---
name: skill-import-workflow
description: Import skills from another machine to Hermes.
version: 1.0.0
author: Hermes Agent + Team
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [skill-import, workflow, installation, migration]
    homepage: https://github.com/NousResearch/hermes-agent
---

# Skill Import Workflow

## Steps
1. Export: `hermes skills snapshot export - > backup.json`
2. Ensure source skills have `SKILL.md` with `name:` frontmatter
3. Import: `hermes skills snapshot import /path/to/skills`
4. Verify: `hermes skills list`
5. Cleanup: `rm backup.json`

## Pitfalls
- Missing `SKILL.md` breaks recognition
- Wrong directory structure (flat in `~/AppData/Local/hermes/skills/`)
- Protected skills (bundled, hub-installed, pinned) cannot be patched
