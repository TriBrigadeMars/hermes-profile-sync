# OST/PST Bulk Extraction with pypff

Known-good recipe for extracting email bodies from Outlook Classic data files
on this Windows host into JSONL. Validated against a live 3.1 GB Exchange OST.

## Setup

```bash
# Python <=3.12 (3.11 proven); py -3.11 launcher syntax on this host may need
# the full spec: py -V:Astral/CPython3.11.16 (plain 'py -3.11' can fail)
py -V:Astral/CPython3.11.16 -m venv .venv
source .venv/Scripts/activate
pip install libpff-python pytest
python -c "import pypff; print(pypff.get_version())"
```

## File locations

- Personal mailbox OST: `%LOCALAPPDATA%\Microsoft\Outlook\<ACCOUNT>.ost`
- Shared mailboxes / group feeds (`*.nst`), `_tmp` files: exclude from personal corpora.
- Find them: `ls -lh "C:/Users/<user>/AppData/Local/Microsoft/Outlook/" | grep -iE '\.(ost|pst)$'`

## Folder-tree discovery (do this FIRST)

The tree is deeper than it looks — `Root - Mailbox/IPM_SUBTREE/IPM_SUBTREE/<folder>`:

```python
def walk(folder, depth=0, max_depth=4):
    name = folder.name or "(root)"
    print(f"{'  '*depth}{name!r} subfolders={folder.number_of_sub_folders} msgs={folder.number_of_sub_messages}")
    if depth < max_depth:
        for i in range(folder.number_of_sub_folders):
            walk(folder.get_sub_folder(i), depth + 1, max_depth)
```

Match target folders by NAME, case-insensitively (`sent items`), never by path.

## Owner (sender) check

```python
def get_sender_smtp(msg):
    """PR_SMTP_ADDRESS lives in the record sets, not in a pypff attribute."""
    for rset in msg.record_sets:
        for entry in rset.entries:
            if entry.entry_type == 0x5D02:  # PR_SMTP_ADDRESS
                v = entry.data
                if isinstance(v, bytes):
                    return v.decode("utf-16-le", errors="replace").rstrip("\x00")
                return str(v)
    return None

def is_owner(msg, owner_smtp, owner_display_lower):
    smtp = get_sender_smtp(msg)
    if smtp is not None:                      # authoritative when present
        return smtp.strip().lower() == owner_smtp
    # missing SMTP is common (~19% on a live Exchange OST)
    return (msg.sender_name or "").strip().lower() == owner_display_lower
```

The display-name fallback keeps genuinely-owner mail when the SMTP property is
absent; the SMTP-present branch excludes delegated "sent on behalf" mail even
when the display name is the owner's.

## Body extraction

```python
import html as html_module, re

BLOCK = re.compile(r"</?(p|div|br|tr|table|li|ul|ol|h[1-6]|blockquote)[^>]*>", re.I)
TAG = re.compile(r"<[^>]+>")
COMMENT = re.compile(r"<!--.*?-->", re.DOTALL)

def html_to_text(h):
    t = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", "", h)
    t = COMMENT.sub("", t)
    t = BLOCK.sub("\n", t)
    t = TAG.sub("", t)
    t = html_module.unescape(t)
    return "\n".join(l.strip() for l in t.splitlines() if l.strip())

def get_body(msg):
    body = _decode(msg.plain_text_body)     # usually None for Outlook-composed mail
    if not body.strip():
        try:
            html = _decode(msg.html_body)
        except OSError:                      # pypff raises when value absent
            html = ""
        if html.strip():
            body = html_to_text(html)
    return body
```

Most Sent Items on an Exchange OST store HTML only; expect roughly 10% empty
bodies from calendar acceptances — report the count rather than failing.

## Path handling

Pass native backslash paths to `pff.open()`: `pff.open(r'C:\Users\...\file.ost')`.
pypff's libcfile concatenates the path raw and produces garbage like
`\\?\C:\C:\...` from MSYS-style `C:/...` strings.

## Verification pattern

After extraction assert and report:
- record count vs `folder.number_of_sub_messages`
- zero records whose SMTP is present and != owner
- counts of: SMTP-matched, display-name-only, excluded, empty bodies

Package JSONL + a manifest (counts, filter description, PRIVATE warning) into a
zip with stdlib `zipfile`; verify by reading it back and running `zf.testzip()`.

## TDD notes

Fake pypff messages in tests with `SimpleNamespace`: mimic `record_sets` as a
list of `SimpleNamespace(entries=[SimpleNamespace(entry_type=0x5D02,
data=smtp.encode('utf-16-le'))])`. Mocking `sender_email_address` does NOT work
— the real code path never reads that attribute.
