# Creating Outlook receive rules via COM (routing rules)

Needed only when a routing rule must be CREATED: the MCP servers can list and toggle rules but cannot create them. The rule is stored in the mailbox and runs like one made in the Rules wizard.

## Preconditions

- Outlook classic running with the target profile (`mcp__outlook_local__outlook_status` confirms).
- Destination folder already exists (under Inbox).
- Match condition, destination, and scope agreed with the user (see SKILL.md routing section).

## Recipe (PowerShell via the bash terminal: `powershell.exe -NoProfile -Command "..."`)

```powershell
Add-Type -AssemblyName Microsoft.Office.Interop.Outlook   # if this fails, fall back to numeric 0 for olRuleReceive
$ol    = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')
$store = $ol.Session.DefaultStore                          # or match by DisplayName across $ol.Session.Stores
$inbox = $store.GetDefaultFolder(6)                        # 6 = olFolderInbox — NOT 1
                                                           # (1 is not a valid olDefaultFolders value and throws
                                                           #  "Value does not fall within the expected range")
$target = $inbox.Folders.Item('<folder name>')
$rules = $store.GetRules()
$rule  = $rules.Create('<rule name>', 0)   # 0 = olRuleReceive. It is Rules.Create, NOT Rules.Add.

# Match on sender (exact address); add more Recipients for more senders
$rule.Conditions.From.Recipients.Add('sender@example.org') | Out-Null
$rule.Conditions.From.Enabled = $true

# Or match on subject/body keywords instead:
# $rule.Conditions.Subject.Text = @('<keyword>'); $rule.Conditions.Subject.Enabled = $true

# Action: move to folder
$rule.Actions.MoveToFolder.Folder = $target
$rule.Actions.MoveToFolder.Enabled = $true

$rule.Enabled = $true
$rules.Save()
```

Key object-model facts (the part worth not re-deriving):

- Attach to the RUNNING instance with `Marshal.GetActiveObject('Outlook.Application')` — no new Outlook process, same profile the user sees.
- `olDefaultFolders`: Inbox=6, SentMail=5, DeletedItems=3, Outbox=4, Calendar=9, Contacts=10, Drafts=16. Inbox is **6**; passing 1 throws ArgumentException.
- `MailItem.SenderEmailAddress` is **null/empty** for internal Exchange senders (`SenderEmailType -eq 'EX'`), and those addresses look like `/O=EXCHANGELABS/OU=...`. Split them into real SMTP with `$m.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptags/0x39FE001E")` (PR_SMTP_ADDRESS) before grouping by sender — otherwise every internal colleague collapses into one bucket and a `$hash.ContainsKey($null)` throws.
- A whole-Inbox snapshot over ~4k items takes minutes. Run the script as a tracked background terminal process (foreground commands are promoted past the 600s cap anyway) and poll — do not assume a silent run means a hung run.
- `Store.GetRules()` returns the store's rule collection; `Rules.Create(name, olRuleReceive)` appends an inbound rule (`Rules.Add(...)` does not exist — `Add` raises "does not contain a method named 'Add'").
- Sender conditions: pass the **bare SMTP string** — `Recipients.Add('user@example.org')`. Handing `Recipients.Add()` a resolved `Recipient` object (from `Session.CreateRecipient` + `.Resolve()`) stores an unmarshaled COM object and read-back then shows `Name='System.__ComObject'`, `Address=''`, `Resolve()=False` — a rule that may never match. Use `CreateRecipient`+`Resolve()` only to *validate* an address before wiring the string.
- Judge a wired condition by `$rec.Name` + `$rec.Resolve()` (both correct in the string path), not `$rec.Address`: `Address` legitimately reads empty for one-off SMTP recipients in this build even when the condition is sound.
- Replace an existing rule by building the replacement first OR at minimum `Save()` before `Remove()`. A script that does `Rules.Remove(name); Save()` and then throws (e.g. at the folder-setter line) leaves the mailbox with **no rule at all** — worse than an unextended one.
- The folder setter takes a single dot: `[Microsoft.Office.Interop.Outlook._MoveOrCopyRuleAction].InvokeMember('Folder', [Reflection.BindingFlags]::SetProperty, $null, $act, @($folder))`. `::InvokeMember` throws "[the type] does not contain a method named 'InvokeMember'".
- Read the rule back from a **fresh process** as well as in-session: freshly created rule objects read stale inside the creating process.
- `$rule.Actions.MoveToFolder.Folder = $folder` silently no-ops in this build (read-back empty → "invalid actions or conditions" on `Save()`); the reflection `InvokeMember` call above is the working path.
- Every condition and action object must have `.Enabled = $true` set explicitly or it is ignored.
- `Conditions.From` is a recipient condition: the sender address goes through `.Recipients.Add(...)`.

## Verify (mandatory)

1. `mcp__outlook__outlook_list_rules` — confirm the rule name is presentand enabled.
2. Wet run— mandatory when several rules were created at once (e.g. an inbox-wide reorganization). Send ONE real test message per rule's predicatefrom webmail or another account(MCP cannot send test mail); wait up to 60s for rules to fire;then read each target folder back with `mcp__outlook_local__search_emails` (newest first)and confirm every test subject sits in its bucketwith zero cross-bucket leaksand nothing swept out of the Inbox beyond the buckets. Fix misroutes in the rule, then re-run the affected bucket only.

**NEVER email real people to test a rule** — that treats someone else's mailor a roster member as a test fixture. Use your own accounts (a second personal account, a throwaway, a webmail alias)or askthe user to send the test mail themselves. This includes members of a roster the rule matches (e.g. Staff Council list)— building their list does not license mailing them. If thereis no consent-to-contact, there is no wet run for that bucket — verify via the user's own accounts instead.

## Building a sender list for a "From these people" rule

When the From-condition must match a roster(page of named members/emails):

- Crawl the WHOLE page (a roster is usually several committee/group tables on one page)and dedupe across every table — the same person recurs on multiple lists.
- Where a member's row shows both a visible label email anda `mailto:` href, trust the **visible label address**, not the href: hrefs on roster pages frequently have copy-paste bugs pointing ata DIFFERENT person's mailbox (e.g. one member's link aimed at another member's address)and malformed truncations. Discard hrefs that are nota well-formed address;use the label.
- Watch display typos:the printed email may misspell the person's name, orthe mailbox may hold an alias form. Note the discrepancy in the rule docs rather than silently "correcting" the address.
- Deliverable: a deduped, one-address-per-line .txt file (plain ASCII, no empty lines), saved next to the plan,rather than a prose list — the file feeds the rule builder directly. Verify: line count == unique count == count of address-bearing linesand all addresses share the expected domain.

## Dry-run a rule chain before creating any rules (hypothetical sort)

A dry run classifies existing mail against the proposed chain WITHOUT moving anything — it is the cheapest place to find misroutes, and it gives the user an inspectable deliverable (per-bucket report + full CSV) to approve or correct the chain before it goes live.

### Recipe
1. Dump the window via COM: `Items.Restrict("[ReceivedTime] >= '11/01/2025 00:00 AM' AND [ReceivedTime] <= '12/31/2025 23:59 PM'")` on the DEFAULT STORE's Inbox (resolve the store root's `Inbox` folder explicitly, not `GetDefaultFolder`, when multiple stores are mounted). For each item capture: `MessageClass`, `ReceivedTime` (`yyyy-MM-dd HH:mm`), `SenderEmailAddress` + `SenderEmailType` (resolve `EX` senders via `PropertyAccessor` PR_SMTP_ADDRESS 0x39FE001E), `SenderName`, `Subject`, first ~1200 chars of `Body` (newlines → spaces), `Attachments` filenames, `EntryID`. Write one JSON object per line (JSONL) via `ConvertTo-Json -Compress` + `WriteAllLines`.
2. Classify offline in Python: implement the chain exactly as spec'd (same rule order, same match surfaces), tag each message with its first-matching rule, and report bucket counts + top senders per bucket + sample subjects + misroute flags.
3. Deliverables: a `.md` report (bucket totals, top senders, sample subjects, findings) + a full `.csv` of every message with its bucket, written to the user's pre-existing workspace folder. Explicitly state NOTHING was moved.

### Classification pitfalls (each cost a misroute when missed)
- **Match the same surface the rule will match.** A keyword rule spec'd as "subject or body contains" will catch ~40% of a typical inbox because 'request'/'training' appear in bodies of operational mail. Prefer SUBJECT-ONLY keyword rules; body-wide keywords need explicit user sign-off after seeing the dry run.
- **Route operational senders by SENDER, above any keyword rule**, or the keyword rule swallows them: no-reply/timesheet/leave systems, case-management notifications (Maxient), LMS notifications (Canvas/instructure), calendar no-replies, ticketing no-replies (Eventbrite/Microsoft/Formstack/Smartsheet). Survey the dry run for high-volume machine-generated senders — each deserves a sender rule to its topical folder, ahead of the keyword layers.
- **A catch-all Miscellaneous rule empties the inbox.** Dry-run and report how many messages would REMAIN in the Inbox (no rule matched); if it's near zero, the Inbox is no longer a safety net — flag it to the user rather than shipping silently.
- **EX senders that never resolve to SMTP** (DN strings like `/O=EXCHANGELABS/...`) classify as external in a Python domain match even though the sender is internal. Report unresolved-EX counts per bucket; Outlook's rule engine evaluates these differently from a string domain match.
- **Zero-match rules are findings, not failures** — a personal-Gmail rule matching 0 in the window means either no such mail arrived or forwarded mail carries a rewritten sender; require a live test before trusting that rule. A newsletter rule matching 0 usually means a prior sweep already cleared those senders (verify against folder counts, don't rebuild).

## Limits — use the Rules wizard UI instead when...

COM scripting is reliable for the simple case (sender and/or subject → move). Multi-condition logic, exceptions, "except if", and "stop processing more rules" are faster and safer to set in the Rules wizard UI (Home → Rules → Manage Rules & Alerts) than to script. Set such rules in the UI, then verify the same way via `outlook_list_rules`.
