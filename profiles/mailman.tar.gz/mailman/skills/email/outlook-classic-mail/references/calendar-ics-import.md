# Installing `.ics` calendars into Outlook Classic

Covers the classic desktop profile only (not Graph/M365 — that is `outlook-agents`).
Use when a generated calendar bundle (milestone/reminder/foresight `.ics` files) or an exported
meeting invite has to become real appointments in the user's live Outlook.

Everything here is driven from PowerShell COM against the RUNNING instance:

```powershell
$ol  = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')
$ns  = $ol.GetNamespace('MAPI')
$cal = $ns.GetDefaultFolder(9)      # 9 = olFolderCalendar
```

Run it from the bash terminal as
`powershell -NoProfile -ExecutionPolicy Bypass -File "<native path to .ps1>"` — write the script to a
file and pass a `C:/...`-style native path; inline `-Command` quoting breaks on `$` and nested quotes.

---

## 1. Recon the destination before anything else

```powershell
Write-Output "OUTLOOK_VERSION: $($ol.Version)"
Write-Output "DEFAULT_CALENDAR: $($cal.FolderPath)  items=$($cal.Items.Count)"
$n = 0
foreach ($f in $cal.Folders) { $n++; Write-Output ("  {0,-30} {1}" -f $f.Name, $f.Items.Count) }
Write-Output "SUBCALENDAR_COUNT: $n"
```

What to look for:

- **Is there already a dedicated calendar?** Sub-calendars are often *shared colleague* calendars
  (other people's names) plus `United States holidays`, `Birthdays`, `Untitled`. If every entry is
  someone else's calendar, the destination does **not** exist yet and you must create it.
- **Is this a first install or a re-install?** Scan every calendar for the incoming event's subject
  tags and record the count. A clean `0` is the baseline the final verification is measured against;
  a non-zero count means a prior partial install that must be reconciled first.
- **Never dump a few hundred generated events into the user's default `Calendar`.** That folder is
  their working surface (standup blocks, "check inbox" reminders, committee meetings).

Subject scanning gotcha — `Restrict` is unreliable on this build, not just for brackets:

```powershell
# THROWS "Condition is not valid" -- for a bracketed pattern ('[' is parsed as a
# field delimiter) AND for plain unbracketed ones:
$cal.Items.Restrict("[Subject] Like '%[CSPH Workshop%'")
$cal.Items.Restrict("[Subject] LIKE '%Grand Rounds%'")        # also throws

# [CreationTime] range filters are worse: they return 0 for windows that
# plainly contain hundreds of items.
$cal.Items.Restrict("[CreationTime] >= '10/08/2026 00:00:00'").Count   # 0, wrong

# Works: iterate and test in the string
foreach ($it in $folder.Items) { if ($it.Subject -and $it.Subject.Contains('[CSPH Workshop')) { ... } }
```

---

## 2. Inspect the source `.ics` before trusting it

Never import a generated bundle straight off. Five checks, each of which has silently cost events:

### 2a. VEVENTs vs unique UIDs

```bash
python - <<'PY'
import re, collections, pathlib
p = pathlib.Path(r"<file>.ics")
txt = p.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
uids = re.findall(r"^UID:(.*)$", txt, re.M)
c = collections.Counter(uids)
print("VEVENTs", len(uids), "unique", len(c), "extras", len(uids) - len(c))
print(sorted(((k, v) for k, v in c.items() if v > 1), key=lambda x: -x[1])[:5])
PY
```

**If `VEVENTs != unique`, the import WILL lose events.** Outlook keys appointments by UID: the second
and later VEVENTs carrying an already-seen UID are treated as updates to the same appointment, so a
file that flattens a weekly series into per-date VEVENTs collapses to one appointment. There is no
error and no warning — only a count that comes up short.

### 2b. Line endings

```bash
python - <<'PY'
import pathlib
raw = pathlib.Path(r"<file>.ics").read_bytes()
lf, crlf, cr = raw.count(b"\n"), raw.count(b"\r\n"), raw.count(b"\r")
print(f"lf={lf} crlf={crlf} cr={cr} crcrlf={raw.count(bytes([13,13,10]))} bare_lf={lf-crlf}")
PY
```

RFC 5545 wants CRLF. Generated bundles commonly carry `\r\r\n` (a doubled CR from writing CRLF content
through a second newline translation) or bare `\n`. Both are a parse risk — normalise to CRLF.

### 2c. `METHOD` and the organizer

Grep the header for `METHOD:`, `ORGANIZER`, `ATTENDEE`.

- `METHOD:PUBLISH` (generated bundles, exports of your own calendar) — safe, importing cannot notify anyone.
- `METHOD:REQUEST` with the **user as `ORGANIZER`** — importing can create a meeting the user appears to
  have sent, and may try to respond to attendees. Check before importing exported invites, and confirm
  with the user rather than assuming it is harmless.

### 2d. Is the set self-redundant?

A bundle often ships `00_ALL_IN_ONE.ics` **plus** its part files. Prove whether the combined file is the
union of the parts before choosing:

```python
# set(UIDs in 00) - union(set(UIDs in parts))  == empty  ->  00 IS the parts
```

If the difference is empty in both directions, importing `00` together with any part file duplicates
everything. Pick **one lane**: the combined file alone, or the parts. Record the skipped file and the
reason, so a later session does not helpfully finish the job.

### 2e. `TZID` references vs `VTIMEZONE` components

```bash
grep -c 'BEGIN:VTIMEZONE' "<file>.ics"; grep -c 'TZID=' "<file>.ics"
```

RFC 5545 requires a `VTIMEZONE` component for every `TZID` used. Generated bundles routinely reference a
zone **without supplying one**, and Outlook then assumes that zone is standard time all year: it converts
the naive local value as though it were standard time, so every event landing inside the local **DST
window imports one hour late**. Nothing errors, and the events falling outside DST are correct — which is
what makes this easy to miss. The same applies to Route A and Route B alike; letting Outlook "parse
`TZID` natively" is only safe when the component is present.

Measured signature, from a bundle with 28 `TZID=` references and 0 `VTIMEZONE` components:

| Intended | Stored | Delta | Where the date falls |
|---|---|---|---|
| 10:00 | 11:00 | +60 min | local DST |
| 12:00 | 12:00 | 0 | local standard time |
| 12:00 | 13:00 | +60 min | local DST again |

**Diagnose on whether the shifted events all sit inside the DST window.** A uniform skew, or a skew on
every event, is a different bug. A recurring series carries a single timezone, so a shifted series is
late for *all* of its occurrences, not just the first — one bad series inflates the blast radius far
beyond its VEVENT count.

Fix by adding the component (immediately after the `X-WR-*` properties, before the first `BEGIN:VEVENT`):

```
BEGIN:VTIMEZONE
TZID:America/Denver
BEGIN:DAYLIGHT
TZOFFSETFROM:-0700
TZOFFSETTO:-0600
TZNAME:MDT
DTSTART:19700308T020000
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU
END:DAYLIGHT
BEGIN:STANDARD
TZOFFSETFROM:-0600
TZOFFSETTO:-0700
TZNAME:MST
DTSTART:19701101T020000
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU
END:STANDARD
END:VTIMEZONE
```

Or sidestep it entirely by rewriting those properties as UTC times, the way an all-`Z` file already does.
Generate the change in the build script; do not hand-edit. An all-UTC file needs none of this — which is
exactly why a scraped feed that mixes `Z` events with `TZID` events imports with only the `TZID` half
wrong, and why "most of the events look right" is not evidence that the timezone handling is fine.

The UTC rewrite is the proven fix — an all-`Z` file imports with correct times — and the packaged
sanitizer (`scripts/sanitize_ics_for_outlook.py`) does it automatically. Convert local → UTC with the US
DST rules from §11 (MDT = UTC−6, MST = UTC−7), then round-trip every converted value back to local and
compare with the intended wall time: the conversion is only verified when the round trip lands on the
intended time, on both sides of a DST boundary.

---

## 3. Sanitize (UID suffixing + CRLF)

Run the packaged script — it rewrites colliding UIDs with a per-instance suffix, normalises line
endings, and self-checks that every output file has `unique_UIDs == VEVENTs`:

```bash
python "<skill_dir>/scripts/sanitize_ics_for_outlook.py" \
    --src "C:/Users/<user>/Downloads/<bundle>" \
    --out "C:/Users/<user>/AppData/Local/hermes/cache/scratch/ics_stage"
```

Stage into the Hermes scratch cache, not the user's document tree — they pre-create their own folders
and object to new ones appearing. The scratch dir is pruned when idle, so re-run the script rather
than relying on yesterday's staged files.

Read the three numeric columns as three different things:

| Column | Meaning |
|---|---|
| `VEVENTs` | blocks in the file |
| `colliding UIDs` | distinct UID *values* appearing more than once |
| `UIDs rewritten` | every VEVENT *carrying* a colliding UID, including the first — so `colliding + extra_copies`, larger than the loss you are avoiding |

Gate on `FILES_FAILED: 0`, which requires all three of: `unique_UIDs == VEVENTs`, clean CRLF, and a
valid structure (exactly one `BEGIN`/`END:VCALENDAR` pair, the file ends with `END:VCALENDAR`, no
`END:VCALENDAR` before the first `VEVENT`). Nothing else is a pass.

**The UID and CRLF checks alone are not enough — they report PASS on a file that imports zero events.**
When you re-serialise an iCalendar you rebuild the header from everything preceding the first
`BEGIN:VEVENT`, and the source's **trailing `END:VCALENDAR` falls into that bucket**. Emitting it puts a
second `END:VCALENDAR` *before* the first `VEVENT`; parsers stop there and import nothing. Exclude
`END:VCALENDAR` when collecting header lines, and assert the structure of what you wrote.

---

## 4. Create the destination sub-calendar(s)

`X-WR-CALNAME` in the file is a hint, not an instruction — Outlook ignores it and creates nothing.
Name the calendar from it anyway (it is the author's intent), and create it explicitly:

```powershell
foreach ($name in @('<Calendar A>', '<Calendar B>')) {
    $found = $null
    foreach ($f in $cal.Folders) { if ($f.Name -eq $name) { $found = $f } }
    if ($found) { Write-Output "EXISTS:  $($found.FolderPath)  items=$($found.Items.Count)" }
    else { $new = $cal.Folders.Add($name); Write-Output "CREATED: $($new.FolderPath)  items=$($new.Items.Count)" }
}
```

Idempotent by construction — re-running prints `EXISTS`. Both must read `items=0` before importing;
that precondition is what makes the rollback a clean undo.

Split by purpose, not by file. Milestone/reminder calendars are the user's own deliverables; a
several-hundred-event campus-events feed is background awareness. Merging them makes the first unusable —
and the second may not be wanted at all. Ask before installing an awareness feed.

---

## 5. Canary: learn where THIS build puts imported events

Do this before any bulk action, with a **one-event** file.

1. Calendar → tick the target sub-calendar's checkbox so it is the *selected* calendar.
2. `File → Open & Export → Import/Export` → **Import an iCalendar (.ics) or vCalendar file (.vcs)** → Next.
3. Pick the one-event file. The dialog then offers **two radio buttons**: `Open as New` and `Import`.
   Choose **Import** — `Open as New` creates one unsaved appointment and nothing else.
4. Read the counts back.

| Observed | Meaning | Route for the bulk files |
|---|---|---|
| target calendar `+1`, default `Calendar` unchanged | the selected calendar is honoured | **Route A** (GUI), repeat per file |
| default `Calendar` `+1`, target `0` | selection ignored, defaults win | **Route B** (split + move) |

The dialog has **no calendar picker**, and behaviour varies by build — that is exactly why the canary
exists. Write down which outcome you got before continuing. Then delete the canary item and re-read the
counts to confirm you are back at baseline.

---

## 6. Route A — GUI import (no code)

Repeat the canary steps per file with the right calendar selected. Native path: Outlook parses `TZID`
and `RRULE` itself — but only correctly when the file supplies the `VTIMEZONE` for each `TZID` it uses,
so run the §2e check first or this route silently imports DST-period events an hour late. Risks: slow and
unresponsive on large files, and it depends entirely on the canary outcome. Do not click in Outlook while
it runs.

## 7. Route B — split per VEVENT, let Outlook parse, then move

`Namespace.OpenSharedItem(path)` returns an appointment for a **single-VEVENT** file; handed a
multi-event file it yields only the first event. So split first, then move each item into the target
folder — this is the only no-GUI route that targets a specific sub-calendar. Because Outlook still does
the parsing, `TZID`/`RRULE` fidelity is preserved.

```powershell
param(
    [Parameter(Mandatory = $true)][string]$Ics,
    [Parameter(Mandatory = $true)][string]$TargetCalendar
)
$ErrorActionPreference = 'Stop'

$ol  = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')
$ns  = $ol.GetNamespace('MAPI')
$cal = $ns.GetDefaultFolder(9)

$target = $null
foreach ($f in $cal.Folders) { if ($f.Name -eq $TargetCalendar) { $target = $f } }
if (-not $target) { throw "Target calendar '$TargetCalendar' not found under $($cal.FolderPath)" }

$text = [IO.File]::ReadAllText($Ics)
$text = $text.Replace("`r`n", "`n").Replace("`r", "`n")
$head   = $text.Substring(0, $text.IndexOf('BEGIN:VEVENT'))
$events = [regex]::Matches($text, '(?s)BEGIN:VEVENT.*?END:VEVENT')

$stage = Join-Path $env:TEMP 'ics_split'
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage | Out-Null
$utf8 = New-Object System.Text.UTF8Encoding($false)

$ok = 0; $fail = 0; $errors = @(); $i = 0
foreach ($m in $events) {
    $i++
    $tmp = Join-Path $stage ("ev_{0:D4}.ics" -f $i)
    [IO.File]::WriteAllText($tmp, ($head + $m.Value + "`r`nEND:VCALENDAR`r`n"), $utf8)
    try { $item = $ns.OpenSharedItem($tmp); $item.Move($target) | Out-Null; $ok++ }
    catch { $fail++; if ($errors.Count -lt 5) { $errors += ("event {0}: {1}" -f $i, $_.Exception.Message) } }
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}

Write-Output "TARGET:           $($target.FolderPath)"
Write-Output "PARSED_VEVENTS:   $($events.Count)"
Write-Output "MOVED_OK:         $ok"
Write-Output "FAILED:           $fail"
$errors | ForEach-Object { Write-Output "  ERR $_" }
Write-Output "TARGET_ITEMS_NOW: $($target.Items.Count)"
```

Run it against the **sanitized** staged file, so every UID is already unique and UID collapse is
impossible. Expect `MOVED_OK == PARSED_VEVENTS` and `TARGET_ITEMS_NOW == PARSED_VEVENTS`.
A few hundred events takes minutes — do not interrupt it.

---

## 8. Verify against predicted counts

Predict every number **before** running the install, then re-run the §1 recon and compare. A mismatch is
a failure to diagnose, never "close enough".

| Check | Pass condition |
|---|---|
| default `Calendar` | exactly the baseline from §1 — a change here means a mis-targeted import |
| each target calendar | exactly the sanitized VEVENT count of its source file |
| total across calendars | exactly the sum |
| worst colliding-UID event | present on its own date — if missing, the sanitizer did not run |
| a recurring series | present on its start date **and** on the next occurrence |

Verify a series via its master item and pattern, never via `GetOccurrence`: from external
PowerShell COM, `GetOccurrence` throws "You changed one of the recurrences of this item, and
this instance no longer exists" even for healthy, long-standing series — it is a limitation of
that context, not evidence of damage. Read the master's `Start`/`StartUTC` and the pattern's
`StartTime`/`EndTime`/`Occurrences`/`PatternStartDate`/`PatternEndDate` instead.

Two counting facts that look like bugs and are not:

- **A recurring series stores as ONE calendar item.** 13 VEVENTs of which 2 carry `RRULE` →
  `Items.Count` reads 13 while the calendar view shows dozens of occurrences. Correct.
- **Zero-duration events** (`DTSTART == DTEND`) import as 0-minute appointments. Common in feeds of
  all-day campus events. Harmless, but expect them and do not chase them as errors.

---

## 9. Rollback

Folder-level delete is the clean undo, because the calendars were created empty in §4:

```powershell
foreach ($f in @($cal.Folders)) {
    if ($f.Name -eq '<Calendar A>' -or $f.Name -eq '<Calendar B>') {
        Write-Output "DELETING $($f.FolderPath) items=$($f.Items.Count)"
        $f.Delete()
    }
}
```

Wrap the collection in `@(...)` — you are deleting from the collection you are iterating. Items land in
`Deleted Items`; the user's own `Calendar` is untouched. Confirm the printed item counts match what you
installed before trusting the delete.

---

## 10. Defect patterns in generated `.ics` bundles

Generated calendars (scripted by an assistant, exported by a scraper) recur with the same flaws. Check
each one before importing:

| Pattern | Effect if unhandled |
|---|---|
| Per-date VEVENTs reusing one UID (flattened series) | Outlook imports 1 appointment instead of N — silent data loss |
| `00_ALL_IN_ONE` plus part files | importing both duplicates the whole set |
| `\r\r\n` or bare `\n` line endings | parse risk, silently skipped events |
| `METHOD:REQUEST` with the user as `ORGANIZER` | may create a meeting the user appears to have sent |
| Events already in the past relative to import day | dead appointments; ask before installing |
| `X-WR-CALNAME` naming a calendar that does not exist | no calendar is created; events land wherever the import defaults to |
| `TZID=` references with no `BEGIN:VTIMEZONE` component | every event inside the local DST window imports **one hour late**; correct-looking events outside it hide the bug |
| Zero-duration / all-day events | 0-minute appointments; harmless but noisy |
| *(introduced by sanitising, not by the source)* trailing `END:VCALENDAR` copied into the header | a second `END:VCALENDAR` before the first `VEVENT`; parsers stop there and import **nothing** |

---

## 11. Writing out what will install

The user treats an install as a decision they get to make, not a fait accompli: they want the manifest of
what lands *before* it lands. Produce it alongside the sanitized `.ics`, in the same folder the `.ics`
are delivered to, as `<date>_<topic>-install-manifest.md`.

What it must contain:

- **A lane table** — one row per file: filename, VEVENT count, destination calendar, and an explicit
  `import? yes / optional / no`, including the deliberately-skipped file and the reason.
- **The full listing for small calendars** — every event: date, local time, subject, location. A dozen
  rows fit inline and are worth reading in full, because they are the user's own deliverables.
- **For large feeds, a month histogram plus the full table.** A several-hundred-row table belongs in the
  file; put the histogram, the file link and a couple of sample rows in the chat reply.
- **Flag the two things that look like bugs and are not:** recurring series ("1 stored item, N
  occurrences") and `DTSTART == DTEND` zero-duration events ("0-minute appointments").
- **Warn on past-dated events.** Anything before the import day is a dead appointment — surface it as a
  decision rather than shipping it silently.

### Rendering local times in Python

Prefer not to: let Outlook parse `TZID`, subject to the §2e `VTIMEZONE` check. But a written manifest
needs local times, and stdlib `zoneinfo` cannot resolve `America/Denver` on this host (no `tzdata`).
Implement US DST rules directly and verify them against the boundaries:

- DST runs from the **2nd Sunday in March 02:00** to the **1st Sunday in November 02:00**.
- Denver is **UTC-7 standard, UTC-6 while DST**.
- For a UTC timestamp, pick the offset whose DST state matches the resulting local time (test `-6`,
  then `-7`).
- **Verify on the boundary dates, not just mid-season** — the failure mode only appears for part of the
  year and is silent in between.

A scraped calendar stored in UTC legitimately carries **different UTC hours for the same wall-clock slot**
either side of the change: `14:00Z` in October and `15:00Z` from November are *both* `08:00` local.
Seeing two different UTC hours is the correct outcome; reporting one event shifted by an hour is the bug.

---

## 12. Uninstalling an import

The user asks for this as its own task, usually when the import is already in the mailbox. `$ns.GetDefaultFolder(3)`
is `Deleted Items`; record its count — the before/after delta is the cheapest proof that items moved rather
than vanished.

The §9 folder delete does **not** apply when the events landed in a calendar that already held the user's
own items. The default `Calendar` is the usual case and deleting it destroys their work.

### 12a. Identify the import set by CONTENT, not by timestamp

An import does stamp every item it creates at nearly the same moment — and those
`CreationTime` values are **not stable**. They drift apart over the minutes after the import
(a 453-item set that read as a single creation second was later observed spread across nine
minutes), so a creation-window filter silently selects only a fraction of the set. Use
`CreationTime` only as corroborating evidence (e.g. "every item in the set was created after
the user's newest pre-existing item"), never as the selector.

Selector: multiset-match every calendar item against the source `.ics` — normalised subject
+ start (date and time), punctuation folded. Require the match count to equal the source
VEVENT count exactly, with zero source events left unmatched. A source can contain duplicate
VEVENTs (same subject and start) that pair 1:1 with duplicate items; that is benign — ambiguity
is only a problem when the candidates differ in start or end.

```powershell
# export the WHOLE folder once -- it is the pre-change backup as well as the input
$rows = @()
foreach ($it in @($cal.Items)) {
    $rows += [pscustomobject]@{
        EntryID     = $it.EntryID
        Subject     = $it.Subject
        Start       = $it.Start.ToString('yyyy-MM-dd HH:mm')
        End         = $it.End.ToString('yyyy-MM-dd HH:mm')
        IsRecurring = [string]$it.IsRecurring
    }
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 "<snapshot>.csv"
```

Keep the CSV — unlike `Deleted Items` it is not subject to a retention policy, and it is the
pre-change backup for any repair, not just deletions.

### 12b. Prove provenance — a count match is not provenance

The §12a multiset match must consume the source exactly: matched items == source VEVENT
count, and zero source events left unmatched. Export both sides and compare offline —
subjects AND start times, so a coincidental subject match on a different date cannot pass.

Normalise both sides before comparing: fold em/en dashes and curly quotes to ASCII, collapse
whitespace runs, casefold. **Require zero unmatched in both directions and print any unmatched
subjects** — do not delete on a bare count match.

### 12c. Test the delete/restore cycle on ONE item

Deleting hundreds of items down an untested path is how a mailbox gets damaged. Pick one non-recurring
candidate, delete it, assert the calendar dropped by exactly 1 **and** `Deleted Items` rose by exactly 1,
then move it back from `Deleted Items` and assert the calendar is back at baseline. Only then continue.

### 12d. Delete

Snapshot the collection with `@(...)` first — **never enumerate a live Outlook collection while deleting
from it**. Select by the content-matched EntryIDs from §12a:

```powershell
$snapshot = @($cal.Items)
$doomed   = @($snapshot | Where-Object { $matchIds -contains $_.EntryID })
if ($doomed.Count -ne $ExpectedCount) { Write-Output "ABORT: $($doomed.Count) != $ExpectedCount"; exit 2 }
foreach ($it in $doomed) { $it.Delete() }
```

- Default to a dry run and require an explicit `-Apply` switch. The EntryID filter is idempotent,
  so re-running after a partial failure removes only what is left.
- `Item.Delete()` on a recurring item removes the **entire series with no prompt** — correct for an import,
  and the reason not to hand-delete from Day/Week view, where Outlook prompts *this occurrence / this and
  following / series* and orphan occurrences get left behind.

### 12e. Verify, then roll back

| Check | Pass condition |
|---|---|
| default `Calendar` | exactly the pre-import baseline |
| items matching the source `.ics` still in the source folder | `0` |
| `Deleted Items` | baseline `+` the number deleted |
| sub-calendar count | unchanged |

Write the post-condition assertion **before** deleting and run it twice: it must report FAIL beforehand
(the calendar is still inflated) and PASS afterwards. Rollback is dragging the items back out of
`Deleted Items`, or re-importing the sanitized `.ics`.

When the events are wanted but merely misplaced, **moving** them (`$it.Move($targetFolder)`) with the same
content-matched EntryID set is strictly less destructive than delete-then-reimport, and leaves nothing in
`Deleted Items`. Offer that before offering deletion. After any move, verify placement by content
(normalised subject + start) — **moving an item between folders rewrites its EntryID**, so an
EntryID captured before the move no longer resolves to it.

---

## 13. Repairing a mis-timed or inconsistent import

When an import already happened and events are wrong, repair in place rather than
delete-and-reimport wherever the affected set is small enough to verify item by item.

### 13a. Diagnose on the UTC instant, not the local read

Compare each suspect item's `StartUTC` with the source's intended instant. A `TZID`
import without `VTIMEZONE` stores DST-period events exactly +1 h off while
standard-time events are correct. The local `Start` read is derived from the stored
instant — fix the instant and the local read follows.

### 13b. Single appointments

```powershell
$it = $ns.GetItemFromID($entryId)
$it.Start = [datetime]'2027-04-06 12:00'   # intended Denver local wall time
$it.End   = [datetime]'2027-04-06 13:00'
$it.Save()
# re-fetch and assert: Start == intended local, StartUTC == intended instant
```

### 13c. Recurring series — rebuild, do not patch

Setting `.Start` on a recurring master fails from external COM ("The object does not
support this method"), and `PropertyAccessor.SetProperty` on the PT_SYSTIME start/end
tags rejects a PowerShell `DateTime` ("Value does not fall within the expected range").
An imported series can also be internally inconsistent — master instant and pattern
`StartTime` disagree, which makes `GetOccurrence` throw even though the pattern itself
is correct. Rebuild:

```powershell
# 1. capture
$old = $ns.GetItemFromID($entryId)
$subj = $old.Subject; $loc = $old.Location; $body = $old.Body
$p = $old.GetRecurrencePattern()
$dowMask = $p.DayOfWeekMask; $patternEnd = $p.PatternEndDate

# 2. delete (recoverable from Deleted Items)
$old.Delete()

# 3. recreate
$appt = $cal.Items.Add()
$appt.Subject = $subj; $appt.Location = $loc; $appt.Body = $body
$appt.Start = [datetime]'2026-10-27 10:00'   # intended local wall time
$appt.End   = [datetime]'2026-10-27 11:00'
$np = $appt.GetRecurrencePattern()
$np.RecurrenceType   = 1          # olRecursWeekly
$np.DayOfWeekMask    = $dowMask   # 4 = Tuesday, 16 = Thursday
$np.PatternStartDate = [datetime]'2026-10-27'
$np.PatternEndDate   = $patternEnd
$appt.Save()

# 4. verify: master Start == intended local, StartUTC == intended instant,
#    pattern StartTime/EndTime/Occurrences match, and exactly one item with
#    that subject remains
```

Verify the rebuilt series via the master and pattern — `GetOccurrence` is unreliable
from external COM (§8). Never verify a repair with a selector that assumes stable
`CreationTime` (§12a).
