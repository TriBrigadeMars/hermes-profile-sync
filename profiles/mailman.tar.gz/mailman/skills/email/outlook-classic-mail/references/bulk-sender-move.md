# Bulk-move existing mail by sender (Outlook COM)

Use when the user wants every existing message from one sender moved into a folder that already exists. Requires the classic Outlook instance to be running. Read-only MCP tools cannot move mail, so the moves go through COM.

## Gates (apply every time)

- **Scope = the store the user names.** If the user says "default mailbox only", touch only the default store. List the other stores in the report and leave them alone, even when they hold matching mail.
- **Destination must already exist.** Use the folder the user names. If the name the user gives does not exist but a close match does, ask before using the close match. Never create a folder unless the user asks for one.
- **Snapshot before any mutation.** The CSV is the only record of original locations, and it is the rollback.
- **Predicted count gate.** The move script reports `Predicted / Moved / Failed`. Any `Failed > 0` stops the run and the failed subjects get reported. Do not retry blindly.
- **Verify both sides.** Source tree must show zero matches from the sender, and the destination must hold exactly the predicted count.

## Procedure

### 1. Recon (MCP, read-only)
`outlook_status` → `list_mailboxes` (note the default store's `store_id`) → `list_folders` on the Inbox to confirm the destination's exact name and `folder_id`.

Do not use MCP `search_emails` to count a whole sender history. It returns about 20 items per cursor page, and a sender with hundreds of messages needs dozens of paged calls. Use step 2 for the count.

### 2. Snapshot (dry run, no moves)
Save as `$TMPDIR/sender_snapshot.ps1` and run with `powershell -NoProfile -ExecutionPolicy Bypass -File <path>`. Walks the default store recursively, skips the destination, and writes the CSV. Tested on a store of about 5,000 items; it finishes within a few minutes, so run it as a background process.

```powershell
$ErrorActionPreference = 'Stop'
$target   = '<sender@example.com>'          # exact SMTP address
$destName = '<existing-folder-name>'        # direct child of the default Inbox
$scratch  = "$env:TMPDIR"                   # if empty, use $env:LOCALAPPDATA\Temp
$excluded = @('Deleted Items','Junk Email','Outbox','Sync Issues','Conversation History',
              'Yammer Root','Calendar','Contacts','Tasks','Notes','Journal')

$ol = New-Object -ComObject Outlook.Application
"Outlook version: " + $ol.Version          # blank = modal dialog blocking COM
$ns = $ol.GetNamespace('MAPI')
$defInbox = $ns.GetDefaultFolder(6)
$root = $defInbox.Store.GetRootFolder()
"Default store: " + $defInbox.Store.DisplayName
$script:hits = New-Object System.Collections.ArrayList
$script:scanned = 0
$script:skipped = New-Object System.Collections.ArrayList

function Walk($folder) {
    if ($folder.Name -eq $destName -and $folder.Parent.Name -eq 'Inbox') { return }
    $n = $folder.Items.Count
    for ($i = 1; $i -le $n; $i++) {
        $it = $folder.Items.Item($i)
        $script:scanned++
        if ($it.Class -eq 43) {                # 43 = olMail
            if (([string]$it.SenderEmailAddress).Equals($target, [StringComparison]::OrdinalIgnoreCase)) {
                [void]$script:hits.Add([pscustomobject]@{
                    FolderPath = $folder.FolderPath
                    Subject    = $it.Subject
                    Received   = $it.ReceivedTime.ToString('o')
                    EntryID    = $it.EntryID
                })
            }
        }
    }
    foreach ($sub in @($folder.Folders)) { Walk $sub }
}

foreach ($top in @($root.Folders)) {
    if ($excluded -contains $top.Name) { [void]$script:skipped.Add($top.Name); continue }
    Walk $top
}
"Scanned items: $script:scanned"
"Excluded top-level folders: " + (($script:skipped | ForEach-Object { $_ }) -join ', ')
"Matches: " + $script:hits.Count
$script:hits | Export-Csv -NoTypeInformation -Encoding UTF8 "$scratch\sender_snapshot.csv"
"Snapshot: $scratch\sender_snapshot.csv"
"--- per folder ---"
$script:hits | Group-Object FolderPath | ForEach-Object { "$($_.Count)  $($_.Name)" }
```

Record N (total matches) as the predicted count, and report the per-folder breakdown. The `$excluded` list is a choice: Deleted Items and Junk are excluded by default. If the user wants them included, remove them from the list and say so in the report.

### 3. Move (after the user approves the destination and scope)
The user's answer to the destination and scope is the go-ahead. Proceed from snapshot to move without asking again. Stop only on `Failed > 0` or a count mismatch.

Save as `$TMPDIR/sender_move.ps1`:

```powershell
$ErrorActionPreference = 'Stop'
$destName = '<existing-folder-name>'
$scratch  = "$env:TMPDIR"
$ol = New-Object -ComObject Outlook.Application
$ns = $ol.GetNamespace('MAPI')
$inbox = $ns.GetDefaultFolder(6)
"Store: " + $inbox.Store.DisplayName
$dest = @($inbox.Folders) | Where-Object { $_.Name -eq $destName } | Select-Object -First 1
if (-not $dest) { throw "Destination '$destName' not found under Inbox" }
"Destination: " + $dest.FolderPath + "  pre-move items: " + $dest.Items.Count
$rows = @(Import-Csv "$scratch\sender_snapshot.csv")
$predicted = $rows.Count
$moved = 0; $failed = 0
$failures = New-Object System.Collections.ArrayList
foreach ($r in $rows) {
    try {
        $item = $ns.GetItemFromID($r.EntryID)   # resolve fresh; EntryIDs from the snapshot are valid only before a move
        [void]$item.Move($dest)
        $moved++
    } catch {
        $failed++
        [void]$failures.Add(($r.Received + ' :: ' + $_.Exception.Message))
    }
}
"Predicted: $predicted  Moved: $moved  Failed: $failed"
if ($failed -gt 0) { 'FAILURES:'; $failures | ForEach-Object { $_ } }
"Destination count now: " + $dest.Items.Count
"Inbox root count now: " + $inbox.Items.Count
```

Expected on success: `Predicted: N  Moved: N  Failed: 0` and `Destination count now: N` (when the destination was empty before, otherwise pre-move count + N).

### 4. Verify (by sender, not EntryID)
Save as `$TMPDIR/sender_verify.ps1`. Moving changes EntryIDs, so count by sender in both places:

```powershell
$ErrorActionPreference = 'Stop'
$target   = '<sender@example.com>'
$destName = '<existing-folder-name>'
$ol = New-Object -ComObject Outlook.Application
$ns = $ol.GetNamespace('MAPI')
$inbox = $ns.GetDefaultFolder(6)
$dest = @($inbox.Folders) | Where-Object { $_.Name -eq $destName } | Select-Object -First 1
function Count-From($f) {
    $c = 0
    for ($i = 1; $i -le $f.Items.Count; $i++) {
        $it = $f.Items.Item($i)
        if ($it.Class -eq 43 -and ([string]$it.SenderEmailAddress).Equals($target, [StringComparison]::OrdinalIgnoreCase)) { $c++ }
    }
    return $c
}
"Inbox root remaining from sender: " + (Count-From $inbox)
"Destination items from sender: " + (Count-From $dest) + ' of ' + $dest.Items.Count + ' total'
```

Pass criteria: Inbox root remaining = 0 (or only items in folders the user excluded), and destination items from sender = N. Subfolders of the Inbox are not covered by this check. Run the snapshot script again if the user cares about them, and expect zero matches there.

## Pitfalls

- **Snapshot EntryIDs are single-use.** A move rewrites the EntryID, so reusing the CSV after a partial or complete move fails silently for the moved items. Re-run step 2 for any second pass.
- **Snapshot match relies on SMTP.** `SenderEmailAddress` compares SMTP, so a sender stored as an Exchange address (`/O=EXCHANGELABS/...`) does not match. If the MCP sender search finds more items for the same address than the COM snapshot does, check the EX-addressed senders before concluding the snapshot is complete.
- **Do not enumerate a live collection while moving.** The move script reads from the CSV and moves by resolved EntryID, which is why it does not walk `$inbox.Items` while mutating it.
- **Keep the CSV in scratch, not the workspace.** It holds subject lines and receive times for the mail. Delete it once the user confirms the move is final.
- **Rollback:** move each item back to its `FolderPath` from the CSV, matching by `Subject` + `Received` (not EntryID), then verify the count.
