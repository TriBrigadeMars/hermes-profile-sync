<#
.SYNOPSIS
  Route B: install a sanitized .ics into a NAMED Outlook Classic sub-calendar.

.DESCRIPTION
  Works around the fact that the `Import an iCalendar (.ics)` dialog has no
  calendar picker: Namespace.OpenSharedItem() returns an appointment for a
  SINGLE-VEVENT file, so each VEVENT is written to its own temporary file, let
  Outlook parse it (preserving TZID / RRULE fidelity), and then moved into the
  target folder explicitly.

  Run against the SANITIZED file from scripts/sanitize_ics_for_outlook.py, so
  every UID is already unique and UID collapse is impossible.

  A few hundred events takes minutes. Do not interrupt it, and do not click in
  Outlook while it runs.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File "install_ics_to_calendar.ps1" `
      -Ics "C:/.../ics_stage/02-foresight.ics" -TargetCalendar "CU Anschutz Master Foresight"
#>
param(
    [Parameter(Mandatory = $true)][string]$Ics,
    [Parameter(Mandatory = $true)][string]$TargetCalendar
)
$ErrorActionPreference = 'Stop'

$ol  = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')
$ns  = $ol.GetNamespace('MAPI')
$cal = $ns.GetDefaultFolder(9)          # 9 = olFolderCalendar

$target = $null
foreach ($f in $cal.Folders) { if ($f.Name -eq $TargetCalendar) { $target = $f } }
if (-not $target) { throw "Target calendar '$TargetCalendar' not found under $($cal.FolderPath)" }

Write-Output "OUTLOOK_VERSION:      $($ol.Version)"
Write-Output "TARGET:               $($target.FolderPath)"
Write-Output "BASELINE_TARGET_ITEMS: $($target.Items.Count)"

$text = [IO.File]::ReadAllText($Ics)
$text = $text.Replace("`r`n", "`n").Replace("`r", "`n")

# Rebuild the header, EXCLUDING the source's trailing END:VCALENDAR. Everything
# before the first BEGIN:VEVENT is copied verbatim, and the trailing END:VCALENDAR
# falls into that bucket -- emitting it writes a second END:VCALENDAR BEFORE the
# first VEVENT, and parsers stop there and import nothing.
$head = $text.Substring(0, $text.IndexOf('BEGIN:VEVENT'))
$head = [regex]::Replace($head, '(?m)^[ \t]*END:VCALENDAR[ \t]*$', '')

$events = [regex]::Matches($text, '(?s)BEGIN:VEVENT.*?END:VEVENT')
if ($events.Count -eq 0) { throw "No VEVENT blocks found in $Ics" }

# Unique stage dir per run, so no pre-wipe of a shared directory is needed.
$stage = Join-Path $env:TEMP ("ics_split_" + [guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Path $stage | Out-Null
$utf8 = New-Object System.Text.UTF8Encoding($false)

$ok = 0; $fail = 0; $errors = @(); $i = 0
foreach ($m in $events) {
    $i++
    $tmp = Join-Path $stage ("ev_{0:D4}.ics" -f $i)
    [IO.File]::WriteAllText($tmp, ($head + $m.Value + "`r`nEND:VCALENDAR`r`n"), $utf8)
    try {
        $item = $ns.OpenSharedItem($tmp)
        $item.Move($target) | Out-Null
        $ok++
    } catch {
        $fail++
        if ($errors.Count -lt 5) { $errors += ("event {0}: {1}" -f $i, $_.Exception.Message) }
    }
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}
Remove-Item $stage -Force -Recurse -ErrorAction SilentlyContinue

Write-Output "PARSED_VEVENTS:       $($events.Count)"
Write-Output "MOVED_OK:             $ok"
Write-Output "FAILED:               $fail"
$errors | ForEach-Object { Write-Output "  ERR $_" }
Write-Output "TARGET_ITEMS_NOW:     $($target.Items.Count)"

# Predicted-vs-actual is the only signal that a large import silently dropped events.
if ($fail -eq 0 -and $ok -eq $events.Count) {
    Write-Output "RESULT:               PASS -- now re-run the recon and compare the folder counts"
} else {
    Write-Output "RESULT:               FAIL -- $fail of $($events.Count) events did not move"
}
