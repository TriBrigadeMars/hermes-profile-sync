#!/usr/bin/env python3
"""Sanitise .ics files so Outlook Classic imports every VEVENT.

Outlook keys appointments by UID, so two defects in generated calendars cost
events silently, with no error and no warning:

  1. VEVENTs that reuse a UID with a different DTSTART (a recurring series that
     was flattened into one VEVENT per date) import as a SINGLE appointment --
     all the other instances vanish. Fix: suffix each colliding UID with its own
     DTSTART so every VEVENT carries a distinct UID.
  2. Non-CRLF line endings (\r\r\n from a doubled newline translation, or bare
     \n) are non-conformant and a parse risk. Fix: rewrite the file as CRLF.
  3. TZID= references with no VTIMEZONE component (an RFC 5545 violation): Outlook
     assumes the zone is standard time all year and imports every event inside
     the local DST window one hour late. Fix: rewrite those DTSTART/DTEND values
     as UTC (Z) instants, which Outlook imports correctly.

Usage:
    python sanitize_ics_for_outlook.py --src <dir-with-ics> [--out <staging-dir>]

Stage into the Hermes scratch cache, never into the user's document tree: they
pre-create their own folders and object to new ones appearing.

Exit code is 0 only when every output file passes ALL of:
  * unique_UIDs == VEVENTs == BEGIN:VEVENT count
  * CRLF throughout (no \r\r\n, no bare LF)
  * exactly one BEGIN:VCALENDAR/END:VCALENDAR pair, the file ends with
    END:VCALENDAR, and no END:VCALENDAR appears before the first VEVENT
  * no TZID= reference remains (every one converted to a UTC instant)

The last group is not decoration. Re-serialising an iCalendar is where the
source's TRAILING END:VCALENDAR gets swept into the header block, emitting a
second END:VCALENDAR before the first VEVENT -- parsers stop there and import
NOTHING, while the UID and CRLF checks alone report PASS on that dead file.

Anything short of all three groups is a failure to diagnose, not a pass.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import pathlib
import re
import sys

UID_RE = re.compile(r"^UID:(.*)$")
DT_RE = re.compile(r"(\d{8}T\d{6})")
TZID_RE = re.compile(r"^(DT(?:START|END));TZID=America/Denver:(\d{8}T\d{6})$")


def _nth_weekday(year, month, weekday, n):
    """Date of the n-th weekday (Mon=0) of the month -- US DST boundary helper."""
    d = dt.date(year, month, 1)
    d += dt.timedelta(days=(weekday - d.weekday()) % 7)
    return d + dt.timedelta(weeks=n - 1)


def _is_dst(local_naive):
    """US DST window: 2nd Sunday of March 02:00 .. 1st Sunday of November 02:00."""
    start = dt.datetime.combine(_nth_weekday(local_naive.year, 3, 6, 2), dt.time(2))
    end = dt.datetime.combine(_nth_weekday(local_naive.year, 11, 6, 1), dt.time(2))
    return start <= local_naive < end


def to_utc(local_naive):
    """Denver local wall time -> UTC instant (MDT = UTC-6, MST = UTC-7)."""
    return local_naive + dt.timedelta(hours=6 if _is_dst(local_naive) else 7)
DEFAULT_OUT = (
    pathlib.Path.home()
    / "AppData" / "Local" / "hermes" / "cache" / "scratch" / "ics_stage"
)


def unfold(text: str) -> str:
    """RFC 5545 line unfolding: CRLF followed by one space/tab continues a line."""
    return re.sub(r"\r\n[ \t]", "", text)


def normalise(text: str) -> str:
    """Collapse every line-ending flavour to bare LF for parsing."""
    return (
        unfold(text)
        .replace("\r\r\n", "\n")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
    )


def parse_blocks(text: str):
    """Return (head_lines, [vevent_lines, ...]); blank lines are dropped."""
    head: list[str] = []
    blocks: list[list[str]] = []
    cur: list[str] | None = None
    for raw in text.split("\n"):
        ln = raw.strip()
        if ln == "BEGIN:VEVENT":
            cur = []
        elif ln == "END:VEVENT":
            if cur is not None:
                blocks.append(cur)
            cur = None
        elif cur is not None:
            if ln:
                cur.append(ln)
        elif ln and ln not in ("BEGIN:VCALENDAR", "END:VCALENDAR"):
            # The source's TRAILING END:VCALENDAR reaches this branch too. Letting it
            # through writes a second END:VCALENDAR into the header -- i.e. BEFORE the
            # first VEVENT -- and parsers stop there and import nothing.
            head.append(ln)
    return head, blocks


def sanitize(src_file: pathlib.Path, out_dir: pathlib.Path):
    text = normalise(src_file.read_text(encoding="utf-8-sig"))
    head, blocks = parse_blocks(text)

    # UID value -> indices of the VEVENTs carrying it
    index: dict[str, list[int]] = collections.defaultdict(list)
    for i, block in enumerate(blocks):
        for ln in block:
            m = UID_RE.match(ln)
            if m:
                index[m.group(1).strip()].append(i)
                break

    collisions = {u: idx for u, idx in index.items() if len(idx) > 1}
    rewritten = 0
    for uid, idx in collisions.items():
        for i in idx:
            block = blocks[i]
            dtstart = next((l for l in block if l.startswith("DTSTART")), "")
            stamp = DT_RE.search(dtstart)
            suffix = stamp.group(1) if stamp else f"i{i}"
            for j, ln in enumerate(block):
                if ln.startswith("UID:"):
                    block[j] = f"UID:{uid}_{suffix}"
                    rewritten += 1
                    break

    # TZID=America/Denver without a VTIMEZONE component imports DST-period events
    # one hour late; UTC (Z) instants import correctly. Rewrite them.
    tz_conversions = 0
    for block in blocks:
        for j, ln in enumerate(block):
            m = TZID_RE.match(ln)
            if m:
                local = dt.datetime.strptime(m.group(2), "%Y%m%dT%H%M%S")
                block[j] = f"{m.group(1)}:{to_utc(local).strftime('%Y%m%dT%H%M%S')}Z"
                tz_conversions += 1

    out = ["BEGIN:VCALENDAR", *head]
    for block in blocks:
        out.append("BEGIN:VEVENT")
        out.extend(block)
        out.append("END:VEVENT")
    out.append("END:VCALENDAR")

    out_dir.mkdir(parents=True, exist_ok=True)
    dest = out_dir / src_file.name
    dest.write_bytes(("\r\n".join(out) + "\r\n").encode("utf-8"))
    return len(blocks), len(collisions), rewritten, tz_conversions, dest


def structure_problems(text: str) -> list[str]:
    """Structural faults that make a parser stop early or import nothing."""
    problems: list[str] = []
    n_begin_cal = text.count("BEGIN:VCALENDAR")
    n_end_cal = text.count("END:VCALENDAR")
    n_begin_ev = text.count("BEGIN:VEVENT")
    n_end_ev = text.count("END:VEVENT")
    if n_begin_cal != 1:
        problems.append(f"BEGIN:VCALENDAR x{n_begin_cal}")
    if n_end_cal != 1:
        problems.append(f"END:VCALENDAR x{n_end_cal}")
    if n_begin_ev != n_end_ev:
        problems.append(f"VEVENT unbalanced {n_begin_ev}/{n_end_ev}")
    if not text.rstrip().endswith("END:VCALENDAR"):
        problems.append("does not end with END:VCALENDAR")
    first_ev = text.find("BEGIN:VEVENT")
    first_end_cal = text.find("END:VCALENDAR")
    if -1 not in (first_ev, first_end_cal) and first_end_cal < first_ev:
        problems.append("END:VCALENDAR before the first VEVENT")
    return problems


def check(dest: pathlib.Path, expected_total: int):
    raw = dest.read_bytes()
    text = raw.decode("utf-8")
    uids = [
        m.group(1).strip()
        for m in (UID_RE.match(l) for l in text.split("\n"))
        if m
    ]
    unique = len(set(uids))
    crlf_clean = raw.count(b"\r\r\n") == 0 and raw.count(b"\n") == raw.count(b"\r\n")
    structural = structure_problems(text)
    no_tzid_left = "TZID=" not in text
    ok = (
        unique == len(uids) == expected_total
        and text.count("BEGIN:VEVENT") == expected_total
        and crlf_clean
        and not structural
        and no_tzid_left
    )
    return ok, len(uids), unique, crlf_clean, structural, no_tzid_left


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--src", required=True, type=pathlib.Path,
                    help="directory containing the .ics files to sanitize")
    ap.add_argument("--out", default=DEFAULT_OUT, type=pathlib.Path,
                    help=f"staging directory (default: {DEFAULT_OUT})")
    args = ap.parse_args()

    if not args.src.is_dir():
        print(f"FAIL: --src is not a directory: {args.src}")
        return 1
    files = sorted(p for p in args.src.glob("*.ics"))
    if not files:
        print(f"FAIL: no .ics files under {args.src}")
        return 1

    print(f"{'file':<58}{'VEVENTs':>8}{'colliding UIDs':>16}{'UIDs rewritten':>16}{'TZID->UTC':>10}")
    print("-" * 108)
    bad = 0
    for src_file in files:
        total, colliding, rewritten, tz_conversions, dest = sanitize(src_file, args.out)
        print(f"{src_file.name:<58}{total:>8}{colliding:>16}{rewritten:>16}{tz_conversions:>10}")
        ok, n_uids, unique, crlf_clean, structural, no_tzid_left = check(dest, total)
        if not ok:
            bad += 1
        print(
            f"    -> {dest.name}: VEVENTs={n_uids} unique_UIDs={unique} "
            f"CRLF_ok={crlf_clean} structure_ok={not structural} "
            f"no_TZID_left={no_tzid_left}  "
            f"[{'PASS' if ok else 'FAIL'}]"
        )
        for problem in structural:
            print(f"       STRUCTURAL FAULT: {problem}")

    print()
    print(f"STAGING_DIR: {args.out}")
    print(f"FILES_FAILED: {bad}")
    print()
    print("'colliding UIDs' counts distinct UID VALUES seen more than once;")
    print("'UIDs rewritten' counts every VEVENT carrying one, first occurrence included,")
    print("so it is larger than the number of extra copies that would have been lost.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
