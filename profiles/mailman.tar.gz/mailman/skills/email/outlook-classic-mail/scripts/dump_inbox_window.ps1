# dump_inbox_window.ps1 — dump a date-range window of the DEFAULT store's Inbox to JSONL
# for offline rule-chain dry runs. Usage (from bash terminal):
#   powershell -NoProfile -ExecutionPolicy Bypass \
#     -File dump_inbox_window.ps1 -StartDate '11/01/2025' -EndDate '12/31/2025' \
#     -OutFile 'C:/Users/<user>/AppData/Local/hermes/cache/scratch/inbox_window.jsonl'
# Nothing is moved or modified — read-only export.
param(
  [Parameter(Mandatory=$true)][string]$StartDate,   # 'MM/DD/yyyy'
  [Parameter(Mandatory=$true)][string]$EndDate,       # 'MM/DD/yyyy'
  [Parameter(Mandatory=$true)][string]$OutFile
)
$ErrorActionPreference = 'Stop'
$out = @()

try { $outlook = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
catch { Write-Output "ERROR: Outlook not running: $($_.Exception.Message)"; exit 1 }
$ns = $outlook.GetNamespace('MAPI')
$store = $ns.DefaultStore
Write-Output ("STORE=" + $store.DisplayName)

# Resolve the store root's Inbox explicitly (not GetDefaultFolder) so the window
# is unambiguous when several stores are mounted.
$root = $store.GetRootFolder()
$inbox = $null
foreach ($f in $root.Folders) { if ($f.Name -eq 'Inbox') { $inbox = $f; break } }
if (-not $inbox) { Write-Output "ERROR: no Inbox in default store"; exit 1 }

$filter = "[ReceivedTime] >= '$StartDate 00:00 AM' AND [ReceivedTime] <= '$EndDate 23:59 PM'"
$items = $inbox.Items.Restrict($filter)
Write-Output ("TOTAL_IN_RANGE=" + $items.Count)

$PR_SMTP = 'http://schemas.microsoft.com/mapi/proptag/0x39FE001E'
$i = 0; $skipped = @{}
foreach ($m in $items) {
  $i++
  $mc = ''
  try { $mc = [string]$m.MessageClass } catch {}
  if ($mc -notlike 'IPM.Note*' -and $mc -notlike 'IPM.Schedule.Meeting*' -and $mc -notlike 'IPM.Appointment*') {
    if (-not $skipped.ContainsKey($mc)) { $skipped[$mc] = 0 }
    $skipped[$mc]++; continue
  }
  $smtp = ''; $seType = ''
  try { $seType = [string]$m.SenderEmailType } catch {}
  try {
    $smtp = [string]$m.SenderEmailAddress
    if ($seType -eq 'EX') {
      try { $smtp = [string]$m.Sender.PropertyAccessor.GetProperty($PR_SMTP) } catch {}
    }
  } catch {}
  $senderName = ''; $subj = ''; $recv = ''
  try { $senderName = [string]$m.SenderName } catch {}
  try { $subj = [string]$m.Subject } catch {}
  try { $recv = ([datetime]$m.ReceivedTime).ToString('yyyy-MM-dd HH:mm') } catch {}
  $body = ''
  try {
    $body = [string]$m.Body
    if ($body.Length -gt 1200) { $body = $body.Substring(0, 1200) }
    $body = $body -replace "`r",' ' -replace "`n",' ' -replace "`t",' '
  } catch {}
  $atts = @()
  try {
    foreach ($a in $m.Attachments) {
      $fn = ''; try { $fn = [string]$a.FileName } catch {}
      if ($fn) { $atts += $fn } else { $atts += '(no-name)' }
    }
  } catch {}
  $rec = [ordered]@{
    idx = $i; msgclass = $mc; received = $recv; sender_smtp = $smtp
    sender_name = $senderName; subject = $subj
    attachments = ($atts -join ';'); body_snip = $body; entry_id = ''
  }
  try { $rec.entry_id = [string]$m.EntryID } catch {}
  $out += (ConvertTo-Json -Compress -InputObject ([object]$rec))
}
[System.IO.File]::WriteAllLines($OutFile, [string[]]$out)
Write-Output ("WROTE=" + $out.Count + " lines to " + $OutFile)
foreach ($k in $skipped.Keys) { Write-Output ("SKIPPED_CLASS=" + $k + " x" + $skipped[$k]) }
Write-Output "DONE"
