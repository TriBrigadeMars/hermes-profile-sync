---
name: event-planning-workflow
description: "Use when planning a training, workshop, or outreach event weeks out. Milestone ladder, materials checklist, state-file seeding, approval gates."
version: 1.0.0
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [events, outreach, planning, project-management]
---

# Event Planning Workflow (Training / Workshop / Outreach Event)

Generic procedure for planning an event from approval to closeout. Distilled from
the 2026-10-09 Bystander Intervention sample plan. Parameters live in the Event
Snapshot; everything else is fixed process.

## 1. Event Snapshot (fill first, confirm with Mars)

| Field | Ask Mars |
|---|---|
| Title | exact wording |
| Format / duration | e.g. 90-min facilitated training + pre/post evaluation |
| Target date | propose date = today + lead time he asked for; confirm |
| Audience + headcount | who, how many |
| Venue | campus/area TBD — propose options, he picks |
| Time slot | propose one; confirm |

Do not proceed past planning until Mars answers the snapshot decisions.

## 2. Milestone ladder (N = weeks out)

Work backwards from event day. Standard ladder (compress proportionally for
shorter lead times):

- **W-N (week 1):** Mars approves event manifest (agenda, materials list, .ics template). Seed `outreach_state.json`. Room request submitted (venue logistics via `maps` skill — locate, parking, accessibility; agent CANNOT book).
- **W-N+1 … W-3:** surveys drafted (Google Forms ONLY after Mars approves platform + questions); promotion timeline begins (communications sent by MARS or his normal channels — never by the agent); materials drafted.
- **W-3:** all materials finalised (facilitator guide, deck, handouts).
- **W-2:** pre-survey closes; materials checklist verified (printed handouts, tech check, nametags).
- **W-1:** dry-run walk-through with Mars; final headcount; post-survey built (mirror of pre).
- **Event day:** deliver; agent tracks attendance vs RSVPs.
- **W+1:** post-survey open 1 week; then closeout.

## 3. Materials checklist (adapt per event)

Event day: facilitator's guide (annotated agenda, timing cues), slide deck
(`powerpoint` skill), printed + digital handouts, survey QR/short-link cards,
sign-in sheet, nametags, AV (projector, adapters, clicker, audio test), room
diagram (U-shape or classroom, never theatre), refreshments (budget ask first).

Agent-owned tracking: `outreach_state.json` current, .ics manifest generated
(approval-gated), weekly reminders via cron, Friday goals report.

## 4. State file seeding

Seed `C:/Users/cruzmars/Documents/OE Outreach/outreach_state.json` on approval:

```json
{
  "goals":   [{"id": "g-001", "title": "Deliver <event>", "due": "<event date>",
               "status": "not_started", "milestones": ["...one per milestone..."]}],
  "events":  [{"id": "e-001", "title": "<event>", "date": "<date>", "venue": "<TBD>",
               "status": "planning", "attendees": "<who, how many>",
               "materials": ["..."]}],
  "tasks":   [{"id": "t-001", "goal_id": "g-001", "title": "...", "due": "<date>",
               "status": "not_started"}]
}
```

Weekly tracking rules: (1) re-read state.json before every status report — never
report from memory; (2) flag anything due within 7 days with status
`not_started` as AT-RISK; (3) write changes back immediately after every action;
(4) the file is the single source of truth.

## 5. Mars decision queue (present as a numbered table)

Venue preference, date confirmation, time slot, survey platform, budget items,
his availability for the dry run. One reply can answer all; agent does not
execute past planning until heard from.

## 6. Hard gates — NEVER without Mars's explicit approval

- Send ANY email (drafts OK; he sends).
- Create Outlook calendar events or distribute .ics — manifest only, he approves.
- Publish a survey — he reviews questions first.
- Spend money / place print or catering orders — checklists only.
- Assume a booking succeeded — verify by reading back his confirmation.
- Touch the `life-coach` profile.
- Execute plan steps before the plan is approved.

## 7. Post-event closeout (within 1 week)

1. Close post-survey, export results.
2. One-page summary: attendance, pre/post comparison, qualitative themes, lessons.
3. Update all goals/events/tasks to `completed`/`archived`.
4. Present summary in-session (not email).
5. Archive materials to `C:/Users/cruzmars/Documents/OE Outreach/<Event>-<date>/`.

## Recurring agent procedures

- Friday afternoon: goals-progress scan from state.json (% complete per goal, at-risk flags).
- Cron reminders (owned by cos-agent): respond with due/overdue tasks + one-line context each.
- Surveys via `mcp__google_workspace__create_form` only after platform approval.
- Slide decks via `powerpoint` skill; deliver as file path, never attached to email.
