---
name: hermes-cron-health-verification
description: Use when creating, checking, or fixing Hermes cron jobs.
version: 1.0.0
author: hermes-curator
license: MIT
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [cron, scheduler, health-check, verification, file-coverage, repair, hermes]
    related_skills: [hermes-state-change-audit, rss_feed_monitoring]
---

# Cron Health and File-Coverage Verification

## When to Use
- "Are my cron jobs running properly?" / "Is <job> still firing?" / "Why didn't I get the weekly report?"
- Before or after editing a schedule, changing a job's script, or adding a new job.
- After a machine restart, an app upgrade, or a gap in expected deliveries.
- **Coverage questions** — "are all my files actually being processed?", "ensure every file is processed", "why are only N documents in the report?". A liveness check cannot answer these; go to the File coverage section.

Default to READ-ONLY: the deliverable is a findings report. Change nothing (schedules, scripts, incident rows) unless the user asks. State plainly in the report that nothing was modified.

**Never mutate the data being studied.** For a research, records, or compliance corpus, adding documents (by OCR, by widening a filter, by fixing an accidental exclusion) changes every count the user reports. Surface it as a decision with exact numbers and let the user choose. When they decline, deliver a per-file exclusion list with independent evidence for each file plus a paste-ready limitations paragraph — a documented gap, not a silent one. Back up any project script before patching it, into the scratch directory, never alongside the project.

## Truth hierarchy — never answer from job `last_status` alone
`last_status: ok` is the job's own self-report. The scheduler keeps separate evidence; check in this order and stop trusting the upper level when a lower one disagrees:

1. `$HERMES_HOME/cron/ticker_heartbeat` (unix seconds) — is the scheduler ticking at all? Fresh means within roughly one to two job intervals of `date +%s`.
2. `$HERMES_HOME/cron/executions.db` — real per-run rows (statuses, errors, lateness).
3. The `cron_incidents` table in that same DB — the only place with a *state* (open vs closed).
4. `$HERMES_HOME/cron/output/<job_id>/*.md` — the newest run bodies.
5. The actual artifact on disk — mtime plus row/entry counts. The only proof the job's side effect happened.

## Procedure
1. **Inventory**: `cronjob_manage(action='list')` for schedule, `deliver`, `script`, `no_agent`, last/next run. Then read `$HERMES_HOME/cron/jobs.json` for what the list truncates: `repeat.completed` (lifetime fire count), `last_dispatch` (`kind: on_time|catch_up`, `lateness_seconds`), `failure_streak`, `model_snapshot`/`provider_snapshot`.
2. **Ticker alive?** Compare `cat $HERMES_HOME/cron/ticker_heartbeat` with `date +%s`. Also read `catch_up_occurrences` — it counts fires that were late or back-filled at startup, a strong hint the host process was closed for a while.
3. **Per-job run history**: group by job+status (verified queries in `references/scheduler-state-db.md`). Any status other than `completed`, or any non-empty `error`, is a finding.
4. **Open incidents**: rows with `state='alerted'` and `closed_at IS NULL` are live failure records — read `error` verbatim and report the root cause, not the symptom. An incident that predates a fix stays open forever, so compare its `last_seen_at` against the job's recent successful runs before calling the job broken; report such rows as stale bookkeeping, not as a failure.
5. **Run bodies**: read the newest one or two files under `cron/output/<job_id>/`. **No output directory at all means the job has NEVER fired** — confirm with `repeat.completed: 0` and `last_run_at: null` in jobs.json, and say so explicitly instead of listing it as healthy.
6. **Verify the deliverable, not the log line**: stat the artifact the job claims to write and reconcile any count the job reports against reality (`find <dir> -maxdepth 1 -name '*.md' | wc -l`). A fresh mtime is the real evidence.
7. **Verify a never-fired job's script before its first scheduled fire** — exercise only the side-effect-free part: import the module by absolute file path and call its fetch/build function directly, never its send/delete function. Never send a test email, never delete/move/rename files, never run a cleanup or migration job's destructive path to "check" it. Report the verified half and the unverified half separately.
8. **Report**: a per-job table (id, name, schedule, healthy / failing / never-run, plus the one piece of evidence proving it), then numbered problems with cause and fix, then config findings (mis-schedule, wrong `deliver`, needless agent mode) called out as notes rather than failures.

## Authoring a job — build the thing the verification pass will inspect
Deterministic file/text work belongs in a `--no-agent` script job: no LLM turn per fire, no `model_snapshot` to go stale, and stdout is the report. Use agent mode only when the job genuinely needs judgement (see the `no_agent: false` pitfall).

1. Put the script under `$HERMES_HOME/scripts/` — the resolver rejects anything outside it (see Pitfalls), so a script living in a skill folder needs a thin launcher there.
2. Develop it under the interpreter the scheduler will use, not the one on PATH. A `.py` job script spawns as `[sys.executable, script]` with the installed app's venv python, which can be an older minor version and can lack pytest — write the job's tests with stdlib `unittest`, run them from the scripts directory, and give the script an argparse `--dry-run` that writes NOTHING (not even its own audit log) so the first real fire is boring.
3. Create it paused, verify, then resume — never let a job that moves, renames, or deletes anything fire before it has been inspected:
   `hermes cron create "every friday 4:45pm" --name <name> --script <file>.py --no-agent --deliver local --paused`
4. Read the parsed `schedule.expr` from jobs.json (pitfall above), then `hermes cron resume <id>` and confirm `Next run:` names the expected weekday, hour and UTC offset.
5. For a job that moves or renames files: append every action to a CSV that is replayable as an undo (one row per action: run_id, timestamp, action, src, dst, status, reason), and make a destination collision skip that single move rather than overwriting or renaming. Auto-created directories must be an explicit allowlist; a destination whose parent folder is missing is a skip, never a `mkdir`.
6. State where the report lands. A `no_agent` job with `--deliver local` writes `cron/output/<job_id>/<ts>.md` and delivers nothing to chat, so tell the user the path instead of assuming they will see it.

Do not assume a VCS around `$HERMES_HOME`: check `git rev-parse` before writing commit steps into a plan for files there, and use a dated copy into the user's own backup folder as the durable fallback.

## File coverage — when the question is "are all files processed?"
Health proves the job FIRED; coverage proves it did its whole job. A job can report `ok` every minute while a fixed set of files fails on every tick, because a per-file failure is logged, not raised. Depth and repair recipes: `references/file-coverage-reconciliation.md`; re-runnable probe: `scripts/audit_pipeline_coverage.py`.

1. Enumerate each stage's input tree yourself and put **every** file in exactly one bucket: covered / deliberately skipped / failing / unknown extension. The invariant is `files on disk == state entries == records in the aggregate output`; any difference is the finding.
2. Read the stage's own log and run summary for per-file failures — that is the only place they exist.
3. Verify each failure's REASON independently (re-check "no extractable text" with a pypdf page-text extraction) instead of repeating the script's own message.
4. Quantify any file that can never succeed: it appears in every consecutive run summary, one attempt per tick — count files x ticks x seconds before calling it harmless.
5. State the stage boundaries plainly. A stage consumes only its declared source folder, so files landing upstream are counted by a reporting job but never converted or coded — do not imply the chain covers them.

Repair rules (only when the user asks for the fix):
- **Make the consumer's discovery scope match the producer's.** If the producer recurses (`os.walk`, `rglob`) and the consumer globs one level (`glob("*.md")`), a file in a subfolder gets converted and silently never coded, and both jobs look healthy in isolation. Keep dot-directories and the output directory out of the recursive scan.
- **Re-key state backward-compatibly.** Moving from filename keys to relative-path keys must leave existing keys valid (a top-level file's relpath IS its filename) or the next run re-processes the entire corpus. Prove it by hashing the aggregate output before and after: byte-identical.
- **Disambiguate output names when nesting can collide** (two sources, same stem, different folders): slug the directory in, but keep the historical name whenever the stem is unique so cached state keeps resolving.
- **Guard the destructive consequence of an empty input.** If a missing or moved source folder yields zero files, "rebuild the output from current files" truncates a populated deliverable. Exit non-zero on an inaccessible source, prune nothing in that case, and refuse to overwrite a non-empty aggregate with zero records.
- **Write aggregates atomically** (temp file + `os.replace`) and prune state for sources that no longer exist, so a crash cannot truncate the deliverable and a rename re-processes cleanly.
- **Match placeholder and sidecar files by NAME, never by extension.** `Path(".gitkeep").suffix` is `""` — not `".gitkeep"` — so an extension-based exclusion set lets it through and it appears in reports as a `(no ext)` row; and `<file>.quarantine.json`-style sidecars get enumerated as content, inflating an inventory tab until it disagrees with a summary tab that filters by extension. Exclude both, then assert the two tabs agree.

Verify a repair without touching real data: load the pipeline module by absolute file path (`importlib.util.spec_from_file_location`), override its module-level path globals to a scratch tree, and build fixtures — a nested file, a duplicate stem across two folders, a dot-directory. Assert the new behaviour, then assert idempotency (a second sweep processes nothing) and that touching one file re-processes exactly one. Never add test documents inside the user's corpus to prove a fix.

## Pitfalls
- `gateway_running: false` (from the cron list, or `hermes gateway status` reporting no process) does NOT mean the jobs are stopped — the scheduler can be demonstrably alive with no gateway process for that profile, because the desktop app drives the ticker in-process. Check `ticker_heartbeat` and recent `executions` rows first, then state the real caveat: fires stop while the host process is closed and back-fill on restart. Never relay the tool's "jobs will NOT fire" warning without that check.
- If the user needs fires while the app is closed, the fix is the gateway (a Windows login item normally exists; `hermes gateway start` / `hermes gateway install`). Offer it as a follow-up; do not install it during a verification pass.
- Job scripts must resolve INSIDE `$HERMES_HOME/scripts/` — a script path pointing straight into a skill folder fails with "Script not found". Keep the real wrapper where it belongs and add a thin launcher under `scripts/`.
- On Windows, a `.sh` job script is spawned via `shutil.which("bash")`, which resolves to `System32\bash.EXE` (the WSL launcher) and dies with `execvpe(/bin/bash) failed: No such file or directory`. Fix: make the job script a `.py` launcher that locates Git Bash by absolute path (`C:\Program Files\Git\bin\bash.exe`, never System32) and forwards argv to the real wrapper — a `.py` job script runs under the agent's interpreter instead. Pass the wrapper as an MSYS `/c/...` path (git-bash resolves it) and native `C:/...` forward-slash paths to Windows executables.
- `no_agent` jobs deliver stdout verbatim, and EMPTY stdout is a normal success meaning "nothing to do" (the run body records `Status: silent (empty output)`). Never report silence as failure.
- `deliver: 'local'` saves the run body and delivers nothing anywhere, so a job can fail silently for weeks with no chat trace. For those jobs, inspect output dirs on your own initiative rather than waiting to be told something broke.
- A `*/N` day-of-month cron field is not an N-day interval: `0 9 */14 * *` fires on days 1, 15 and 29 — gaps of 14, 14, then 2–3 days back to the 1st — and only twice in February. For a true N-day cadence use the scheduler's interval form (e.g. `20160m` for 14 days) or anchor on a weekday.
- `no_agent: false` on a job whose whole job is running one script burns an LLM turn per fire; `no_agent: true` + `script:` is free. Flag it as a finding, do not convert it mid-verification.
- A job snapshotted to a provider/model the main agent no longer uses can fail for reasons unrelated to its script — check `model_snapshot`/`provider_snapshot` in jobs.json when a job fails at dispatch rather than inside its script.
- `executions.db` is a rolling window (a thousand rows observed), so old runs are unavailable for forensics — historic failures survive only in `cron_incidents`.
- A `no_agent` job exits 0 while individual files fail, so per-file failures never become incidents. They surface only in the script's own run summary (`{"converted": 0, "failed": 10, ...}`) and the log, which the scheduler does not read. Read the run summary, not just the status, before declaring a job healthy — and check whether the same file names recur across consecutive runs.
- Schedules are interpreted in HOST-LOCAL time, and `hermes cron create` has no timezone flag (no `--tz`; `next_run_at` carries the host's UTC offset). When the user names a timezone — "4:45 PM PST" on a Mountain host — resolve the conversion explicitly and say which wall clock you chose instead of silently substituting one for the other. Pinning a foreign zone costs a twice-yearly `hermes cron edit`: PST 4:45 PM is 5:45 PM Mountain while both observe DST and 6:45 PM in standard time.
- The human schedule phrase and the stored expression are different objects: read `schedule.expr` out of `jobs.json`, never `schedule_display`/the `Schedule:` line. `every friday 4:45pm` is a supported phrase, but only the expr proves the hour that will actually fire.

## Support files
- `references/scheduler-state-db.md` — cron state file layout, both DB schemas, and the verified queries to run.
- `references/file-coverage-reconciliation.md` — the file-coverage bucket model, repair recipes for a stage that skips files, and the sandbox-harness pattern for testing a pipeline fix without touching real data.
- `scripts/cron_health_report.py` — re-runnable read-only dump: ticker freshness, per-job run history, open incidents, newest output per job.
- `scripts/audit_pipeline_coverage.py` — re-runnable stdlib probe for one stage: buckets its files, diffs them against the state file, flags placeholders/sidecars, stale entries and unconvertible files, and confirms each recorded output exists and is non-empty.
