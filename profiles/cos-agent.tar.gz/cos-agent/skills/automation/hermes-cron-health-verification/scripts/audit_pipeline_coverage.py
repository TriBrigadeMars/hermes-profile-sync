#!/usr/bin/env python3
"""Reconcile one pipeline stage against its own state file.

Answers "is every input file accounted for?" for a single stage: buckets the
stage's source files, diffs them against the stage's state file, and reports
placeholders/sidecars, stale state, and outputs that are missing or empty.

Stdlib only. Exit 0 = every file accounted for, 1 = discrepancies found,
2 = bad usage (unreadable source folder).

Examples
--------
# convert stage: folder -> markdown, state keyed by filename
python audit_pipeline_coverage.py \
  --source "<proj>/output" \
  --state  "<dest>/.markdown_conversion_state.json" --state-pointer files \
  --key-mode filename --dest "<dest>" --output-key output

# code stage: markdown -> per-file JSONL, state keyed by relative path
python audit_pipeline_coverage.py \
  --source "<dest>" \
  --state  "<jsonl-dir>/.coding_state.json" --state-pointer processed_files \
  --key-mode relpath --dest "<jsonl-dir>" --output-key jsonl_file

Add --probe-text-layer to independently confirm that uncovered PDFs really have
no extractable text (pypdf), rather than trusting the stage's own message.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

# Placeholders are matched by NAME: Path('.gitkeep').suffix is '' -- not
# '.gitkeep' -- so an extension-based exclusion set silently lets it through.
PLACEHOLDER_NAMES = {".gitkeep", ".tmp", ".gitignore", ".ds_store"}
SIDECAR_SUFFIXES = (".quarantine.json",)

CONVERTIBLE = {".pdf", ".docx", ".pptx", ".xlsx", ".html", ".htm", ".rtf",
               ".txt", ".md", ".csv", ".json", ".xml", ".eml", ".msg"}
IMAGES = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".tif", ".webp", ".heic"}


def is_meta(p: Path) -> bool:
    name = p.name.lower()
    return name in PLACEHOLDER_NAMES or name.endswith(SIDECAR_SUFFIXES)


def key_for(root: Path, p: Path, mode: str) -> str:
    return p.name if mode == "filename" else p.relative_to(root).as_posix()


def load_state(path: Path | None, pointer: str) -> dict:
    if path is None:
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"state file not found: {path}", file=sys.stderr)
        return {}
    except Exception as exc:  # corrupt state: report, do not guess
        print(f"state file unreadable ({type(exc).__name__}): {path}", file=sys.stderr)
        return {}
    if pointer:
        data = data.get(pointer, {})
    return data if isinstance(data, dict) else {}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--source", required=True, help="stage input folder")
    ap.add_argument("--state", default=None, help="stage state JSON file")
    ap.add_argument("--state-pointer", default="",
                    help="top-level key holding the entry map, e.g. files")
    ap.add_argument("--key-mode", choices=("filename", "relpath"), default="filename")
    ap.add_argument("--dest", default=None, help="folder an entry's output path resolves against")
    ap.add_argument("--output-key", default=None, help="entry field naming the produced file")
    ap.add_argument("--probe-text-layer", action="store_true",
                    help="pypdf-check uncovered PDFs for a text layer")
    args = ap.parse_args()

    src = Path(args.source).expanduser()
    if not src.is_dir():
        print(f"source folder not accessible: {src}", file=sys.stderr)
        return 2

    problems: list[str] = []

    everything = sorted(p for p in src.rglob("*") if p.is_file())
    meta = [p for p in everything if is_meta(p)]
    files = [p for p in everything if not is_meta(p)]
    nested = [p for p in files if p.parent != src]

    print(f"source                : {src}")
    print(f"files                 : {len(files)}  ({len(nested)} below the top level)")
    print(f"placeholders/sidecars : {len(meta)}  (excluded from the counts below)")
    print(f"extension census      : "
          f"{dict(sorted(Counter(p.suffix.lower() or '(no ext)' for p in files).items()))}")
    for p in meta[:10]:
        print(f"    meta: {p.relative_to(src).as_posix()}")

    keys = {key_for(src, p, args.key_mode): p for p in files}
    state = load_state(Path(args.state) if args.state else None, args.state_pointer)
    print(f"state entries         : {len(state)}   (key mode: {args.key_mode})")

    uncovered = sorted(set(keys) - set(state))
    stale = sorted(set(state) - set(keys))
    print(f"on disk, not in state : {len(uncovered)}")
    for k in uncovered[:20]:
        print(f"    - {k}")
    print(f"in state, not on disk : {len(stale)}")
    for k in stale[:20]:
        print(f"    - {k}")

    if files and not state:
        problems.append("state is empty while files exist: the stage has processed nothing")
    if uncovered:
        problems.append(f"{len(uncovered)} file(s) on disk are not in the state file")
    if stale:
        problems.append(f"{len(stale)} stale state entr(ies): source removed or renamed")
    if nested:
        print(f"note                  : {len(nested)} file(s) below the top level "
              f"-- a one-level glob would miss these")

    if args.dest and args.output_key:
        dest = Path(args.dest).expanduser()
        missing, empty = [], []
        for k, entry in state.items():
            if not isinstance(entry, dict):
                missing.append(f"{k} (entry is not an object)")
                continue
            out = entry.get(args.output_key)
            if not out:
                missing.append(f"{k} (no '{args.output_key}' field)")
                continue
            q = dest / out
            if not q.is_file():
                missing.append(f"{k} -> {out}")
            elif q.stat().st_size == 0:
                empty.append(f"{k} -> {out}")
        print(f"missing outputs       : {len(missing)}")
        for m in missing[:10]:
            print(f"    - {m}")
        print(f"empty outputs         : {len(empty)}")
        for m in empty[:10]:
            print(f"    - {m}")
        if missing:
            problems.append(f"{len(missing)} state entr(ies) name an output that does not exist")
        if empty:
            problems.append(f"{len(empty)} output(s) are zero bytes (empty artifact)")

    if args.probe_text_layer:
        try:
            from pypdf import PdfReader
        except ImportError:
            print("text-layer probe      : skipped (pypdf not installed)")
        else:
            pdfs = [p for p in files if p.suffix.lower() == ".pdf"
                    and key_for(src, p, args.key_mode) not in state]
            other = [p for p in files if p.suffix.lower() in IMAGES
                     and key_for(src, p, args.key_mode) not in state]
            if other:
                print(f"image files uncovered : {len(other)} "
                      f"(capability gap if the stage has no OCR, not a defect)")
            if pdfs:
                print(f"text-layer probe      : {len(pdfs)} uncovered PDF(s)")
                for p in pdfs:
                    try:
                        rd = PdfReader(str(p))
                        chars = len("".join((pg.extract_text() or "")
                                            for pg in rd.pages).strip())
                        print(f"    chars={chars:6d} pages={len(rd.pages):3d}  {p.name}")
                        if chars:
                            problems.append(
                                f"{p.name} HAS a text layer but was not processed")
                    except Exception as exc:
                        print(f"    unreadable ({type(exc).__name__})  {p.name}")

    print()
    if problems:
        print("VERDICT: DISCREPANCIES")
        for p in problems:
            print(f"  - {p}")
        return 1
    print("VERDICT: every file accounted for")
    return 0


if __name__ == "__main__":
    sys.exit(main())
