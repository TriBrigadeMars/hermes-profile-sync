#!/usr/bin/env python3
"""Read-only Hermes cron health dump.

Usage:
    python cron_health_report.py [--home <HERMES_HOME>] [--outputs 2]

Prints: scheduler ticker freshness, per-job config summary, per-job run
history, non-clean runs, incidents, and the newest run bodies per job.
Writes nothing; safe to run while the scheduler is live.
"""

import argparse
import json
import os
import sqlite3
import time
from datetime import datetime
from pathlib import Path


def resolve_home(explicit=None):
    if explicit:
        return Path(explicit)
    env = os.environ.get("HERMES_HOME")
    if env:
        return Path(env)
    local = os.environ.get("LOCALAPPDATA")
    if local:
        return Path(local) / "hermes"
    return Path.home() / ".hermes"


def stamp(epoch):
    try:
        return datetime.fromtimestamp(float(epoch)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(epoch)


def section(title):
    print()
    print(f"=== {title} ===")


def read_text(path):
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except Exception as exc:
        return f"<unreadable: {exc}>"


def ticker(cron):
    section("scheduler ticker")
    now = time.time()
    print(f"now (unix): {now:.0f}  ({stamp(now)})")
    for name in ("ticker_heartbeat", "ticker_last_success"):
        raw = read_text(cron / name)
        try:
            age = now - float(raw)
            verdict = "ALIVE" if age < 300 else "STALE (longer than any sane job interval)"
            print(f"{name:20}: {raw}  age={age:.0f}s  {verdict}")
        except ValueError:
            print(f"{name:20}: {raw}")
    print(f"catch_up_occurrences: {read_text(cron / 'catch_up_occurrences')}")


def jobs(cron):
    section("jobs.json summary")
    try:
        data = json.loads((cron / "jobs.json").read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"cannot read jobs.json: {exc}")
        return
    items = data.get("jobs", data) if isinstance(data, dict) else data
    for job in items:
        repeat = job.get("repeat") or {}
        dispatch = job.get("last_dispatch") or {}
        print(f"{job.get('id')} {job.get('name')}")
        print(
            f"    schedule={job.get('schedule_display') or job.get('schedule')}  "
            f"deliver={job.get('deliver')}  script={job.get('script')}  "
            f"no_agent={job.get('no_agent')}"
        )
        print(
            f"    last_run={job.get('last_run_at')}  last_status={job.get('last_status')}  "
            f"failure_streak={job.get('failure_streak')}  fires={repeat.get('completed')}"
        )
        print(
            f"    next_run={job.get('next_run_at')}  "
            f"dispatch_kind={dispatch.get('kind')}  "
            f"lateness={dispatch.get('lateness_seconds')}  "
            f"model_snapshot={job.get('model_snapshot')}"
        )


def db(cron):
    path = cron / "executions.db"
    if not path.exists():
        section("executions.db")
        print(f"missing: {path}")
        return
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    try:
        section("run history by job/status")
        for row in con.execute(
            "select job_id, status, count(*) n, min(started_at) first, "
            "max(finished_at) last from executions "
            "group by job_id, status order by job_id, n desc"
        ):
            print(dict(row))

        section("non-clean runs (newest 20)")
        rows = list(
            con.execute(
                "select job_id, status, started_at, finished_at, "
                "substr(coalesce(error,''),1,200) error from executions "
                "where status != 'completed' "
                "or (error is not null and error != '') "
                "order by finished_at desc limit 20"
            )
        )
        if not rows:
            print("none")
        for row in rows:
            print(dict(row))

        section("incidents (OPEN = state 'alerted' and never closed)")
        try:
            for row in con.execute(
                "select job_id, state, failure_type, first_seen_at, last_seen_at, "
                "closed_at, substr(coalesce(error,''),1,300) error "
                "from cron_incidents order by last_seen_at desc"
            ):
                item = dict(row)
                open_row = (
                    str(item.get("state")).lower() == "alerted"
                    and not item.get("closed_at")
                )
                print(f"[{'OPEN' if open_row else 'ok'}] {item}")
        except sqlite3.Error as exc:
            print(f"cron_incidents unreadable: {exc}")
    finally:
        con.close()


def outputs(cron, per_job):
    section(f"newest run bodies per job (top {per_job})")
    root = cron / "output"
    if not root.is_dir():
        print(f"no output dir: {root}")
        return
    for job_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        files = sorted(
            (f for f in job_dir.iterdir() if f.is_file()),
            key=lambda f: f.stat().st_mtime,
            reverse=True,
        )
        if not files:
            print(f"{job_dir.name}: EMPTY -- has never produced a run body")
            continue
        newest = files[0]
        age = time.time() - newest.stat().st_mtime
        print(
            f"{job_dir.name}: {len(files)} bodies, newest {newest.name} "
            f"(age {age / 3600:.1f}h)"
        )
        for item in files[:per_job]:
            tail = [ln for ln in read_text(item).splitlines() if ln.strip()][-2:]
            print(f"    {item.name}: {' | '.join(tail)[:180]}")


def main():
    ap = argparse.ArgumentParser(description="read-only Hermes cron health dump")
    ap.add_argument("--home", default=None, help="HERMES_HOME override")
    ap.add_argument("--outputs", type=int, default=2, help="bodies to show per job")
    args = ap.parse_args()

    home = resolve_home(args.home)
    cron = home / "cron"
    print(f"HERMES_HOME: {home}")
    print(f"cron dir   : {cron} (exists={cron.is_dir()})")
    if not cron.is_dir():
        raise SystemExit("no cron directory found")

    ticker(cron)
    jobs(cron)
    db(cron)
    outputs(cron, max(1, args.outputs))
    print("\nread-only dump complete; nothing was modified")


if __name__ == "__main__":
    main()
