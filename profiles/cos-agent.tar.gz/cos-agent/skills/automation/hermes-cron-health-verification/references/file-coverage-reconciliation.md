# File coverage reconciliation

Depth for the **File coverage** section of SKILL.md. Answers "is every input file accounted for?"
for one stage of a pipeline, and covers repairing a stage that silently skips files.

## The invariant

```
files on disk  ==  state entries  ==  records in the aggregate output
```

Every number in that chain is derived differently — the first from the filesystem, the second from the
stage's own memo file, the third from the artifact it produces — so disagreement localises the bug
without reading any code. A stage whose three numbers match is not necessarily correct (it may be
correctly excluding files it should include), which is why the bucket model below exists.

## Bucket model

Put every file in exactly one bucket, and report the bucket sizes rather than a verdict:

| Bucket | Meaning | Action |
|---|---|---|
| covered | has a state entry and a present, non-empty output | none |
| deliberately skipped | unsupported format, placeholder, sidecar | confirm the reason is by design, and that the count matches the skip total in the run summary |
| failing | convertible format, no state entry, an error on every run | verify the reason independently, then quantify the cost |
| unknown extension | neither convertible nor a known skip | treat as a defect: it is falling through the format routing |
| stale state | state entry whose source is gone | prune; report if the count is growing |

## Reading a stage's own state file

State schemas differ; adapt rather than assume. Two common shapes:

```python
# {"version": 1, "files":      {"<key>": {"output": "<rel>.md",   "size": ..., "mtime": ...}}}
# {"processed_files":           {"<key>": {"jsonl_file": "<name>", "size": ..., "mtime": ...}}}
entries = json.loads(state_path.read_text(encoding="utf-8"))[pointer]
```

Notes that decide whether a key diff is meaningful:
- **Key mode matters.** Filename keys collide across folders; relpath keys do not. When a stage keys by
  filename and its source is (or becomes) nested, the diff will look clean while files overwrite each
  other. Check which mode the state uses before trusting `files on disk == state entries`.
- **Unchanged detection is usually `size` + exact `mtime` equality.** So `touch` alone forces
  reprocessing and a content change that preserves both size and mtime does not. Verify a "0 new" run
  means "no changes" rather than "detection broken" by touching one file in the sandbox.
- **A corrupt/unreadable state file commonly triggers a rebuild-from-scratch**, so a stage can silently
  reprocess everything. Harmless for idempotent converters, expensive for anything with a side effect.

## Repair recipes

**Recursive discovery that matches the producing stage.** Keep dot-directories and the stage's own
output folder out of the walk; skip a path component entirely rather than filtering the result, or the
walk still descends into large trees it should never read.

```python
for p in root.rglob("*.md"):
    rel = p.relative_to(root)
    if p.name.startswith(".") or any(part.startswith(".") for part in rel.parts[:-1]):
        continue
```

**Backward-compatible state re-key.** Keep the old key for the files the old key identified, so the
first run after the change does not reprocess everything:

```python
def rel_key(path):          # bare filename at the top level, 'sub/dir/name' below it
    return path.relative_to(SOURCE).as_posix()
```

Guard the refactor with a hash of the aggregate output:

```bash
md5sum "<aggregate>" > /tmp/before
# ...patch, run the stage once...
md5sum "<aggregate>" > /tmp/after && diff /tmp/before /tmp/after   # must be identical
```

**Collision-safe output naming in a flat output directory.** Derive uniqueness only where a collision
is possible, so historical names — and therefore cached state and aggregate references — stay valid:

```python
by_stem = {}                             # stem -> [sources]
if len(by_stem[stem]) == 1:              # historical name, unchanged
    name = f"{stem}{SUFFIX}"
else:                                    # disambiguate with a directory slug + counter
    name = f"{stem}__{slug(parent)}{SUFFIX}"
```

**Guards an empty input must not get past.**

```python
if not SOURCE.is_dir():
    raise RuntimeError(f"source folder not accessible: {SOURCE}")   # exit non-zero, prune nothing
if not records and aggregate.exists() and aggregate.stat().st_size > 0:
    print("refusing to overwrite a non-empty aggregate with 0 records", file=sys.stderr)
else:
    tmp.write_text(...); os.replace(tmp, aggregate)                # atomic
```

**Name-based placeholder/sidecar filtering.** See the SKILL.md rule; the mechanism is that
`Path(".gitkeep").suffix == ""` and sidecars such as `<file>.quarantine.json` are real `.json` files
already paired with a content file, so list them under their own heading (excluded, N) rather than
letting them into an inventory tab.

## Sandbox harness — test the fix against the real logic, not the real data

A pipeline with hardcoded project paths can still be tested end to end: import it by path and repoint
its module-level globals at a scratch tree. This exercises the actual production code without a single
file entering the user's corpus.

```python
import importlib.util, sys
from pathlib import Path

spec = importlib.util.spec_from_file_location("pipeline", PIPELINE_PY)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.SOURCE_DIR, m.OUTPUT_DIR = SRC, OUT          # module globals are what the functions read
m.STATE_FILE, m.LOCK_FILE   = OUT / ".state.json", OUT / ".lock"
m.ARTIFACT_PATH             = OUT / "artifact.xlsx"
```

Fixtures worth building every time, because each one catches a distinct class of bug:
- a file at the top level and one in a subfolder (recursion)
- the same stem in two folders (output-name collision)
- a dot-directory (must be skipped)
- then, as assertions: a second sweep processes nothing (idempotency), and touching exactly one file
  reprocesses exactly one (change detection)
- and a run with the source folder missing, asserting the state file and aggregate are byte-identical
  afterwards (the truncation guard)

## Exclusion list artifact

When the user declines to fill a coverage gap, the deliverable is a document, not silence. Generate it
from disk so nothing is hand-transcribed, and include:

1. the arithmetic, as a table: candidate / included / excluded-by-reason, with percentages;
2. per-file rows with the evidence that justifies exclusion — for image-only scans, page count and the
   independently measured extractable-character count (0), not the converter's own message;
3. a ready-to-paste limitations paragraph naming the file types involved, stating that exclusion
   reflects a missing capability rather than a judgement of immateriality, and noting that closing the
   gap later would require reprocessing and recomputing reported frequencies;
4. provenance: source and destination folders, the state file with its entry count, the log, and how
   the verification was performed.

## Counting commands

```bash
# candidate files by extension, ignoring placeholders and sidecars
find "<dir>" -type f ! -name '.gitkeep' ! -name '*.quarantine.json' | sed 's/.*\.//' | sort | uniq -c
# per-run summary of a stage that logs one line per run
grep 'run end' "<stage log>" | tail -1
# distinct failure signatures, most frequent first
grep -h 'FAIL' "<stage log>" | sed -E 's/^[^ ]+ //' | sort | uniq -c | sort -rn | head
```
