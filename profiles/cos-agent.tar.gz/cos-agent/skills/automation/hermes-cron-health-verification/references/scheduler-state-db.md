# Hermes cron scheduler state — files, schemas, queries

All paths under `$HERMES_HOME/cron/` (`$HERMES_HOME` = `$LOCALAPPDATA\hermes` on Windows; resolution order is `$HERMES_HOME`, then `$LOCALAPPDATA\hermes`, then `~/.hermes`).

## File layout

| Path | What it is |
|---|---|
| `jobs.json` | Full job config: `id`, `name`, `prompt`, `script`, `no_agent`, `monitor_script`/`monitor_url`/`monitor_state`, `context_from`, `schedule{kinds,minutes\|expr,display}`, `schedule_display`, `repeat{times,completed}`, `enabled`, `state`, `paused_at`/`paused_reason`, `created_at`, `next_run_at`, `last_run_at`, `last_status`, `last_error`, `failure_streak`, `deliver`, `origin`, `last_dispatch{scheduled_at,dispatched_at,lateness_seconds,kind}`, `provider_snapshot`/`model_snapshot`. Top-level `updated_at` moves on every tick. |
| `executions.db` | SQLite: `executions`, `cron_incidents`. |
| `output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md` | Run body per fire; kept to ~50 files per job. Header gives Job ID, Run Time, Mode, Status. Missing dir = job never fired. |
| `ticker_heartbeat`, `ticker_last_success` | Unix seconds, rewritten each tick — freshness is the "is the scheduler alive" test. |
| `catch_up_occurrences` | Integer count of fires that were late or back-filled at startup. |
| `.tick.lock`, `.jobs.lock`, `.fire-<hash>.lock` | Lock files; leftover `.fire-*` files indicate interrupted fires. |

## `executions` columns

`id` (opaque string hash — **has no chronological order, never sort by it**), `job_id`, `source`, `process_id`, `pid`, `process_started_at`, `status`, `claimed_at`, `started_at`, `finished_at`, `error`, `handoff_pending`, `handoff_started_at`, `delivery_outcome`, `scheduled_instant`.

- `status='completed'` with empty `error` = clean run; a `no_agent` job with nothing to do still records `completed`.
- Rolling window (1000 rows observed) — old runs are pruned.
- Sort by `finished_at`, not `id`.

## `cron_incidents` columns

`id`, `job_id`, `error_sig` (dedupe key — one row per distinct error), `state`, `failure_type`, `first_seen_at`, `last_seen_at`, `acked_at`, `closed_at`, `error`, `output_file`, `alerted_at`.

- `state='alerted'` + `closed_at IS NULL` = **open** failure record.
- `state='resolved'` + `closed_at` set = fixed.
- Open rows are never auto-closed when a fix lands: compare `last_seen_at` against the job's recent successful runs, and report stale rows as bookkeeping rather than current failure.

## Verified queries

```sql
-- per-job run history (the core health line)
select job_id, status, count(*) n,
       min(started_at) first, max(finished_at) last
from executions group by job_id, status order by job_id, n desc;

-- tolerate nothing: non-clean runs
select job_id, status, started_at, finished_at, substr(coalesce(error,''),1,200) e
from executions
where status != 'completed' or (error is not null and error != '')
order by finished_at desc limit 20;

-- incidents, newest first
select id, job_id, state, failure_type, first_seen_at, last_seen_at, closed_at,
       substr(coalesce(error,''),1,300) e
from cron_incidents order by last_seen_at desc;

-- open only
select job_id, first_seen_at, last_seen_at, error from cron_incidents
where coalesce(state,'')='alerted' and closed_at is null;
```

Run them without a sqlite3 binary:

```bash
python3 -c "import sqlite3,json;c=sqlite3.connect(r'C:/Users/<user>/AppData/Local/hermes/cron/executions.db');c.row_factory=sqlite3.Row;print([dict(r) for r in c.execute('select * from cron_incidents')])"
```

## Delivering a verdict

Healthy = fresh heartbeat + only `completed` rows + fresh deliverable mtime. Failing = non-`completed` rows, or an open incident whose `last_seen_at` postdates the job's last success. Never-run = no output dir + `repeat.completed: 0` + `last_run_at: null`; treat an untested script as unproven until its safe half has been exercised.
