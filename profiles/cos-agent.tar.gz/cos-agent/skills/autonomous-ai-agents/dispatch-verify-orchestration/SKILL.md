---
name: dispatch-verify-orchestration
description: "Use when orchestrating weekly work across agent profiles: job health checks, task dispatch, independent output verification, correction loops."
version: 1.0.0
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [orchestration, delegation, verification, cron-health, chief-of-staff]
---

# Dispatch-and-Verify Orchestration (Weekly Loop)

Procedure for a chief-of-staff agent running one orchestration week over sibling
agent profiles: check scheduled jobs → dispatch → independently verify → correct
→ report. The orchestrator never does domain work itself.

## Invariants (every week)

- Orchestrator only checks, dispatches, verifies, corrects, reports.
- Every dispatch prompt names (a) exact output path, (b) acceptance criteria, (c) deadline.
- When a child must be READ-ONLY (mailbox, files, calendar), enforce it structurally, not by prompt: a
  profile's MCP servers can be kept from spawning at all with `hermes -p <profile> chat -t <toolset,list>`
  (the `-t` value doubles as the MCP spawn allowlist — `hermes_cli/mcp_startup.py`, `main.py`). A read-only
  run of the mailman profile looks like `-t file,terminal,code_execution,skills,outlook-local`, which leaves
  the mutating Graph `outlook` server (send/move/delete/calendar) and `google-workspace` never loaded.
- Prove the structural guarantee before the real run (dispatch a throwaway `-q` that lists its tool names;
  expect none from the excluded server) and audit the transcript afterwards (`--format stream-json` to a
  file, plus `agent.log`), grepping for the forbidden tool names and for the excluded server's registration
  line. Pair it with a pre/post read-only count of the folders that must not change.
- No child self-report is trusted — READ the artifact before scoring it. Verify by re-deriving the claim from an
  independent source of truth (a fresh read of the mailbox/file/API with your own probe), not by re-reading the
  child's own evidence files — a bug in the child's analysis is usually present in the evidence it produced.
- Design a dispatched one-shot's task to work from evidence files already on disk, not from live MCP tools: a
  child profile's MCP servers connect asynchronously (long connect timeouts, retry cooldown after a failed
  attempt), so a short run can expose only the built-in tools. That is a warm-up race, not a broken server —
  don't chase it, and don't build the task around tools that may not be loaded.
- Keep the bug-prone deterministic work (shell/COM extraction, parsing) with the orchestrator and dispatch the
  JUDGEMENT the child's role actually owns (classify, decide, author). When you split a plan that way, say so
  in the final report — an undisclosed split looks like the child did work it never touched.
- Never write into another profile's `cron/`, `skills/`, `plugins/`, or `memories/` without explicit direction.
- Never create new folders — destinations are Mars-pre-created or verified-existing paths.
- Standing rules: no email ever, read-only Outlook, life-coach profile untouched.

## Phase 1 — Job health check (start of week)

Run the 4-tier truth hierarchy over the default profile's cron jobs
(`$HERMES/cron/jobs.json` for definitions):

1. `cron/ticker_heartbeats.json` → scheduler alive? (age vs now)
2. `cron/executions.db` → real execution rows, last 7 days, per-job status counts + `cron_incidents` (open vs resolved)
3. `cron/output/<job_id>/` → did the script produce anything?
4. Artifact on disk → mtime + size + content fresh?

A job is healthy only if all four tiers agree. Triage:
- Tier 1 stale/frozen → whole week's evidence void; report "scheduler down"; no restart attempts without Mars.
- `last_status: ok` + no executions / stale artifact → false-green; dig in the execution log.
- Repeated errors + non-zero `failure_streak` → real defect. Classify: **environment defect** (missing dependency, bad path, scrubbed credential) = escalate to Mars, never fix credentials autonomously; **child-output defect** = correction loop (Phase 5).
- Record known-benign patterns (dispatch batching lateness ~50s, never-fired jobs awaiting first slot) so they aren't misread as faults.

## Phase 2 — Dispatch

One-shot per child, wrapper or `hermes -p <profile> chat -q "<task>"`:

```bash
hermes -p research-agent chat -q "Task... Output to: <exact path>. Acceptance criteria: <list>. Deadline: <time>."
hermes -p mailman chat -q "Task... Output to: <exact path>. Acceptance criteria: <list>. Deadline: <time>."
```

Set child deadlines ~1h after dispatch; batch independent dispatches in parallel.

## Phase 3 — Independent verification (next morning, per artifact)

Score each artifact against its acceptance criteria yourself:
1. `read_file` the artifact — content exists, non-trivial, matches the requested format.
2. Spot-check claims against ground truth (senders/subjects via Outlook read tools; citations via PubMed E-utilities / Crossref live lookups).
3. Verdict: PASS / FAIL with named defects + evidence (file, section, line).

## Phase 4 — Correction loop

Re-dispatch the failing child with a defect-naming prompt: specific defect +
evidence + required fix + re-test instruction. Keep the pre-correction artifact
as `.v1`. Re-verify yourself after the redo. **Two failed corrections on the
same defect → escalate to Mars instead of re-dispatching.**

## Phase 5 — Weekly report (end of week)

Write `<ISO-week>_weekly_orchestration_report.md` to the orchestrator's own
workspace: scheduled-jobs health table (with defects classified), dispatch
results + verification verdicts, corrections attempted/outcome, escalations.
Deliver in-session — never email. Separate child-output defects from
environment/scheduler defects in the escalation list.

## Escalation table

| Defect class | Examples | Route |
|---|---|---|
| Child output | missed AC, unverified citation, wrong format | correction loop (Phase 4), escalate after 2 failures |
| Environment | missing venv dependency, scrubbed credentials, missing folder | escalate to Mars immediately; take no send/credential action |
| Scheduler | ticker stale, 24h+ lateness, job never fired | report with evidence; confirm against next run before calling broken |
