# "Last word is theirs" — detecting conversations with no reply

The deterministic core of an unanswered-mail audit. Everything else is orchestration around this rule.

## The rule

1. Load every in-window message: each store's Inbox **subtree** (inbound) plus each store's Sent Items
   (outbound). A reply lands in Sent Items no matter which folder the inbound message was filed into.
2. Group into conversations by Exchange `ConversationID`. When it is empty (senders outside Exchange),
   fall back to a normalised topic key — lowercase, whitespace-collapsed, `Re:`/`FW:`/`Fwd:` stripped — and
   mark that row `exact_grouping=false` so the weaker grouping is visible downstream.
3. Sort each conversation by timestamp. If the **newest** message is inbound, nothing outbound follows it:
   the last word is theirs. That conversation is a candidate.
4. For each candidate record: the newest inbound message (the one being reported),
   `my_last_reply` (timestamp of the newest outbound, empty if none), `unanswered_count` (inbound messages
   strictly after `my_last_reply`), `thread_len`, and the folder/store it lives in.

Using the newest message rather than "any unanswered question in the thread" is what keeps the output a
list of live decisions instead of a history lesson. `thread_len` and `unanswered_count` let the reader see
whether a row is a one-shot ask or a thread they went quiet inside.

## Noise filters — drop, but never silently

Every dropped row is written to a companion file with its reason and shipped alongside the report. A filter
bug that deletes a real question is this workflow's worst outcome; an excluded row the user can see is a
minor annoyance.

| Reason | Test |
|---|---|
| `not-in-inbox-subtree` | no unanswered inbound inside the Inbox subtree (e.g. only outbound is unanswered) |
| `from-yourself` | sender SMTP in the user's own addresses, or sender display-name tokens ⊆ owner-name tokens |
| `calendar` | `MessageClass` matching `IPM.Schedule.Meeting*`, or an acceptance/invitation/updated-invitation subject |
| `auto/ooo` | `automatic reply`, `out of office`, `undeliverable`, `delivery status`, `returned mail` subjects |
| `automated-sender` | local-part/domain patterns: `no-reply`, `noreply`, `donotreply`, `notifications@`, `alerts@`, `service@`, `insider@`, `communications@`, `trainingregistration@`, plus known platform domains |
| `bulk-domain` | senders on the organisation's bulk-sending subdomain (verify it first — see below) |
| `bulk-header` | transport-header evidence: `list-unsubscribe`, `list-id`, `feedback-id`, `precedence: bulk`, campaign headers |
| `newsletter` | body contains `unsubscribe` / `email preferences` (backstop only) |

Derive the bulk-domain rule from evidence, not assumption: list the senders that the header rule already
catches and look for a shared subdomain (a `*.com.<org>` style marketing subdomain is common). Confirm it
has no human senders in the sample before adopting it, state it as a limitation in the report, and keep
`bulk-header` (header evidence) as the primary signal — headers are universal, the domain rule is local.

## Tiers (pre-labels only; the judgement pass decides)

- **A** — addressed directly to the user (`To` matches one of their addresses) and carries an ask signal.
- **B** — cc-only, or no ask signal detected.

Direct-vs-cc requires resolved SMTP on recipients (see `references/outlook-com-recipe.md` §2) — with X500
values this test returns false for everything and every row lands in B. Treat the regex ask-signal as a
ranking hint only: marketing copy is full of question marks, so tiers must never be used as the exclusion
mechanism. The model's `needs_response` decides, and tiering only orders the batches.

## Judgement pass

Batches of ~25 rows, each returning a JSON array in the same order with one object per row and every
`conv_key` present exactly once. Keep the schema tiny and data-only:
`{conv_key, needs_response, urgency, what_they_want, reason}`.

Prompt rules that measurably change the output:

- `true` only when a specific person plausibly waits on the user personally — a question, request, approval,
  feedback, availability, a decision, a document, a hand-off.
- `false` for mass mail, announcements, marketing, system/automation messages (task-assignment notices,
  ticket notifications, licence or registration instructions, receipts), event invitations, and mail where
  the user is one of many recipients. The reason must name which.
- `"unknown"` when the body snippet is empty or too truncated to tell — never guess.
- Give 5-6 calibration examples taken from the user's own mailbox, including one deliberately misleading
  case (`Mars, can you do me a favor?` from a cold vendor) and one system message. Without these, a model
  treats anything with a question mark as a personal ask.

Sections in the deliverable follow the judgement: A = needs a reply, B = uncertain / cc-only, C = reviewed
and no reply needed (with the model's reason — this is what makes the audit trustworthy), E = not judged.

## False positives to disclose, always

1. A reply sent from a phone, Teams, web Outlook on another account, or in person is invisible here.
2. A brand-new thread reusing a subject can split or merge a conversation (visible via `exact_grouping=false`).
3. Deliberately unanswered mail is indistinguishable from forgotten mail.
4. The user may be only cc'd on distribution mail that still expects an action.
5. Mail sent to himself appears as an unanswered inbound thread.
6. A sender-domain bulk rule can hide a real question from a shared departmental mailbox.
