# Outlook classic COM recipe (read-only extraction)

Exact idioms for driving a *running* classic Outlook profile from PowerShell, and the failures that
look like data problems but are language/COM problems. Everything here reads; nothing writes.

## 0. Attach, and treat a blank version as a hard stop

```powershell
$ErrorActionPreference = 'Continue'   # per-item try/catch beats one bad item killing the run
try { $ol = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
catch { Write-Output ('OUTLOOK_UNAVAILABLE: ' + $_.Exception.Message); exit 1 }
$ns = $ol.GetNamespace('MAPI')
Write-Output ('OUTLOOK_VERSION=' + $ol.Version)   # blank => a modal dialog is blocking COM
```

`$ol.Version` blank/empty means a dialog is up. Output the version as the first act so a later oddity is
traceable to a blocked COM session rather than to your logic. Print a per-folder `Items.Count` baseline
before extracting, so "we found nothing" is always distinguishable from "we never looked".

## 1. Never read a COM property inside a method-call argument list

This silently produces an EMPTY value, not an error:

```powershell
# BROKEN: every pushed path came back as "Inbox/" -- the folder name vanished
$stack.Push(@($child, "$parentPath/" + $child.Name))
```

```powershell
# WORKING: assemble into plain variables, then push an explicitly built object[]
$cn = ''; try { $cn = [string]$child.Name } catch {}
if (-not $cn) { try { $cn = [string]$child.FolderPath } catch {} }   # fallback
$childPath = $parentPath + '/' + $cn
$entry = New-Object object[] 2
$entry[0] = $child; $entry[1] = $childPath
$stack.Push($entry)
```

The identical concatenation assigned to a variable first works; the same expression as a call argument
does not. Build paths in variables, always, and include a `FolderPath` fallback plus a visible default
(`'(unnamed)'`) so a lost name is loud instead of blank.

## 2. Senders and recipients: `.Address` is an X500 DN on Exchange

`.Address` returns `/o=ExchangeLabs/ou=Exchange Administrative Group/.../cn=...` for internal people, so
comparing it against an SMTP address never matches. Resolve SMTP in this order:

```powershell
$PR_SMTP = 'http://schemas.microsoft.com/mapi/proptag/0x39FE001E'   # PR_SMTP_ADDRESS

function Get-Smtp([object]$m) {
  $s = ''
  try { $s = [string]$m.SenderEmailAddress } catch {}
  if ((-not $s) -or ([string]$m.SenderEmailType -eq 'EX')) {
    try { $pa = [string]$m.Sender.PropertyAccessor.GetProperty($PR_SMTP); if ($pa) { $s = $pa } } catch {}
  }
  if ((-not $s) -or $s.StartsWith('/')) {                              # still an X500 DN
    try { $ex = [string]$m.Sender.AddressEntry.GetExchangeUser().PrimarySmtpAddress; if ($ex) { $s = $ex } } catch {}
  }
  if ((-not $s) -or $s.StartsWith('/')) {                              # last resort: a human-readable name
    try { $n = [string]$m.SenderName; if ($n) { $s = $n } } catch {}
  }
  return $s
}

function Get-Recip([object]$m, [int]$type) {   # 1 = To, 2 = CC, 3 = BCC
  $out = @()
  foreach ($r in @($m.Recipients)) {
    $t = -1; try { $t = [int]$r.Type } catch {}
    if ($t -ne $type) { continue }
    $addr = ''
    try { $addr = [string]$r.PropertyAccessor.GetProperty($PR_SMTP) } catch {}
    if (-not $addr) { try { $addr = [string]$r.AddressEntry.GetExchangeUser().PrimarySmtpAddress } catch {} }
    if (-not $addr) { try { $addr = [string]$r.Address } catch {} }
    if (-not $addr) { try { $addr = [string]$r.Name } catch {} }
    if ($addr) { $out += $addr }
  }
  return ($out -join ';')
}
```

Why it matters: with X500 values, "is the user in the To list" is false for every message, so a
To-vs-CC distinction silently collapses and every candidate looks cc-only. Also collect the user's own
addresses from `$ns.Accounts` (`.SmtpAddress`) and from Sent-Items senders; add a display-name token
fallback for self-sent mail (sender name tokens ⊆ owner-name tokens from `$ns.CurrentUser.Name`).

## 3. Date windows: sort newest-first, stop with a tolerance window

`Items.Restrict` with a date range has been unreliable on this build and returns an empty set that reads
as "no mail in the window" — the most dangerous possible failure. Iterate instead:

```powershell
$items = $folder.Items
$sortOk = $false
try { $items.Sort('[ReceivedTime]', $true); $sortOk = $true } catch {}   # $true = descending
$kept = 0; $old = 0; $first = ''
foreach ($m in $items) {
  $when = $null; try { $when = [datetime]$m.ReceivedTime } catch {}
  if ($when -eq $null) { continue }
  if (-not $first) { $first = $when.ToString('yyyy-MM-dd') }
  if ($when -lt $cutoff) {
    if ($sortOk) { $old++; if ($old -ge 50) { break } }   # tolerance: never trust the sort fully
    continue
  }
  $old = 0
  $mc = ''; try { $mc = [string]$m.MessageClass } catch {}
  if ($mc -and $mc -notlike 'IPM.Note*' -and $mc -notlike 'IPM.Schedule.Meeting*') { continue }
  # ... emit record
  $kept++
}
```

Emit one log line per folder — `ITEMS=<folder.Items.Count>|IN_WINDOW=<kept>|SORT=DESC|FIRST=<date>` —
and set `SORT=NOSORT` when the try/catch fell through. `ITEMS` large with `IN_WINDOW=0`, or a `FIRST` date
far in the past, is the visible signature of a filter/sort failure. Sent Items needs `[SentOn]` rather than
`[ReceivedTime]`.

## 4. Message bodies: `Body` is often empty on Outlook-composed mail

```powershell
$b = ''; try { $b = [string]$m.Body } catch {}
if (-not $b) { try { $h = [string]$m.HTMLBody; if ($h) { $b = [regex]::Replace($h, '<[^>]+>', ' ') } } catch {} }
$b = $b -replace "`r",' ' -replace "`n",' ' -replace "`t",' '
$b = ([regex]::Replace($b, '\s{2,}', ' ')).Trim()
```

Cap the snippet (~1200 chars) — it keeps the evidence file small and is plenty for classification.

## 5. Bulk-mail evidence: read the transport headers

Mass mail carries list/campaign headers that no subject or body heuristic matches as reliably.
`PR_TRANSPORT_MESSAGE_HEADERS = 0x007D001E` returns the RFC822 header block:

```powershell
$PR_HDRS = 'http://schemas.microsoft.com/mapi/proptag/0x007D001E'
$h = ''; try { $h = [string]$m.PropertyAccessor.GetProperty($PR_HDRS) } catch {}
$ev = @()
foreach ($raw in ($h -split "`r?`n")) {
  $line = ''; try { $line = $raw.Trim().ToLower() } catch {}
  if ($line.Length -eq 0) { continue }
  if ($line.StartsWith('list-unsubscribe')) { $ev += 'list-unsubscribe' }
  elseif ($line.StartsWith('list-id'))      { $ev += 'list-id' }
  elseif ($line.StartsWith('feedback-id'))  { $ev += 'feedback-id' }
  elseif ($line.StartsWith('precedence:') -and $line.Contains('bulk')) { $ev += 'precedence-bulk' }
  else { foreach ($c in @('x-mailchimp','x-cmail','x-sfmc','x-constantcontact','x-campaign','x-hubspot','x-sendgrid')) {
           if ($line.StartsWith($c)) { $ev += 'campaign-header'; break } } }
}
$evidence = ($ev -join ',')
```

Note the escape-free style: `StartsWith`/`Contains` instead of a regex with `\s`/`^` in it. See §7 for why.

## 6. The read-only proof

Before and after the run, record `Items.Count` per store for Inbox, Sent Items, Drafts, Deleted Items,
Outbox, Junk Email and Calendar, and diff them. Calendar/Sent/Drafts/Deleted/Junk equal ⇒ no send, no move,
no delete, no calendar change. Structural tool gating plus this count diff is what makes the "read-only"
claim verifiable instead of asserted.

## 7. Generating script files programmatically

When a script is emitted by another tool (a heredoc, a generator, a template), the quoting layers compose:
a backslash that survives one layer can be doubled by the next and turn `\s` into a literal `\\s` in the
file, which silently makes a regex filter match nothing. Two rules:

1. Prefer constructs with no backslashes at all (`.StartsWith()`, `.Contains()`, `-split` on a
   backtick-escaped newline). Where a regex is unavoidable, verify the bytes actually written
   (`repr()` of the line, or a backslash count) rather than trusting the escaping.
2. Always syntax-check a generated script BEFORE running it — it costs a second:

```bash
powershell -NoProfile -Command "\$e=@(); [void][System.Management.Automation.Language.Parser]::ParseFile('<abs path>',[ref]\$null,[ref]\$e); if(\$e.Count){\$e|ForEach-Object{'ERR: ' + \$_.Message + ' @line ' + \$_.Extent.StartLineNumber}}else{'PARSE_OK'}"
```

## 8. Folder walk: Inbox AND its subfolders

Mail gets filed into topic subfolders, so an audit of "my inbox" that reads only the Inbox top level
misses exactly the mail the user cared enough to file. Walk the whole Inbox subtree (stack of
`(folder, path)` pairs, recursing `folder.Folders`) plus each store's `Sent Items`, since a reply lands in
Sent Items regardless of which folder the inbound message sits in.
