---
name: outlook-mailbox-audit
description: "Use when auditing an Outlook mailbox window read-only."
version: 1.0.1
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [outlook, outlook-classic, com, powershell, mailbox-audit, read-only, unanswered]
    related_skills: [email-inbox-triage, dispatch-verify-orchestration]
---

# Outlook Mailbox Audit (read-only, window-based)

Answers historical mailbox questions by mining a date window rather than reading today's mail: "which
messages never got a reply from me?", "what is still waiting on me?", "how long do I take to answer X?"
This is the Outlook-classic connector for `email-inbox-triage` and owns the audit deliverable shape;
that skill owns per-thread dispositions and reply policy for current mail.

## When to Use

- "Examine my inbox for the last N days and tell me what I never responded to."
- Follow-up-debt and response-latency audits; per-sender or per-folder response analysis.
- Any read-only bulk extraction from a *running* classic Outlook profile: the OST stays locked while
  Outlook is open, so COM is the surface (file-level OST parsing needs Outlook fully closed).

Don't use for: sending, filing, rules, or calendar work — those are different tasks with different gates.

## Standing rules (do not relitigate)

- **Outlook is READ-ONLY.** Never send, reply, reply-all, forward or create a draft; never move, copy,
  archive, delete, junk, categorise, flag or mark a message read; never create/copy/update/delete a
  calendar item; never create, rename, move or delete a folder or rule. The deliverable is a **file**,
  never an email.
- **Never create a folder.** Deliver to a path the user names or one verified to exist; keep scratch and
  evidence as flat files in the profile's existing `cache/scratch`.
- **The model supplies DATA, a script owns the NUMBERS.** The judging model returns JSON judgements only;
  a deterministic renderer builds every table and count, so the report cannot drift from the evidence.
- **Confirm scope before a long run** — which stores, Inbox-subtree vs Inbox-only, output format, exact
  output path. Ask only the questions whose answers change the deliverable; decide the rest yourself.
- **Disclose limitations and any deviation from the approved plan** in the final report.

## Procedure

### 0. Readiness gate (blocking)
`mcp__outlook_local__outlook_status` must report `available: true`; `list_mailboxes` gives the default
store plus any shared/delegated stores — report those separately, and if a store received nothing inside
the window, say so rather than implying it was clean. Unavailable → tell the user to open classic Outlook
and clear pending dialogs, then stop; do not retry in a loop.
Resolve the dispatch model before a long run, e.g.
`hermes -p <profile> chat -Q --provider nous -m z-ai/glm-5.3:US --reasoning high -t file -q "Reply with exactly: MODEL_OK"`.

### 1. Baseline counts — this is the read-only proof
Run the dump script with `-BaselineOnly`. It prints `COUNT|<store>|<folder>|<n>` for Inbox, Sent Items,
Drafts, Deleted Items, Outbox, Junk Email, Calendar plus every Inbox-subtree folder, and writes a JSON
baseline. Keep it: the post-run comparison is the evidence that nothing was sent, moved, read or flagged.
Drafts/Sent/Deleted/Junk/Calendar must be identical afterwards (the Inbox may legitimately grow).

### 2. Canary on 7 days BEFORE the real window
Run the dump with `-Days 7` to a scratch `-OutRoot`, then the analyser over it. Gates:

- Every `FOLDER|` line shows a real folder path (not bare `Inbox/`), `SORT=DESC`, and a `FIRST=` date near today.
- A folder reporting `ITEMS=432|IN_WINDOW=0` means a broken date filter or failed sort — never an empty window.
- Eyeball the residual candidates: bulk/newsletter mail sitting in the top tier means the filters are too loose.

This gate is not optional. Every real defect in this pipeline surfaced in a 7-day canary, not in the
full-window run, and each one would have silently corrupted the final list.

### 3. Full-window extraction
Dump the window (120 days unless told otherwise) to the scratch dir and tee the console log to a coverage
file. Per-folder `ITEMS` vs `IN_WINDOW` goes into the deliverable as proof of scan scope.

### 4. Analyse (deterministic)
Group messages into conversations and flag "the last word is theirs". Rule, noise filters, tier design and
the false-positive classes to disclose: `references/unanswered-detection.md`.
Write every dropped row to a companion file with a reason; a filter that silently deletes a real question
is this workflow's worst failure mode, so exclusions must be auditable and shipped with the report.

### 5. Slice and judge
Slice candidates into batches of ~25 and have the judging model return **only** a JSON array per batch:
`{conv_key, needs_response: true|false|"unknown", urgency, what_they_want, reason}`. State in the prompt:
use only the row's own fields; never invent facts, dates or names; `false` for mass mail, announcements,
system notifications and group-cc mail; `"unknown"` when the snippet is too short to tell; every `conv_key`
exactly once, same order, no merging or summarising. Include 5-6 calibration examples drawn from the
user's own mailbox — without them a model treats marketing copy containing a question mark as a personal ask.

### 6. Render, then verify before reporting
Render with the deterministic script (report + main CSV + excluded CSV). Then:

- Re-run the analyser and confirm identical counts (determinism).
- Confirm `UNJUDGED=0` and that the declared CSV row count equals the file's actual row count.
- Run the post-run baseline comparison; report any non-Inbox difference loudly as a defect.
- Re-derive 3-5 sampled conversations straight from Outlook with `scripts/verify_conversations.ps1` —
  a fresh COM read of ground truth, never the pipeline's own evidence files.

See `scripts/probe_outlook_com.ps1` for the 30-second COM sanity probe to run before writing any export.

### 7. Deliver
Report inline: headline counts, the oldest / highest-urgency items, the safety evidence (count
comparison, structural tool gate), and the limitations. Attach the files. Never email them.

## Pitfalls

Mechanics with exact snippets: `references/outlook-com-recipe.md`.

- Reading a COM property *inside a method-call argument list* silently yields empty
  (`$stack.Push(@($f, "$p/" + $f.Name))` lost every folder name). Build the string in a variable first and
  push an explicit `object[]`.
- `.Address` on an Exchange recipient/sender is an X500 DN, not an SMTP address; resolve SMTP explicitly or
  "was this addressed to me" matching fails and every row silently degrades to cc-only.
- Don't build date-window selection on `Items.Restrict` here; sort newest-first and stop after N consecutive
  out-of-window items, and log the sort mode so a truncation is visible rather than plausible.
- Generating a script through nested quoting layers (heredoc → `.ps1`) silently doubles regex backslashes,
  which turns a filter into a no-op. Prefer escape-free constructs (`.StartsWith()` line checks), and always
  run the PowerShell Parser syntax check before executing a generated script.
- MCP `search_emails` cannot reach old mail in a large folder — paging stalls at the scan budget, so a zero
  result there is an unfinished search. Verify old threads with a fresh COM walk instead.
- Attachment contents are never read; record filenames only.

## Verification checklist

- [ ] Readiness gate passed against the live profile; scope and output path confirmed.
- [ ] 7-day canary passed every gate before the full run.
- [ ] Excluded rows shipped with reasons, and per-reason counts stated in the report.
- [ ] `UNJUDGED=0`; CSV row count equals the declared total.
- [ ] Post-run Drafts/Sent/Deleted/Junk/Calendar counts identical to baseline.
- [ ] 3-5 conversations re-derived from ground truth, not from the pipeline's own files.
- [ ] Limitations stated: cross-client replies invisible, topic-fallback grouping, deliberate silence,
      cc'd distribution mail, self-sent mail.
