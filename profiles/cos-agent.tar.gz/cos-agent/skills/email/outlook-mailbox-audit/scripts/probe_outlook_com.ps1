# probe_outlook_com.ps1 -- READ-ONLY sanity probe before writing any Outlook COM export.
# Confirms the four idioms that fail SILENTLY on this host: folder names, sender/recipient SMTP,
# newest-first sort, and transport-header bulk evidence. Nothing is opened, moved or modified.
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File probe_outlook_com.ps1
$ErrorActionPreference = 'Continue'
try { $ol = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
catch { Write-Output ('OUTLOOK_UNAVAILABLE: ' + $_.Exception.Message); exit 1 }
$ns = $ol.GetNamespace('MAPI')
$PR_SMTP = 'http://schemas.microsoft.com/mapi/proptag/0x39FE001E'
$PR_HDRS = 'http://schemas.microsoft.com/mapi/proptag/0x007D001E'
Write-Output ('VERSION=' + $ol.Version + '   (blank => a modal dialog is blocking COM: stop)')

$store = $ns.DefaultStore
Write-Output ('DEFAULT_STORE=' + $store.DisplayName)
$root = $store.GetRootFolder()
$inbox = $null
foreach ($f in @($root.Folders)) { if ([string]$f.Name -eq 'Inbox') { $inbox = $f } }
if (-not $inbox) { Write-Output 'NO_INBOX'; exit 1 }

Write-Output '--- 1. child folder NAMES (must NOT be empty) ---'
$i = 0
foreach ($c in @($inbox.Folders)) {
  $i++; if ($i -gt 5) { break }
  $nm = ''; try { $nm = [string]$c.Name } catch {}
  $cnt = '?'; try { $cnt = [string]$c.Items.Count } catch {}
  Write-Output ("  name='$nm' items=$cnt")
}

Write-Output '--- 2. newest-first walk (SORT=DESC and FIRST near today) ---'
$items = $inbox.Items
$sortOk = $false
try { $items.Sort('[ReceivedTime]', $true); $sortOk = $true } catch {}
$first = ''; $n = 0
foreach ($m in $items) {
  $n++; if ($n -gt 3) { break }
  $when = ''; try { $when = ([datetime]$m.ReceivedTime).ToString('yyyy-MM-dd HH:mm') } catch {}
  if (-not $first) { $first = $when }
  $s = ''; try { $s = [string]$m.Subject } catch {}
  Write-Output ("  $when  " + $s.Substring(0, [Math]::Min(64, $s.Length)))
}
$sortTxt = 'NOSORT'; if ($sortOk) { $sortTxt = 'DESC' }
Write-Output ("  SORT=$sortTxt FIRST=$first")

Write-Output '--- 3. sender/recipient SMTP (must be an address, not /o=ExchangeLabs...) ---'
$n = 0
foreach ($m in $items) {
  $n++; if ($n -gt 2) { break }
  $sn = ''; try { $sn = [string]$m.SenderName } catch {}
  $ss = ''; try { $ss = [string]$m.SenderEmailAddress } catch {}
  if ((-not $ss) -or $ss.StartsWith('/')) {
    try { $pa = [string]$m.Sender.PropertyAccessor.GetProperty($PR_SMTP); if ($pa) { $ss = $pa } } catch {}
  }
  Write-Output ("  sender name='$sn' smtp='$ss'")
  foreach ($r in @($m.Recipients)) {
    $ra = ''
    try { $ra = [string]$r.PropertyAccessor.GetProperty($PR_SMTP) } catch {}
    if (-not $ra) { try { $ra = [string]$r.Name } catch {} }
    $t = -1; try { $t = [int]$r.Type } catch {}
    Write-Output ("    recip type=$t smtp='$ra'")
  }
}

Write-Output '--- 4. transport-header bulk evidence ---'
$n = 0
foreach ($m in $items) {
  $n++; if ($n -gt 8) { break }
  $h = ''; try { $h = [string]$m.PropertyAccessor.GetProperty($PR_HDRS) } catch {}
  $ev = @()
  foreach ($raw in ($h -split "`r?`n")) {
    $line = ''; try { $line = $raw.Trim().ToLower() } catch {}
    if ($line.Length -eq 0) { continue }
    if ($line.StartsWith('list-unsubscribe')) { $ev += 'list-unsubscribe' }
    elseif ($line.StartsWith('list-id')) { $ev += 'list-id' }
    elseif ($line.StartsWith('feedback-id')) { $ev += 'feedback-id' }
    elseif ($line.StartsWith('precedence:') -and $line.Contains('bulk')) { $ev += 'precedence-bulk' }
  }
  $s = ''; try { $s = [string]$m.Subject } catch {}
  Write-Output ("  [" + ($ev -join ',') + '] ' + $s.Substring(0, [Math]::Min(56, $s.Length)))
}
Write-Output 'PROBE_DONE'
