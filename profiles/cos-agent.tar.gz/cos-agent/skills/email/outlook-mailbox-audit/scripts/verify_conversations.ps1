# verify_conversations.ps1 -- INDEPENDENT re-read of sampled conversations straight from Outlook.
# Purpose: check the audit's core claim ("the newest message in this conversation is inbound, with no
# reply from the user after it") against live ground truth, NOT against the pipeline's own evidence files.
# A bug in the pipeline's analysis is usually present in the evidence it produced, so re-reading that
# proves nothing -- this script queries the mailbox fresh. READ-ONLY: walks folders, reads properties.
#
# Usage:
#   echo <ConversationID> > ids.txt   (one per line; seed from the conv_key column, strip the 'cid:' prefix)
#   powershell -NoProfile -ExecutionPolicy Bypass -File verify_conversations.ps1 -IdFile <abs path> -Days 120
# Then compare each conversation's newest HIT date+folder against the row you are checking: the newest
# must be in an Inbox folder (not Sent Items), and its timestamp must equal last_inbound.
param(
  [Parameter(Mandatory=$true)][string]$IdFile,
  [int]$Days = 120
)
$ErrorActionPreference = 'Continue'
$cutoff = (Get-Date).AddDays(-$Days)
try { $ol = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
catch { Write-Output ('OUTLOOK_UNAVAILABLE: ' + $_.Exception.Message); exit 1 }
$ns = $ol.GetNamespace('MAPI')

$want = @{}
foreach ($line in [System.IO.File]::ReadAllLines($IdFile)) {
  $v = $line.Trim().ToLower()
  if ($v) { $want[$v] = $true }
}
Write-Output ('SAMPLED=' + $want.Count)

function Find-Child([object]$root, [string]$name) {
  foreach ($f in @($root.Folders)) {
    $n = ''; try { $n = [string]$f.Name } catch {}
    if ($n -eq $name) { return $f }
  }
  return $null
}

$hits = 0
foreach ($store in @($ns.Stores)) {
  $sname = ''; try { $sname = [string]$store.DisplayName } catch {}
  $root = $store.GetRootFolder()
  $targets = New-Object System.Collections.ArrayList

  $inboxRoot = Find-Child $root 'Inbox'
  if ($inboxRoot) {
    $stack = New-Object System.Collections.Stack
    $e0 = New-Object object[] 2; $e0[0] = $inboxRoot; $e0[1] = 'Inbox'
    $stack.Push($e0)
    while ($stack.Count -gt 0) {
      $pair = $stack.Pop(); $folder = $pair[0]; $fpath = $pair[1]
      $en = New-Object object[] 2; $en[0] = $folder; $en[1] = $fpath
      [void]$targets.Add($en)
      foreach ($c in @($folder.Folders)) {
        $cn = ''; try { $cn = [string]$c.Name } catch {}
        $cp = $fpath + '/' + $cn
        $e = New-Object object[] 2; $e[0] = $c; $e[1] = $cp
        $stack.Push($e)
      }
    }
  }
  $sentF = Find-Child $root 'Sent Items'
  if ($sentF) {
    $es = New-Object object[] 2; $es[0] = $sentF; $es[1] = 'Sent Items'
    [void]$targets.Add($es)
  }

  foreach ($t in $targets) {
    $folder = $t[0]; $fpath = $t[1]
    $items = $folder.Items
    $sorted = $false
    try { $items.Sort('[ReceivedTime]', $true); $sorted = $true } catch {}
    $old = 0
    foreach ($m in $items) {
      $when = $null
      try { $when = [datetime]$m.ReceivedTime } catch {}
      if ($when -eq $null) { continue }
      if ($when -lt $cutoff) { if ($sorted) { $old++; if ($old -ge 200) { break } }; continue }
      $old = 0
      $cid = ''
      try { $cid = ([string]$m.ConversationID).Trim().ToLower() } catch {}
      if (-not $cid) { continue }
      if (-not $want.ContainsKey($cid)) { continue }
      $hits++
      $sn = ''; try { $sn = [string]$m.SenderName } catch {}
      $subj = ''; try { $subj = [string]$m.Subject } catch {}
      Write-Output ("HIT|$cid|$sname|$fpath|" + $when.ToString('yyyy-MM-dd HH:mm') + "|$sn|$subj")
    }
  }
}
Write-Output ('HITS=' + $hits)
Write-Output 'VERIFY_DONE'
