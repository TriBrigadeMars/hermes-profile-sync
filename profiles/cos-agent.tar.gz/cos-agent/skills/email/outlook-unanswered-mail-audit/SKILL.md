---
name: outlook-unanswered-mail-audit
description: "Use when auditing Outlook classic for unanswered mail."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [outlook, com, powershell, mail-audit, read-only, verification]
---

# Unanswered-Mail Audit (Outlook classic, read-only)

Answer "which conversations have, as their newest message, a message from someone else with no reply
from the user after it — and which of those still need a reply?" without writing to the mailbox.

## When to Use

- The user asks who is still waiting on a reply, or wants a list of mail they never answered.
- A repeatable inbox audit over a date window is wanted (e.g. "the last 120 days").
- The work must be read-only: no send, no move, no calendar touch, no mark-read.
- The user is setting boundaries for mailbox work for the first time (scope, forbidden operations, proof).

## Pipeline (four deterministic stages; the LLM only classifies)

1. **Dump** (PowerShell + Outlook COM, read-only): walk the Inbox subtree + Sent Items of the in-scope
   store(s) newest-first, write JSONL, and write a per-folder item-count baseline for the safety proof.
2. **Candidates** (stdlib Python): group by Exchange `ConversationID` (fallback: normalised
   `ConversationTopic`, flag those rows `exact_grouping=false`); a conversation whose LAST message is
   inbound is a candidate. Deterministic filters then drop mail nobody answers personally — and every
   dropped row goes to an excluded file WITH its reason, never silently.
3. **Judge**: an agent reads each candidate batch (25 rows: sender, subject, dates, 600-char body snippet)
   and writes judgements as a JSON **data** file — `needs_response`, `urgency`, `what_they_want`, `reason` —
   never prose, and never by opening the mailbox.
4. **Render**: a script owns every count, table and CSV row, so the report cannot drift from the evidence.
   The model's output is data; layout is code.

Batch the judgement work so it is resumable: one judgement file per batch, re-render incrementally, and
skip batches whose judgement file already exists on a re-dispatch.

## COM pitfalls that cost real time (all verified on this host)

- **Never read a COM property inside a method-call argument list.** `$stack.Push(@($f, "$p/" + $f.Name))`
  silently yields `"p/"` — the name comes back empty — while the identical concatenation assigned to a
  variable first works fine. Assemble the string in variables, then push an explicit
  `New-Object object[] 2`.
- **Recipients' `.Address` is an X500 DN, not an SMTP address.** Resolve with `PropertyAccessor` tag
  `0x39FE001E` (fallback `AddressEntry.GetExchangeUser().PrimarySmtpAddress`, then `.Name`). Skip this and
  "was this addressed to me directly?" can never be decided — every row silently falls to the low tier.
  Senders need the identical fallback chain, or the sender comes out as a `/o=ExchangeLabs/...` blob.
- `Items.Restrict` is unreliable on this build: iterate items and compare dates in PowerShell instead. Sort
  descending and break at the cutoff only after N consecutive out-of-window items, so a partially ordered
  folder cannot truncate the window. Log the first-seen date per folder so a wrong sort order is visible.
- `$m.Body` is often empty for Outlook-composed mail — fall back to `HTMLBody` with tags stripped.
- Read a baseline item count as the first act, and print `ITEMS=n` beside `IN_WINDOW=m` for every folder:
  that pairing is what exposes a broken date filter or a partial walk.

## Filters worth having (and one that isn't)

- Strongest bulk signal is the **transport header** (`PropertyAccessor` tag `0x007D001E`):
  `List-Unsubscribe`, `List-Id`, `Precedence: bulk`, `X-*` campaign headers. Body-text "unsubscribe"
  scans are far weaker.
- A **bulk-sending subdomain** rule (`*@com.<university>.edu` style mail-marketing hosts) catches what
  headers miss — verify it against the real sender list before trusting it, and keep every dropped row
  auditable.
- Auto-generated addresses (`noreply@`, `notifications@`, `service@`, `no-reply@`) plus subject prefixes
  (`Accepted:`, `Automatic reply:`, `Undeliverable`) account for most of the remaining noise.
- A regex "did they ask a question?" signal is NOT a filter — mass mail is full of question marks and
  request verbs. Use it for ranking only, and let the judgement pass decide.
- Mail sent by the user to himself arrives as inbound; detect it by "sender is in the user's own address
  set" and by name-token matching against the mailbox owner's display name.

## Boundaries (standing rules for this work)

- Scope to the **default store only** unless the user says otherwise; never open another mailbox. Encode the
  scope in the extractor (a `-DefaultStoreOnly` switch) and prove it in the baseline output
  (`stores_walked`), not just in the prompt.
- No send / reply / draft / forward, no move / copy / archive / delete / junk / categorise / flag /
  mark-read, no calendar touch, no folder or rule changes, no attachment opened.
- **Enforce structurally, not by prompt:** `hermes chat -t/--toolsets` doubles as the MCP spawn allowlist, so
  `-t file,terminal,code_execution,skills,outlook-local` means the mutating Graph `outlook` server
  (send/draft/move/delete/archive/calendar) is never spawned. Prove it twice: have the child list its tool
  names before the real run, then grep the streamed transcript and `agent.log` for the forbidden names and
  for the excluded server's registration line.
- One-shot children cannot use `execute_code` (BLOCKED — no user to approve) and are killed mid-run by
  lifecycle cleanup unless launched with `persist_on_release=true`. Pre-write every helper script for them.
- Run a 7-day canary of the whole chain and eyeball the rows BEFORE the full window: a regex-tiered candidate
  list looks plausible in aggregate and obviously wrong row by row.

## Verification battery (every run; the child's self-report is not evidence)

1. Read the deliverable files yourself; the CSV row count must equal the candidate count and `UNJUDGED` must
   be 0, with no duplicate judgement keys.
2. Pre/post item counts identical for Drafts / Sent Items / Deleted Items / Junk / Calendar. Top-level Inbox
   drifts with live mail — label that "live mail, not a safety signal" instead of reporting it as a breach.
3. Grep the transcript for forbidden tool names and for mutations of the excluded server.
4. Re-derive a few sampled threads from the live mailbox with an INDEPENDENT script and compare the newest
   message's direction, date and folder against the row. Use the MCP read tools only for recent mail:
   `search_emails` over an old window returns `coverage.exhausted=false` with `stop_reason=time_budget`,
   which is an unfinished search, not proof of absence.
5. Recall self-check: list candidates that are direct-to-user, contain a question mark, yet were judged
   "no reply needed"; require a written justification or a flip for each.
6. Keep pre-correction artifacts as `.v1` and diff the passes — on a redo, report which calls actually
   flipped and why, not just the new totals.

Cosmetic drift worth knowing: a renderer run BEFORE the post-baseline step prints "evidence file not found"
where the safety table belongs, and a wrong "default store" guess (dict ordering) can emit every row under
"outside the default store". Re-render after the last evidence file exists, and pass the default store name
in explicitly.
