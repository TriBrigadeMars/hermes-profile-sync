#!/usr/bin/env python3
"""Check OA status of DOIs via OpenAlex batch API.

Usage:
  python openalex_oa_check.py dois.json [--out result.json]

dois.json: JSON list of DOI strings ("10.xxxx/yyyy").
Prints per-DOI: is_oa, oa_status, pdf_url (best_oa_location), landing URL.

Notes:
  - Batch <= 25 DOIs per request; 50 returns HTTP 400 (URL too long).
  - On batch 400, retry each DOI individually (odd DOIs can still resolve singly).
  - Sleep 1-2 s between batches; always send a User-Agent.
  - OpenAlex overclaims OA on PubMed-only records with no PMC copy:
    follow up pubmed IDs yourself before promising a download.
"""
import json, sys, time, urllib.request, urllib.parse

UA = {"User-Agent": "research-audit/1.0 (mailto:you@example.com)"}


def fetch(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def norm(d):
    return d.strip().lower().rstrip(".")


def _record(out, w):
    d = norm((w.get("doi") or "").replace("https://doi.org/", ""))
    oa = w.get("open_access") or {}
    best = w.get("best_oa_location") or {}
    out[d] = {"is_oa": oa.get("is_oa", False),
              "oa_status": oa.get("oa_status", ""),
              "pdf": best.get("pdf_url") or "",
              "landing": best.get("landing_page_url") or ""}


def main():
    dois = json.load(open(sys.argv[1], encoding="utf-8"))
    out = {}
    B = 25
    for i in range(0, len(dois), B):
        batch = dois[i : i + B]
        filt = "|".join(f"doi:{d}" for d in batch)
        url = ("https://api.openalex.org/works?filter="
               + urllib.parse.quote(filt)
               + "&per-page=50&select=doi,open_access,best_oa_location")
        try:
            data = fetch(url)
        except Exception:
            for d in batch:  # isolate the offending DOI
                try:
                    w = fetch(f"https://api.openalex.org/works/doi:{d}"
                              "?select=doi,open_access,best_oa_location")
                    _record(out, w)
                except Exception:
                    print(f"NOT FOUND: {d}", file=sys.stderr)
                time.sleep(0.3)
        else:
            for w in data.get("results", []):
                _record(out, w)
        time.sleep(1.5)
    print(json.dumps(out, indent=1))
    if len(sys.argv) > 2 and sys.argv[2].startswith("--out"):
        json.dump(out, open(sys.argv[3], "w", encoding="utf-8"), indent=1)


if __name__ == "__main__":
    main()
