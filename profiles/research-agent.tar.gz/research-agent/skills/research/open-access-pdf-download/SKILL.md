---
name: open-access-pdf-download
description: Bulk-download OA research PDFs from citation lists/corpora.
version: 1.0.0
metadata:
  hermes:
    tags: [open-access, pdf, download, doi, openalex, pubmed, cdp, chrome]
    category: research
    related_skills: [citation-verification, xlsx, blocked-page-recovery]
---

# Open-Access PDF Bulk Download

Collect research-article PDFs from a verified citation corpus (per-topic lit reviews, QIQA corpora, reference lists) with honest per-article outcomes. Built for Mars Cruz's academic workflow and his network rules.

## Hard rules (user standing preferences)

- **Rate limit: sequential downloads only, 15–30 s between requests** (default 20 s). University network; user fears IP flagging. State the delay up front before any run.
- **NEVER create folders.** The user pre-creates the destination directory and gives an exact path — write into it as-is. No new subfolders, no workspace trees beside outputs. Reusing an old pattern drew an explicit correction: *"I do not want you to make new ones, stop making new folders."*
- File naming convention: `Author et al - Year - Title.pdf` (sanitize `\/:*?"<>|`, cap title ~120 chars).
- Provenance + resume: write `_state.json` (per-file status/bytes/sha16/source URL) and `_download_log.txt` into the destination; skip anything already `ok` on rerun.
- Never claim success from intent: verify each file's `%PDF` magic bytes + size > 5 KB on disk, and report OK vs MISS with reasons, not a plausible total.
- When a run finishes short, produce `MANUAL_DOWNLOAD_N.md` (numbered table of file→DOI/URL) in the destination so the user can click through leftovers.

## Workflow: three staged passes

### Pass 0 — OA classification (metadata only, no downloads)

Live-check every DOI's OA status **before** promising a count. OpenAlex batch API beats guessing:

```
https://api.openalex.org/works?filter=doi:A|doi:B|doi:C&per-page=50&select=doi,open_access,best_oa_location
```

- Batch **≤ 25 DOIs** per request (50 returns HTTP 400 — URL too long). On any 400, retry the batch one DOI at a time; odd DOIs that still 400 on batch can resolve via single `works/doi:<doi>`.
- Classify each row: `is_oa` true → direct PDF (`best_oa_location.pdf_url`) vs landing-only; false → closed. Gov/repo items without DOIs (CDC stacks, university repositories, NIOSH, PubMed pages, WHO) count as free — fetch them directly by URL.
- Sleep ~1–2 s between batches; send a `User-Agent`. Ready-made checker: `scripts/openalex_oa_check.py`.
- **OpenAlex overclaims OA.** A pubmed.ncbi.nlm.nih.gov record with `is_oa=true` often has NO free copy (no PMC link) — fast-fail those instead of burning minutes. Landing-only items are frequently bot-blocked HTML at the publisher. Expect the honest script-downloadable total to be well under the OA total (e.g. 58 of 159 in the reference run; the rest needed the browser pass or manual clicks).

### Pass 1 — plain urllib (cheap wins)

Sequential `urllib.request` with a browser `User-Agent`; accept only `%PDF` magic + > 5 KB; `.part` file then `os.replace`; 20 s delay; save state every iteration. Captures ~40 % (mostly MDPI/PMC/BMC direct links).

### Pass 2 — OA-fallback retry chain (another ~15 %)

For every Pass-1 failure, in order, 2 s apart:
1. **PMC via NCBI idconv**: `https://www.ncbi.nlm.nih.gov/pmc/utils/idconv/v1.0/?ids=<DOI>&format=json` → `pmcid` → `https://pmc.ncbi.nlm.nih.gov/articles/<PMCID>/pdf/`
2. **Crossref full-text links**: `https://api.crossref.org/works/<DOI>` → `message.link[]` where `content-type == application/pdf`
3. **Unpaywall**: `https://api.unpaywall.org/v2/<DOI>?email=<you@host>` → `best_oa_location.url_for_pdf`
4. **doi.org direct** (last resort).

### Pass 3 — CDP browser pass (recovers the bot-walled remainder)

Full technique and code: `references/cdp-browser-download.md`. Summary:

- **Launch the INSTALLED Chrome yourself** — never rely on a browser harness's auto-launch (it spawns its own instance/falls back to another engine and demands manual "Allow remote debugging" popups on the default profile, which loops badly and frustrates the user):
  `"C:/Program Files/Google/Chrome/Application/chrome.exe" --remote-debugging-port=9333 --user-data-dir="<dedicated temp dir>" --no-first-run --no-default-browser-check about:blank` — a **dedicated profile never shows the Allow popups** (those only hit the default profile).
- Drive tabs directly over websockets (CDP `http://127.0.0.1:9333/json/new?about%3Ablank` → `webSocketDebuggerUrl`).
- **The working download mechanism is a same-origin in-page `fetch()`** executed via `Runtime.evaluate` with `awaitPromise:true`, `returnByValue:true` — it carries the page's cookies, so publisher bot-challenge interstitials served to cookieless clients never trigger, and no Chrome download machinery is involved. Returns base64; decode and write the file yourself.
- Landing-page strategy per article: navigate → wait `document.readyState == "complete"` → dismiss consent banners with a RETRY loop (Wiley's button says "Close this consent banner", not Accept; also match Agree/Reject/Save and close + the OneTrust `#onetrust-banner-sdk` container) → scan anchors → `fetch()` each candidate in-page. For PubMed entries with no `/pmc/` link, fail immediately.
- **Link-scorer pitfall:** keep `epdf` links — score `/epdf/` +4 (a −3 demotion hid Wiley's real OA link and produced false "1 link scanned" misses on fully-loaded pages); demote only `full.?text|html|reader` and cite/export/social junk. When a job misses with a suspiciously low link count, inspect the live tab's buttons/title/hasAbstract before trusting the failure — a consent banner still up or the scorer dropping links are the usual real causes.
- **Chrome ≥ 152 refuses every CDP download path** — do not waste time: page-level `Browser.setDownloadBehavior`, browser-level (on `/json/version` ws) calls, and `--disable-features=PdfViewer` all failed to produce files; `Network.responseReceived` never fires for the main PDF document (the internal viewer consumes it); response-stage `Fetch` interception deadlocks `Page.navigate` acks and still misses the PDF.
- Wiley OA is fetchable via its `/epdf/<DOI>` reader page: navigate to the epdf URL, wait ready, then same-origin fetch the PDF link/iframe found there (validated 2026-09-07: Levin 2023 Dent Traumatol 898 KB in ~24 s; Banava 2026 462 KB; Lewer 2026 469 KB). Direct `pdfdirect` still challenges in-page fetch — use the epdf hop instead. Only genuinely paywalled or Cloudflare-walled items stay in the manual list.

## Verification & report

Tally PDFs on disk (count + MB), state.json statuses, and reasons for misses. Give the user: downloaded count, per-leftover reason, and the manual-download file. Offer next steps (manual browser clicks vs CU library for closed-access) instead of over-promising.
