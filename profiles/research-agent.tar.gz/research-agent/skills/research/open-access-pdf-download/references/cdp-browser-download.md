# CDP browser pass — same-origin in-page fetch (validated 2026-09-07)

Context: bulk OA PDF download where ~100 of 159 articles were OA per OpenAlex but bot-blocked / HTML-only / dead-link for plain urllib. Chrome 152 on Windows. This is the mechanism that finally worked after every CDP download API failed.

## Launch installed Chrome (dedicated profile → no Allow popups)

```bash
"C:/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9333 \
  --user-data-dir="C:/Users/<you>/AppData/Local/Temp/.../chrome-automation" \
  --no-first-run --no-default-browser-check --disable-features=Translate about:blank
```

- Dedicated `--user-data-dir` = **no "Allow remote debugging" popups** (they only hit the default profile; the harness flow that opens chrome://inspect and asks the user to click Allow twice is a dead end in automated runs — the user grew frustrated at repeated popups and repeated chromium launches).
- Verify: `GET http://127.0.0.1:9333/json/version` → `Browser: Chrome/1xx`, then `/json/list` shows targets.
- The background terminal process holding Chrome exits when the parent shell dies — restart Chrome before a long pass; check the port first.

## Why every "normal" CDP download path failed (Chrome 152)

| Attempt | Result |
|---|---|
| `Page.setDownloadBehavior` (page ws) | ignored — no file, no event |
| `Browser.setDownloadBehavior` (browser-level ws from `/json/version`) | ignored — no file, no event |
| relaunch with `--disable-features=PdfViewer` | still no download |
| `Network.responseReceived` + `Network.loadingFinished` + `Network.getResponseBody` | `responseReceived` NEVER fires for the main PDF document (internal viewer consumes it); `loadingFinished` fires but body is the 536-byte HTML interstitial when the client is cookieless |
| `Fetch.enable` request-stage | only request metadata, no body |
| `Fetch.enable` with `requestStage: "Response"` | `Page.navigate` ack deadlocks (nav is paused); even then the PDF document bypasses Fetch |
| `Network.getResponseBody` on finished ids after full page nav | works ONLY for non-viewer responses; for the PDF you get the cookieless bot-challenge HTML |

Root causes: (1) Chrome's internal PDF viewer (`mhjfbmdgcfjbbpaeojofohoefgiehjai`) consumes the PDF document before DevTools can grab it; (2) publishers serve a bot-challenge interstitial (Springer returned a 536-byte HTML) to clients with no cookies.

## The working method: same-origin in-page fetch()

Navigate a tab to the **article landing page** (cookies set), then run an async fetch of the PDF URL inside that page via `Runtime.evaluate`. Same-origin + `credentials:'include'` → the request carries the page cookies → no interstitial. Bytes come straight back; no Chrome download machinery involved.

```python
FETCH_JS = """(async () => {
  try {
    const r = await fetch(%s, {credentials: 'include', redirect: 'follow'});
    if (!r.ok) return {err: 'http ' + r.status};
    const ct = r.headers.get('content-type') || '';
    const b = await r.arrayBuffer();
    if (!b.byteLength) return {err: 'empty'};
    const u8 = new Uint8Array(b);
    if (u8[0]!==0x25 || u8[1]!==0x50 || u8[2]!==0x44 || u8[3]!==0x46)
      return {err: 'not pdf: ' + ct};
    let bin = ''; const chunk = 0x8000;            // chunked btoa avoids call-stack limits
    for (let i = 0; i < u8.length; i += chunk)
      bin += String.fromCharCode.apply(null, u8.subarray(i, i + chunk));
    return {size: b.byteLength, ct: ct, b64: btoa(bin)};
  } catch (e) { return {err: String(e).slice(0, 160)}; }
})()"""
# send via Runtime.evaluate {expression: FETCH_JS % json.dumps(href),
#                             awaitPromise: true, returnByValue: true}
# -> decode result.b64 with base64.b64decode and write the file.
```

Results: Springer/BMC 1.6 MB ✓, Highwire (jdh.adha.org) 730 KB ✓ — each in ~4 s. Wiley: `pdfdirect` challenges in-page fetch, BUT navigating to the article's `/epdf/<DOI>` reader page and same-origin fetching there works (Levin et al. 2023, Dent Traumatol, 898 KB in ~24 s; also Banava 2026 462 KB, Lewer 2026 469 KB).

## Per-article landing-page sequence

1. Open tab: `PUT http://127.0.0.1:9333/json/new?about%3Ablank` → connect to `webSocketDebuggerUrl`.
2. `Page.enable`, `Runtime.enable`.
3. `Page.navigate` to the entry URL (DOI → `https://doi.org/<doi>`; pubmed/other URLs used as-is). Fire-and-forget the command (don't await its ack while pumping events, or a paused/interstitial nav can hang you).
4. Wait `document.readyState == "complete"` (poll via `Runtime.evaluate`, ~1 s cadence, cap ~22 s), then ~1.5 s settle.
5. Dismiss consent banners in a RETRY loop (layers reappear): up to ~4 clicks 2–2.5 s apart, matching Accept/Agree/Allow all/Got it AND "Close this consent banner", "Close Cookie Preferences", "Save and close", "Reject all", "Continue without accepting" — plus OneTrust containers (`#onetrust-banner-sdk, #onetrust-consent-sdk`) and their inner buttons. A banner left up hides the article's real links (Wiley).
6. Scan anchors in-page; score: `\.pdf` +6, `pdfdirect|pdfft|/pdf/|pdf?|content/pdf|article-pdf|download|getfile|epdf` +4, label text "download pdf|view pdf|epdf" +3, demote only `full.?text|html|reader` −3, drop cite/export/social/figures links. Return top ~8 hrefs. (Demoting `epdf` was a real bug: it hid Wiley's OA reader links and caused "1 link scanned" misses on pages whose abstract was fully loaded.)
7. `fetch()` each candidate in-page (skip the entry URL itself). If the entry host is pubmed and no candidate contains `/pmc/`, fail immediately — no free copy exists (OpenAlex overclaim). If candidates include a Wiley `/epdf/` URL, navigate to it, wait ready, rescan, and `fetch()` the PDF link/iframe there — that is the working Wiley path (direct `pdfdirect` fetch fails).
8. Optional hop: if candidates include `.../pmc/articles/PMC####` article pages, navigate to one, repeat 4–7 there, fetch its `/pdf/` link.
9. Close the tab: `PUT http://127.0.0.1:9333/json/close/<id>`; clean any temp download dir. Sleep the user's rate limit (20 s) between articles.

## websockets v15 pitfall

`websockets>=15` forbids concurrent `recv()` ("cannot call recv while another coroutine is already running"). Structure: ONE reader task drains `ws.recv()` into an `asyncio.Queue`; all commands and event pumping consume from the queue. Never spawn a second recv loop (e.g. an inline event collector while `cmd()` also reads).

## State/log discipline

Update `_state.json` after every article (status, bytes, sha16, source URL, which pass got it) and append timestamped lines to `_download_log.txt` — the runs are 1–2 h at 20 s/request and MUST be resumable/killable. On completion: count real PDFs on disk, summarize reasons for the misses, and write `MANUAL_DOWNLOAD_N.md` (numbered `| file | DOI/URL |` table) for the user's browser pass.
