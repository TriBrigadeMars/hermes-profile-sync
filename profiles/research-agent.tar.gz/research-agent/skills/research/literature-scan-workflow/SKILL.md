---
name: literature-scan-workflow
description: "Use when running a multi-day literature scan for a topic/profession. Search-string design, PubMed pipeline, two-pass verification, gap analysis."
version: 1.0.0
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [literature-review, pubmed, citations, research-methodology]
---

# Literature Scan Workflow (Multi-Day, Citation-Verified)

Generic procedure for a bounded literature scan producing candidate resources,
verified annotations, and a themed digest. Distilled from the 2026-10-09
nursing SA/DV workplace-prevention sample plan. Parameters: topic, profession,
window (default 14 days), output folders.

## 1. Scan snapshot (fill first)

| Field | Default |
|---|---|
| Topic + profession | from Mars's request |
| Scope line | interventions, training programs, policy, risk/protective factors, organisational strategies |
| Window | 14 days; digest at Day 7 (interim) and Day 14 (final) |
| Parallelism | ≤2 subagents at any time |
| Budget | PubMed E-utilities are free; respect rate limits (10 req/s with API key, 3 without) |
| Known risk | state it up front (e.g. "profession-specific SA/DV literature may be thin — honest shortfall reporting built in") |

## 2. Search-string design (four-string pattern)

Build four PubMed strings, escalating precision. Record rationale + expected
yield for each; adjust field tags per string (MeSH `[mh]` for recall on broad
strings, `[tiab]` for precision on narrow ones):

1. **Broad** — core concept synonyms AND profession (nurs*, "nursing staff", …) AND prevention terms (prevent*, intervention, program*, training, policy, strategy). Yield: hundreds.
2. **Focused** — the specific SA/DV dimension AND profession AND prevention/bystander/reporting terms. Yield: tens-to-hundreds.
3. **High-precision** — concept AND ("prevention program" OR "prevention training" OR "de-escalation training" OR "bystander intervention") AND profession. Yield: ~30–100; these are the approvable program studies.
4. **Adjacent context** — the domestic-violence/IPV side of the topic AND workplace/healthcare AND profession. Often thin; commit to reporting honest yield.

Post-filter window: `AND 2019:2026[dp]` (or per Mars) for practical relevance;
capture publication year from esummary either way.

## 3. E-utilities pipeline

```
ESearch   GET https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi
            ?db=pubmed&term=<url-encoded>&retmax=500&retmode=json&usehistory=y
ESummary  .../esummary.fcgi?db=pubmed&id=<comma-separated PMIDs, ≤200/call>&retmode=json
EFetch    .../efetch.fcgi  (PMID→DOI backfill)
ELink     .../elink.fcgi   (cited-by / related-article snowballing)
```
Parse: title, authors, year, journal, DOI, PMID. Store PMIDs between calls.

## 4. Day-by-day schedule (14-day template)

- **D1** Scaffold output dirs; run Strings 1–2; store PMIDs.
- **D2** ESummary fetch; write candidate .md files to `candidates/`.
- **D3** OA journal RSS poll (3–5 profession-relevant feeds); add recent finds.
- **D4** Run String 3; **Crossref verification batch 1** — every DOI: title/author/year match or flag.
- **D5** Targeted grey-lit scan (agency pages, professional-association position statements, sentinel alerts) — 1 subagent; String 4 in parallel — subagent 2.
- **D6** Deduplicate (by DOI, then title similarity); tag each candidate with its source string; count table by source.
- **D7** **Interim digest**: candidates grouped by theme, ≤3-line annotations, to Mars.
- **D8** **Verification pass 2** — second Crossref check on every approval candidate; PMID→DOI backfill via EFetch; mismatches demote to `verified: false` with reason. Subagent 2 snowballs cited-by on the 3 strongest candidates.
- **D9** Write approved .md files to `approved_resources/` (metadata block + 150–250 word annotation + APA 7 reference).
- **D10** Freshness sweep: RSS re-poll + PubMed `[dp]` last-7-days search.
- **D11** **Gap analysis** (see §6).
- **D12** **Final digest**: themes, counts, top-5 resources with full annotations, gap summary, next-cycle recommendations.
- **D13** Mars review window — no automated actions.
- **D14** Close out: archive unpromoted candidates (never delete — they document scope), optional `scan_summary.json` (query dates, counts per source, gap notes).

## 5. Output contract

- `approved_resources/` — one .md per resource: metadata block (title/authors/year/journal/DOI/URL), 150–250 word annotation, APA 7 reference. Mars promotes a candidate to approved; default status is `candidate`.
- `candidates/` — unverified/pending. NEVER fabricate a citation; honest shortfalls over padding.
- Digest: plain text/markdown, grouped by theme, every entry carries verified DOI/URL.

## 6. Gap analysis (always run)

Tabulate found vs sought and answer explicitly:
(a) did the scan find the SPECIFIC dimension (e.g. SA/DV prevention) or only the general one (e.g. workplace violence prevalence)?
(b) which sub-contexts concentrated the literature (ED, psych, community health)?
(c) which search strings returned zero relevant results?
State shortfall plainly in the digest — a documented gap, never padded.

## 7. Hard rules

- Two-pass live verification before anything is "approved" (Crossref, plus PubMed EFetch backfill).
- APA 7 only.
- Never email the digest — hand the body to the default profile's cron/mail.py flow.
- Lean: ≤2 subagents, batched API reads, no brute-force parallelism.
