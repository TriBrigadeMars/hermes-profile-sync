---
name: citation-verification
description: "Use when verifying citations or batch-downloading articles."
---

# Citation Verification & Batch Article Retrieval

Verify that a list of citations refers to real, resolvable sources, classify open-access
status, and (when asked) batch-download the obtainable PDFs — politely.

## When to use

- User provides a bibliography/master citation list and asks "do these actually exist?"
- Compiling a master list from multiple documents (dedupe, annotate, APA 7 output).
- Batch-downloading open-access PDFs of a known citation list.
- A user asks whether a DOI/URL is live or whether a citation is fabricated.

## Workflow

1. **Extract identifiers** from every reference: DOI (`10.*`), PMID, or plain URL.
   Normalize malformed strings (nested `https://doi.org/https://...`, trailing punctuation).
2. **Verify DOIs via doi.org first** — but see Pitfalls: HEAD can 400/403 on fine DOIs.
3. **Re-verify all 403/uncertain DOIs via Crossref API** (`api.crossref.org/works/<doi>`)
   — this bypasses publisher bot-walls and returns full metadata (authors, year, journal).
4. **Classify OA status with OpenAlex** batch queries (see references/doi-verification-methods.md
   for the exact filter syntax — a naive filter returns zero matches silently).
5. **Report honestly.** Typical real-world split: ~95% of DOIs real; failures are almost
   always bot-protection or malformed strings, NOT fabricated citations. Never claim a
   source is fake without a Crossref + web-search double-check.
6. **Flag unscriptable hosts** rather than omitting them: produce a manual-check markdown
   checklist (full citation + direct URL + expected content + checkboxes). Known
   bot-protected hosts: cdc.gov, hrsa.gov, jointcommission.org, pharmacytimes.com,
   ihpi.umich.edu, journalslibrary.nihr.ac.uk, most Elsevier/Wiley/T&F PDF endpoints.
7. **If batch-downloading**, follow the rate-limited downloader pattern in
   references/batch-oa-download.md (manifest, resumable, alt-URL retry round).
8. Deliver results as an annotated APA-7 document (.docx via the docx skill) plus a
   markdown checklist for manual items. Annotate but never silently omit unverified entries.

## User preferences (embed in every run)

- **Rate limiting is a hard user requirement.** User does research at a university and
  explicitly fears IP flagging by network security. Default: 30 s between downloads;
  15 s only if the user explicitly approves. One request at a time, never parallel.
- **User creates destination folders himself.** Never mkdir new project folders mid-task
  ('stop making new folders'). Use the exact folder path the user provides; create only
  files inside it (plus the run's own `_state`/`_log` files, not new directories).
- Citation integrity is absolute: no fabrication tolerated, honest shortfalls preferred
  over padding, complete author lists (no "et al." in reference entries).
- APA 7 output: hanging indent 0.5", double-spaced, alphabetical, & before final author,
  21+ authors → first 19 + ellipsis + last, advance-online notation, no-author works put
  title in author position (APA 7 §9.12).

## Pitfalls

- **HEAD requests:** some servers reject HEAD with 400/403 even when the resource is fine.
  Use GET (with a real browser User-Agent) before concluding anything is dead.
- **HTTP 403 ≠ dead link.** It usually means CDN bot protection. Crossref API or a web
  search of the exact title resolves the question.
- **OpenAlex batch filter:** must be `filter=doi:https://doi.org/x|https://doi.org/y`
  with `urllib.parse.quote(filt, safe="|")`. Writing bare DOIs returns 0 results with no error.
- **OpenAlex `select=` parameter must NOT be urlencoded.** `quote()` on the whole query
  string mangles `select=doi,open_access,best_oa_location` and returns HTTP 400. Build
  the URL manually: quote only the filter value, append `&select=...` raw. Also: an
  over-long filter value (50+ DOIs) can 400 — batch 25 per request and fall back to
  per-DOI queries to isolate any offending identifier.
- **xlsx_create.py spec gotchas:** `column_widths` must be a dict keyed by column LETTER
  (`{"A": 78}`), not a list, and `autofilter` must be a range string (`"A1:D160"`) — a
  list-shaped spec fails with `'list' object has no attribute 'items'`.
- **Transient 5xx on doi.org:** retry once or confirm via Crossref before declaring failure
  (a real DOI failed once with 502 and resolved fine on recheck).
- **docx skill spec format** (for the .docx deliverable): `styles` is a LIST of dicts with
  `name`/`size_pt` keys; `Normal` already exists (re-adding raises ValueError) — set its
  font post-create via python-docx; page margins go under `margins_mm`.
- **Filenames from references:** extracting "title" with a naive first-period regex grabs
  author-list fragments. Take the text after the closing year paren instead.
- **session_search is a deferred tool** — must be called via `tool_call(name="session_search", ...)`,
  not directly. CLI equivalent is `hermes sessions` (plural, not `session`). Attempting
  `hermes session search` fails with `invalid choice: 'session'`.

## References

- `references/doi-verification-methods.md` — verified API patterns, code snippets, host list
- `references/batch-oa-download.md` — downloader design, manifest pattern, realistic yield data
- `references/master-source-register.md` — multi-project master Excel register:
  cross-corpus aggregation/dedupe, OpenAlex OA classification, OA/closed two-sheet split,
  retry chain v2 (PMC → Crossref → Unpaywall → doi.org)
