# DOI Verification & OA Classification — Verified API Patterns

Patterns below were exercised end-to-end on a real 156-entry bibliography (2026-08-31).
Trust them as starting points; re-check API docs if a call returns unexpectedly empty.

## 1. Identifier extraction

- DOI: `re.search(r'https?://(?:dx\.)?doi\.org/(.+?)(?:\s|$)', ref)` then strip trailing
  punctuation AND nested prefixes (`re.sub(r'^https?://(?:dx\.)?doi\.org/', '', doi)`).
  Real bibliographies contain nested double-prefixes — handle them.
- PMID: `re.search(r'pubmed\.ncbi\.nlm\.nih\.gov/(\d+)', ref)`.
- Fallback: first bare URL. Always rstrip `.,;`.

## 2. doi.org resolution (first pass)

HEAD `https://doi.org/<doi>` with browser UA. 200/302 = exists.
BUT: 53/144 real DOIs returned 403 (publisher bot walls) and mis-classified web URLs
returned 400 (HEAD unsupported). Expect roughly this failure mix on academic lists.
One real DOI returned 502 and resolved fine on recheck — transient 5xx happens.

## 3. Crossref API (second pass — bypasses bot walls)

```
GET https://api.crossref.org/works/<doi>
```
Returns full metadata: `author[].family/given`, `issued.date-parts`, `container-title`,
`volume`, `issue`, `page`. Use to (a) confirm existence, (b) build/repair APA entries,
(c) fetch author lists the original bibliography truncated. All 53 bot-walled DOIs
confirmed here. Rate: sequential with 1–3 s sleep is fine.

Bibliographic fallback when DOI unknown/failed:
```
GET https://api.crossref.org/works?query.bibliographic=<urlencoded title+author>&rows=3
```

## 4. OpenAlex OA classification (batch)

**Filter syntax gotcha:** bare DOIs silently return 0 results. Correct form:

```
GET https://api.openalex.org/works?filter=doi:https://doi.org/10.x/abc|https://doi.org/10.x/def&per-page=50&select=doi,open_access,best_oa_location
```
with `urllib.parse.quote(filt, safe="|")` — the pipe must survive encoding.
Batches of 40 work. Response `open_access.oa_status` ∈ {gold, diamond, hybrid, bronze,
green, closed}. `best_oa_location.pdf_url` is the direct-download candidate.

Real distribution on a 115-DOI health-sciences bibliography:
gold 47, hybrid 22, diamond 10, green 8, bronze 5, closed 22 (~19% closed is typical).

## 5. URL (gray literature) verification

GET with browser User-Agent (`Mozilla/5.0 (Windows NT 10.0; Win64; x64) ... Chrome/126`).
- 200 → exists. Content-Type tells you PDF vs HTML.
- 403/429/503 → bot-blocked; NOT dead. Confirm via `web_search` of exact title + site.
- 404 → likely dead; try Wayback Machine before declaring gone.

## 6. Known bot-protected hosts (as of 2026-08)

cdc.gov, stacks.cdc.gov, hrsa.gov, jointcommission.org, pharmacytimes.com,
ihpi.umich.edu, journalslibrary.nihr.ac.uk, repository.arizona.edu (intermittent),
plus virtually all Elsevier (ScienceDirect), Wiley, and Taylor & Francis PDF endpoints.
Ergroove/bepress, NCBI Bookshelf, osha.gov, who.int, tuc.org.uk, cda.org, aacp.org,
nursingworld.org, adha.org all scripted fine with a browser UA.

## 7. No-author works

PubMed sometimes lists zero authors for unsigned journal articles. APA 7 §9.12: move the
title to the author position: `Title of article. (Year). Journal...`. Also watch for
`https://doi.org/https://pubmed...` double-prefix garbage in inherited bibliographies —
replace with a direct PubMed link when no DOI exists.

## 8. Reporting standard

Deliverable = annotated APA-7 .docx (via docx skill) + markdown manual-check checklist
(citation, direct URL, expected content, `- [ ]` checkboxes). Annotate bot-blocked
entries inline; never silently omit them. Suggested summary table: per-method counts +
verified vs manual-check totals.
