# Master Source Register — Multi-Project Excel Workbook Pattern

Proven on the 2026-09-07 run: 248 unique sources aggregated from five SA/DV source
corpora (JSON), two QIQA lit-review markdown reference lists, and one local PDF library
(filenames), deduped, OA-classified via OpenAlex, then split into an Open Access /
Closed Access two-sheet workbook.

## 1. Aggregation & dedupe

- Ingest each corpus into one record shape: `{apa, year, url, pmid, title, project, type, journal}`.
- **APA builders:** build from structured fields (authors inverted, year, title, italic
  journal + vol(issue) + pages, DOI). Some corpora embed `vol(issue)` inside the journal
  string — detect `journal, N(N)` and don't double-print volume.
- **Markdown reference lists:** split the `## References` section on blank lines; require
  a `(\d{4}[a-z]?)` year match per block or skip; DOI from `https://doi.org/(\S+)`, else
  first URL; title = text after `(year). ` up to the period before the `*Journal*`.
- **Filename-only sources:** parse `Author et al., YYYY - Title.(pdf|md|txt)`; skip
  duplicate .txt/.md twins; mark type `local library PDF` and cite honestly from filename
  (no fabricated metadata).
- **Dedupe key (in order):** `doi:<lowercase>` → `pmid:<n>` → `t:<alphanumeric title[:80]>`.
  On collision, merge by appending the second project tag (`A | B`) instead of dropping
  the row.

## 2. OA classification (OpenAlex, measured 2026-09-07)

- Batch `filter=doi:...` 25 DOIs/request; `select=doi,open_access,best_oa_location`.
- Treat all `is_oa=true` (gold/hybrid/green/diamond/bronze) as open access; plus
  gov/repository URLs (OSHA, CDC stacks, NIHR, .edu repositories, PubMed pages).
- Category the rest: DOI-verified closed vs org-page (not article PDFs) vs no-identifier.
- Result on 248 rows: 146 OA-with-DOI (97 with direct pdf_url), +13 gov/repo → 159 OA /
  89 closed. **OA status ≠ scriptable download** (see batch-oa-download.md yield table).

## 3. Workbook split (user's requested columns)

User asked exactly: Article Name | Year | Journal | DOI/PMID/URL — deliver those four
columns per sheet, sorted by title, frozen header + autofilter. OA sheet = everything an
agent could fetch without a university login; Closed = everything else (paywalled + org
pages + unenriched no-identifier rows, with the caveat stated in the reply).

## 4. Retry chain v2 (for failed first-pass downloads)

Per failed job, try in order (sleep 2 s between API calls, 20 s between jobs):

1. **DOI → PMC:** `ncbi.nlm.nih.gov/pmc/utils/idconv/v1.0/?ids=<doi>&format=json` →
   if `pmcid` returned, fetch `pmc.ncbi.nlm.nih.gov/articles/<PMCID>/pdf/`.
2. **Crossref full-text links:** `api.crossref.org/works/<doi>` →
   `message.link[]` entries with `content-type: application/pdf`.
3. **Unpaywall:** `api.unpaywall.org/v2/<doi>?email=<address>` →
   `best_oa_location.url_for_pdf`, then each `oa_locations[].url_for_pdf`.
4. **doi.org direct redirect** (last resort).

Log per-item which source succeeded (`src` in state) so yield per channel is measurable.
Validate `%PDF` magic bytes and >5 KB; never trust status codes alone.

## 5. Markdown APA7 reference list output

When the user asks for a master reference list as markdown ("APA 7 reference list", "bibliography
as .md"), output `.md` instead of Excel. Same aggregation and dedupe as sections 1–2; different
formatting.

### Procedure

1. **Ingest** per-topic `sources.json` files from `_workspace/<topic>/`.
2. **Dedupe** by `doi_or_url` (lowercased, stripped) → fallback `title`[:80] (lowercased).
   Typical: 168 raw → 161 unique across 5 profession corpora.
3. **Format** each entry as APA 7 inline reference:
   - Authors: 1 = name; 2 = "A, & B"; 3+ = "A, B, C, & Last".
   - Body: `Author(s). (Year). Title. *Journal*, *Vol*(Issue), Pages. DOI.`
   - No journal = use source type or URL (dissertation, org report, news).
4. **Sort** alphabetically by first author surname, then year.
5. **Write** `.md` with header (project name, total count, scope note) + `## References`.
   Hanging indent not needed in markdown; blank line between entries.

### Pitfalls

- Some `journal` fields already embed `Vol(Issue): Pages` — detect and don't double-print
  volume/issue/pages if already present in the journal string.
- `year` can be `None`, empty, or `9999` (unpublished) — render as "n.d." in APA 7.
- Double periods from concatenation (period after author list + period after year parens)
  — clean `..` → `.` in a while loop after assembly.
- Internal metadata fields (`_src`, `_verification`, `summary`) are not reference content;
  exclude them from the formatted output.
- Single-author entries with trailing period in the author name produce `Author.. (year)`;
  strip trailing periods from each author component before joining.

## 6. Run discipline (unchanged)

Sequential, 20–30 s pacing, `_state.json` written every item (resume-safe),
`_download_log.txt` timestamped lines, background `terminal(background=true, notify=true)`.
User creates the destination folder himself — never mkdir new project folders.
