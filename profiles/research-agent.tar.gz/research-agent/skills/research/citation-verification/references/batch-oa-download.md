# Batch OA Download — Polite Downloader Design & Real-World Yield

Design proven on a real 68-target run (2026-09-01): 27 PDFs acquired autonomously,
rest correctly triaged to manual. Use this as the reference implementation shape.

## Non-negotiable constraints (user requirement)

- **User is on a university network and fears IP flagging.** Sequential only, never
  parallel. Default 30 s between requests; 15 s only if user explicitly approves
  (user approved 15 s mid-run without issue). Politeness is a feature, not overhead.
- Real browser User-Agent on every request; Accept header for PDF/HTML.

## Architecture (single script, resumable)

1. **Plan** (deterministic, built from the verified citation list + OpenAlex metadata):
   skip `closed` status; take `best_oa_location.pdf_url` for OA items; include org URLs
   ending `.pdf`; PMID items → PubMed landing page (mostly SKIP — landing HTML, not PDF).
2. **Manifest** (`_manifest.json`): one entry per target — status, file, bytes, source,
   url. Write to disk after EVERY item. Makes the run resumable and auditable; enables
   the "downloaded vs manual" split for final lists.
3. **Log** (`_download_log.txt`): timestamped line per attempt. Human-checkable mid-run.
4. **Validate content, not status**: accept only if `data[:4] == b'%PDF'` or
   Content-Type contains 'pdf'. Otherwise mark `not-pdf` (HTML landing page — common
   on bronze/green OA).
5. **Run as background process** (`terminal(background=true)`); poll with
   `process(action='wait')` in ≤180 s windows (tool clamp).

## Retry round (second script, same rate limit)

For each `failed` item: query OpenAlex per-DOI `.../works/doi:<doi>?select=locations`,
collect ALL `locations[].pdf_url` (PMC, arXiv, university repositories), try each.
This recovered ~15% of first-pass failures. Sleep 3 s between OpenAlex queries.

## Realistic yield (measured, not estimated)

| First-pass estimate | Reality |
|---|---|
| "~95–110 of 149 downloadable" (2026-09-01 run) | 23 first pass + 4 retry = **27 (18%)** |
| "146 OA of 248" (2026-09-07 run, 159 jobs staged) | 39 first pass = **25%** of jobs |

Second run detail: of 97 jobs with an OpenAlex `best_oa_location.pdf_url`, most returned
403 (publisher wall), HTML landing pages, or 0-byte responses — OpenAlex OA status ≠ a
live, scriptable PDF link. The 13 gov/repo and 49 landing-attempt jobs fared no better
scripted. Expect roughly a fifth to a quarter of OA-classified DOIs to yield PDFs per
pass; recovery comes from the retry chain (see `references/master-source-register.md`
§ Retry chain v2: PMC idconv → Crossref full-text links → Unpaywall → doi.org).

Why the gap: OpenAlex OA status ≠ scripted-downloadability. Green OA copies are often
repository LANDING pages; Elsevier/Wiley/T&F 403 every scripted request regardless of
OA status; PMC alternates exist for only some. **Set user expectations accordingly**:
promise the honest split (auto + manual list), not a download count.

## Post-run deliverables

- Two APA-7 markdown lists in the download folder:
  List 1 = downloaded (auto), List 2 = manual required — with a summary table
  (paywalled / bot-blocked / HTML-only / org-protected counts) and a library-access tip.
- Known bug to avoid: filename generation from references — naive first-period regex
  produces `Author et al - 2024 - , & Other, N.pdf` garbage. Extract title text AFTER
  the closing year paren; sanitize `\/:*?"<>|`. Some early-run files may still have
  bad names — offer a rename pass.

## Failure triage (from real run)

- 403 Forbidden — publisher wall; goes to manual list (browser works fine).
- 429 Too Many Requests — only appeared at 15 s pacing on one host; acceptable.
- 404 — dead alt-URL; try next alternate or Wayback.
- not-pdf — landing page; sometimes the real PDF is linked inside (manual fetch).
