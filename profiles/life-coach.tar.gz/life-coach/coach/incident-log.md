# Incident Log

<!-- Life-coach crisis escalation events. Date, trigger, action taken. -->
