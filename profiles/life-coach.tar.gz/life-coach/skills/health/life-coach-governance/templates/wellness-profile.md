# Wellness Profile — CONFIDENTIAL

<!-- Filled in for Mars Cruz. Save as JSON alongside this template, e.g.
     ~/.hermes/coach/profile.json. Never commit this file, never upload it,
     never paste its contents into web queries or session titles.
     coach_governance.py reads the JSON form of these fields. -->

## Conditions & Diagnoses

- ADHD
- undiagnosed autism (self-identified trait — not a diagnosis; the agent
  treats this as the user's own framing and never asserts it as fact)

## Current Medications

<!-- None listed. Leave empty. -->

## Known Triggers & Warning Signs

<!-- Add any topics, phrasings, or situations that reliably make things
     worse. Empty for now. -->

## Contraindicated Coaching Patterns

<!-- Advice framings that are wrong *for you*. These are added to the
     built-in block list as regex patterns. ADHD + autism patterns are
     auto-merged from the conditions above; add personal ones here. -->
- `\bno pain no gain\b`

## Crisis Contacts

<!-- Used verbatim during escalation. -->
- Andrew — message him on Instagram, or call him via SMS
- 988 Suicide & Crisis Lifeline (call or text 988) — fallback only

## Human Supports

<!-- People and professionals the agent should point back to. The agent is
     never positioned as a substitute for these. -->
- Andrew (crisis contact)

## Safety Plan

<!-- Free text. -->
When things get bad: message Andrew on Instagram or call him via SMS first.
If I can't reach him and I'm unsafe, call 988.

## Coaching Preferences

- modality: CBT + motivational interviewing
- tone: gentle, almost parental
- cadence: [preference]
