#!/usr/bin/env python3
"""Life-Coach Governance guards (Primitives 13-17).

Deterministic guardrails for a personal life-coach / therapeutic-guidance
Hermes agent. Same philosophy as browser_governance.py (Primitives 9-12):
regex-based, zero-LLM, auditable, fail-closed. LLM judgment (empathy,
motivational interviewing) layers on top; it never replaces this floor.

Covers:
  13. WellnessProfile       - confidential, local-only profile; default-deny
  14. ContraindicationCheck - advice patterns screened against the profile
  15. ClaimEvidenceLedger   - unevidenced psychoeducation claims flagged
                              (pairs with grounded-citations sources.py)
  16. CrisisScan            - two-way scan (user text AND agent drafts)
  17. DependenceGuard       - anti-dependence language + query redaction

Self-test:  python coach_governance.py --check
CLI:
  python coach_governance.py scan-user "<text>" [--json]
  python coach_governance.py scan-agent "<text>" --profile profile.json [--json]
  python coach_governance.py scan-claims draft.md [--json]
  python coach_governance.py redact-query "<query>" --profile profile.json [--json]
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass, field

# ---------------------------------------------------------------------------
# Primitive 16: CrisisScan patterns
# ---------------------------------------------------------------------------

# User-side crisis markers. Any match escalates immediately; the coaching
# frame stops and the escalation protocol in SKILL.md takes over.
CRISIS_PATTERNS = [
    ("suicid-mention", r"\bsuicid(e|al)\b"),
    ("self-harm-ideation", r"\bkill (myself|me)\b"),
    ("end-life", r"\bend(?:ing)? (my|it all|my own) (life|it)\b"),
    ("no-reason-to-live", r"\bno reason to (go on|live|keep going)\b"),
    ("burden", r"\b(everyone|they|you(?: all)?|my family) (would be|will be|are) better off without me\b"),
    ("want-to-die", r"\bwant(to| to) die\b"),
    ("self-injury", r"\b(hurt|harming|cutting|cut) (myself|myself)\b"),
    ("self-injury-2", r"\bself[- ]harm\b"),
    ("hopeless-cant-go-on", r"\bcan'?t (go on|do this anymore|take (this|it) anymore)\b"),
    ("overdose-risk", r"\boverdose\b|\btake (all|the whole (bottle|pack))\b"),
    ("goodbye-framing", r"\b(say(ing)? goodbye|this is (the end|goodbye))\b"),
]

# Agent-side block patterns: output the agent must NEVER produce. Fail-closed:
# any match rejects the draft and forces a rewrite (or ReviewRequest).
AGENT_BLOCK_PATTERNS = [
    ("med-change-advice", r"\b(stop|quit) taking (your|the) (medication|meds|antidepressants?|prescription)\b"),
    ("dose-escalation", r"\btake more than (your )?(prescribed|dose|directed)\b"),
    ("method-facilitation", r"\b(ways?|how) (to|of) (kill|hurt|cut|end) (yourself|oneself|your life)\b"),
    ("toxic-positivity", r"\bjust (get over it|think positive|snap out of it|push through it)\b|\b(get over it|snap out of it|think positive(?:ly)?|push through it)\b"),
    ("minimizing", r"\bit'?s not (that|really) bad\b|\bothers have it worse\b"),
    ("sole-support-claim", r"\bi('?m| am) (the only one|all) (you have|who (understands|cares))\b"),
    ("replace-professional", r"\byou don'?t need (therapy|a therapist|professional help|medication|a doctor)\b"),
    ("diagnosis-claim", r"\byou (definitely|clearly) have \b|\bthat'?s (clearly|definitely) (bipolar|depression|adhd|anxiety disorder|a disorder)\b"),
    ("dependency-encouragement", r"\b(i'?m|talk to me) (always here|all you need|the only)\b"),
]

# ---------------------------------------------------------------------------
# Primitive 17: DependenceGuard
# ---------------------------------------------------------------------------

# Softer than AGENT_BLOCK_PATTERNS: these are dependence-fostering framings
# that should be rewritten even if not a hard violation.
DEPENDENCE_SOFT_PATTERNS = [
    ("exclusivity-framing", r"\bonly (i|here) (understand|can help)\b"),
    ("always-available-framing", r"\bi'?ll? (always )?be here (whenever|for you)\b"),
    ("isolation-nudge", r"\byou don'?t have to tell (anyone|anybody) else\b"),
    ("secrecy-framing", r"\b(our|this) (conversations? )?(stays?|is) (just )?between us\b"),
]

# ---------------------------------------------------------------------------
# Primitive 14: condition-aware contraindication patterns
# ---------------------------------------------------------------------------
# Auto-merged into all_contraindications() when the profile lists a matching
# condition (substring match, case-insensitive). Built-ins are immutable;
# these are curated for the user's ADHD + undiagnosed autism. Negative
# lookbehinds keep genuinely supportive phrasing ("you don't need to mask")
# from being blocked.
CONDITION_PATTERNS = {
    "adhd": [
        ("adhd-shame-focus", r"\bjust (focus|concentrate|try harder|pay attention|be more organized|get disciplined)\b"),
        ("adhd-lazy", r"\byou'?re just (lazy|unmotivated|procrastinating|not trying)\b"),
        ("adhd-hustle", r"\b(hustle|grind|no days off)\b"),
        ("adhd-want-to", r"\bif you (really )?wanted to, you would\b"),
        ("adhd-planner", r"\bjust (use a planner|set a reminder|make a to-do list)\b"),
    ],
    "autism": [
        ("autism-social", r"\bjust (be more social|put yourself out there|make eye contact|smile more|talk to people)\b"),
        ("autism-mask", r"(?<!don't )(?<!doesn't )\b(you )?(just )?need to (mask|blend in|act normal|fit in)\b"),
        ("autism-stimming", r"(?<!need to )(?<!have to )\bstop (stimming|fidgeting|rocking)\b"),
        ("autism-invalid", r"\b(it'?s|that'?s) all in your head\b|\byou don'?t (seem|look) autistic\b"),
        ("autism-sensory", r"\bjust (deal with it|toughen up|get used to it|ignore it)\b"),
    ],
}

# ---------------------------------------------------------------------------
# Primitive 15: ClaimEvidenceLedger scan
# ---------------------------------------------------------------------------

# Assertion phrases that demand a citation [n] or an explicit [unverified] tag.
EVIDENCE_ASSERTIONS = [
    r"research shows", r"studies (show|suggest|find)", r"science says",
    r"clinically proven", r"proven to", r"evidence (shows|suggests|supports)",
    r"guaranteed", r"cures?", r"always works", r"never causes",
    r"is (known|shown) to cause", r"doctors (recommend|agree)",
    r"(resets?|rewires?|heals?|fixes?|balances?) your",  # mechanism claims
    r"completely|instantly|permanently",                 # absolutist modifiers
]

_CITATION_RE = re.compile(r"\[\d+\]|\[unverified\]", re.IGNORECASE)
_SENTENCE_RE = re.compile(r"[^.!?\n]+[.!?]?")
_ASSERTION_RE = re.compile("|".join(EVIDENCE_ASSERTIONS), re.IGNORECASE)

# ---------------------------------------------------------------------------
# Findings / ReviewRequest
# ---------------------------------------------------------------------------


@dataclass
class Finding:
    """One deterministic scan hit."""
    scanner: str
    pattern_id: str
    excerpt: str
    severity: str  # "info" | "rewrite" | "block" | "crisis"

    def to_dict(self):
        return asdict(self)


@dataclass
class ReviewRequest:
    """Fail-closed escalation artifact (analog of Primitive 7)."""
    source: str          # "user_message" | "agent_draft" | "claims" | "query"
    severity: str        # "info" | "rewrite" | "block" | "crisis"
    findings: list = field(default_factory=list)
    action: str = ""     # recommended disposition

    @classmethod
    def from_findings(cls, source, findings):
        if not findings:
            return None
        order = {"info": 0, "rewrite": 1, "block": 2, "crisis": 3}
        severity = max((f.severity for f in findings), key=lambda s: order[s])
        actions = {
            "info": "PROCEED with awareness",
            "rewrite": "REWRITE draft before sending",
            "block": "REJECT draft; reframe per SKILL.md",
            "crisis": "STOP coaching frame; run Crisis Escalation Protocol",
        }
        return cls(
            source=source,
            severity=severity,
            findings=[f.to_dict() for f in findings],
            action=actions[severity],
        )

    def to_dict(self):
        return asdict(self)


def _scan(text, patterns, scanner, severity):
    findings = []
    if not text:
        return findings
    for pattern_id, pattern in patterns:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            start = max(0, match.start() - 30)
            end = min(len(text), match.end() + 30)
            findings.append(Finding(
                scanner=scanner,
                pattern_id=pattern_id,
                excerpt=text[start:end].strip(),
                severity=severity,
            ))
    return findings


# ---------------------------------------------------------------------------
# Primitive 13: WellnessProfile (confidential, local-only, default-deny)
# ---------------------------------------------------------------------------


@dataclass
class WellnessProfile:
    """User's confidential coaching profile. Lives on disk locally only.
    Never uploaded, never echoed in web queries (see redact_query).
    Empty/unknown fields fall back to conservative behavior: the agent
    treats unknown conditions as present and applies the strictest defaults."""
    conditions: list = field(default_factory=list)
    medications: list = field(default_factory=list)
    triggers: list = field(default_factory=list)
    contraindicated_patterns: list = field(default_factory=list)  # extra regexes
    crisis_contacts: list = field(default_factory=list)
    support_contacts: list = field(default_factory=list)
    safety_plan: str = ""
    coaching_preferences: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    def to_dict(self):
        return asdict(self)

    def all_contraindications(self):
        """Built-in patterns can never be removed; condition-aware patterns
        auto-merge from the profile's conditions; profile adds extras."""
        patterns = list(AGENT_BLOCK_PATTERNS)
        for cond, pats in CONDITION_PATTERNS.items():
            if any(cond in (c or "").lower() for c in self.conditions):
                patterns.extend(pats)
        patterns += [
            (f"profile:{i}", p) for i, p in enumerate(self.contraindicated_patterns)
        ]
        return patterns


def redact_query(profile: WellnessProfile, query: str) -> tuple:
    """Primitive 13/17: strip condition and medication names from a web
    query before it leaves the machine. Returns (redacted, removed_terms).
    A fully-empty result fails closed (the query is not sent)."""
    raw_terms = [t for t in list(profile.conditions) + list(profile.medications) if t]
    terms = []
    for t in raw_terms:
        terms.append(t)
        # multi-word conditions ("undiagnosed autism") must also redact their
        # individual words, or a bare "autism" leaks into the query.
        for w in t.split():
            w = w.strip(" ,;()")
            if len(w) >= 4:
                terms.append(w)
    removed = []
    redacted = query
    for term in terms:
        if re.search(re.escape(term), redacted, re.IGNORECASE):
            redacted = re.sub(re.escape(term), "", redacted, flags=re.IGNORECASE)
            removed.append(term)
    redacted = re.sub(r"\s{2,}", " ", redacted).strip(" ,;-")
    return redacted, removed


# ---------------------------------------------------------------------------
# Public scan API
# ---------------------------------------------------------------------------


def crisis_scan_user(text) -> list:
    """Primitive 16, user side. Any finding => severity 'crisis'."""
    return _scan(text, CRISIS_PATTERNS, "crisis_scan_user", "crisis")


def crisis_scan_agent(text) -> list:
    """Primitive 16, agent side. Any finding => severity 'block'."""
    return _scan(text, AGENT_BLOCK_PATTERNS, "crisis_scan_agent", "block")


def contraindication_scan(profile: WellnessProfile, text) -> list:
    """Primitive 14. Profile-driven advice screening (block severity)."""
    return _scan(text, profile.all_contraindications(),
                 "contraindication_scan", "block")


def dependence_scan(text) -> list:
    """Primitive 17. Soft dependence framings => severity 'rewrite'."""
    return _scan(text, DEPENDENCE_SOFT_PATTERNS, "dependence_scan", "rewrite")


def claim_scan(text) -> list:
    """Primitive 15. Assertion phrases without a citation [n] or an explicit
    [unverified] tag => severity 'rewrite'."""
    findings = []
    for sentence in _SENTENCE_RE.findall(text or ""):
        if _ASSERTION_RE.search(sentence) and not _CITATION_RE.search(sentence):
            findings.append(Finding(
                scanner="claim_scan",
                pattern_id="unevidenced-assertion",
                excerpt=sentence.strip()[:120],
                severity="rewrite",
            ))
    return findings


def scan_agent_draft(profile: WellnessProfile, text) -> ReviewRequest:
    """Full agent-side gate: run every draft through 14, 15, 16, 17 before
    it is sent. 'block' findings reject the draft outright."""
    findings = (
        crisis_scan_agent(text)
        + contraindication_scan(profile, text)
        + claim_scan(text)
        + dependence_scan(text)
    )
    return ReviewRequest.from_findings("agent_draft", findings)


def scan_user_message(profile: WellnessProfile, text) -> ReviewRequest:
    """User-side gate: crisis detection before the coaching frame engages."""
    findings = crisis_scan_user(text)
    return ReviewRequest.from_findings("user_message", findings)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------


def _check():
    profile = WellnessProfile.from_dict({
        "conditions": ["depression", "generalized anxiety"],
        "medications": ["sertraline"],
        "contraindicated_patterns": [r"\bno pain no gain\b"],
        "crisis_contacts": ["988 Suicide & Crisis Lifeline"],
    })

    # 16 user side: crisis detected, fail-closed escalation
    rr = scan_user_message(profile, "honestly lately I've been thinking about ending my life")
    assert rr is not None and rr.severity == "crisis", rr

    # 16 user side: benign message passes
    assert scan_user_message(profile, "work has been stressful, I keep procrastinating on my review") is None

    # 16 agent side: medication advice blocked
    rr = scan_agent_draft(profile, "It might help to stop taking your medication for a while and reset.")
    assert rr and rr.severity == "block", rr

    # 16 agent side: toxic positivity blocked
    rr = scan_agent_draft(profile, "Honestly you just need to snap out of it and get moving.")
    assert rr and any(f.pattern_id == "toxic-positivity" for f in
                      [Finding(**d) for d in rr.findings]), rr

    # 14 profile-driven contraindication hits
    rr = scan_agent_draft(profile, "Remember: no pain no gain!")
    assert rr and any("profile:0" in f["pattern_id"] for f in rr.findings), rr

    # 14 condition-aware contraindications (ADHD + undiagnosed autism)
    adhd_autism = WellnessProfile.from_dict({
        "conditions": ["ADHD", "undiagnosed autism"],
        "crisis_contacts": ["Andrew - message on Instagram or call via SMS"],
    })
    rr = scan_agent_draft(adhd_autism, "You're just lazy - if you really wanted to, you would have started.")
    assert rr and rr.severity == "block", rr
    rr = scan_agent_draft(adhd_autism, "Just be more social and make eye contact, it's not that hard.")
    assert rr and rr.severity == "block", rr
    # supportive autism framing is NOT blocked
    assert scan_agent_draft(adhd_autism, "You don't need to mask or force eye contact here.") is None
    # benign coaching passes under the same profile
    assert scan_agent_draft(adhd_autism, "What's one small thing you'd like to make easier this week?") is None

    # 15 unevidenced claim flagged
    rr = scan_agent_draft(profile, "Cold showers reset your dopamine system completely.")
    assert rr and any(f["scanner"] == "claim_scan" for f in rr.findings), rr

    # 15 cited claim passes
    assert claim_scan("Exercise reduces depressive symptoms in many adults.[1]") == []

    # 15 explicit unverified tag passes
    assert claim_scan("Some people report cold showers help. [unverified]") == []

    # 17 soft dependence framing flagged as rewrite
    rr = scan_agent_draft(profile, "Don't worry, I'll always be here whenever you need me.")
    assert rr and any(f["scanner"] == "dependence_scan" for f in rr.findings), rr

    # 17 benign warm phrasing passes
    assert scan_agent_draft(profile, "That took real courage to name out loud.") is None

    # 13/17 query redaction
    redacted, removed = redact_query(profile, "sertraline and depression exercise evidence")
    assert "sertraline" not in redacted and "depression" not in redacted, redacted
    assert sorted(removed) == ["depression", "sertraline"], removed

    # 13/17 redaction never empties a query (fail-closed)
    redacted, _ = redact_query(profile, "sertraline depression")
    assert redacted == "", redacted

    # 13/17 multi-word condition: individual words also redacted
    redacted, removed = redact_query(adhd_autism, "ADHD and autism executive function strategies")
    assert "autism" not in redacted and "ADHD" not in redacted, redacted
    assert "autism" in removed, removed

    print("ALL SELF-TESTS PASSED")
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main(argv=None):
    parser = argparse.ArgumentParser(description="Life-Coach Governance guards")
    parser.add_argument("--json", action="store_true", dest="as_json")
    parser.add_argument("--check", action="store_true", dest="self_test")
    sub = parser.add_subparsers(dest="cmd")

    p = sub.add_parser("scan-user")
    p.add_argument("text")

    p = sub.add_parser("scan-agent")
    p.add_argument("text")
    p.add_argument("--profile", default=None)

    p = sub.add_parser("scan-claims")
    p.add_argument("path")

    p = sub.add_parser("redact-query")
    p.add_argument("query")
    p.add_argument("--profile", default=None)


    args = parser.parse_args(argv)

    def _load_profile(path):
        if not path:
            return WellnessProfile()
        with open(path, "r", encoding="utf-8") as fh:
            return WellnessProfile.from_dict(json.load(fh))

    def _emit(rr):
        if args.as_json:
            print(json.dumps(rr.to_dict() if rr else {"clear": True}, indent=2))
        else:
            if rr is None:
                print("CLEAR")
            else:
                print(f"[{rr.severity.upper()}] {rr.action}")
                for f in rr.findings:
                    print(f"  - {f['scanner']}/{f['pattern_id']}: {f['excerpt']}")
        return 0 if rr is None or rr.severity in ("info", "rewrite") else 1

    if args.self_test:
        return _check()
    if args.cmd == "scan-user":
        return _emit(scan_user_message(_load_profile(None), args.text))
    if args.cmd == "scan-agent":
        return _emit(scan_agent_draft(_load_profile(args.profile), args.text))
    if args.cmd == "scan-claims":
        with open(args.path, "r", encoding="utf-8") as fh:
            return _emit(ReviewRequest.from_findings("claims", claim_scan(fh.read())))
    if args.cmd == "redact-query":
        redacted, removed = redact_query(_load_profile(args.profile), args.query)
        if args.as_json:
            print(json.dumps({"redacted": redacted, "removed": removed}))
        else:
            print(redacted or "(QUERY BLOCKED - fully redacted)")
            if removed:
                print(f"removed: {', '.join(removed)}")
        return 0
    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
