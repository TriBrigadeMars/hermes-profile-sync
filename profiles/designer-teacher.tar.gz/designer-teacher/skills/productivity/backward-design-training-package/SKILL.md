---
name: backward-design-training-package
description: "Use when building a training package (lesson plan, activities, slides, evaluation). Backward Design, four deliverables, accessibility sign-off loop."
version: 1.0.0
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [instructional-design, backward-design, training, accessibility, lesson-planning]
---

# Backward Design Training Package (4 Deliverables)

Production procedure for a training request: measurable outcomes first, then
assessment, then activities, then content. Every deliverable passes
accessibility review before sign-off.

## 0. Before production

- Confirm with Mars: topic + duration, audience, department focus, folder path
  (Mars pre-creates `C:/Users/cruzmars/Documents/OE Training/<slug>/` — never
  mkdir), evaluation platform, whether de-identified OE data may ground the
  framing slide.
- Source grounding: OE training materials on disk, `approved_resources/` from
  research-agent, and the agent resource index. Every claim cites its source or
  a verified citation — mark anything ungrounded as [UNGROUNDED]. Never
  fabricate a citation.

## 1. Backward Design sequence (never content-first)

1. **Measurable learning outcomes** (3–5): observable verbs (identify, apply,
   demonstrate, distinguish), scoped to the session length.
2. **Assessment plan**: pre/post evaluation items mapping 1:1 to outcomes.
3. **Activities**: 2–4, each tied to a named outcome, with facilitation notes
   and timing.
4. **Content/slides**: only what serves the outcomes and activities.

## 2. The four deliverables (to the Mars-created folder)

| File | Contents | Budget |
|---|---|---|
| `lesson_plan.docx` | outcomes, assessment plan, activity sequence w/ timing, materials list | 3–6 pages |
| `activities.docx` | 2–4 activities tied to named outcomes, facilitation notes, debrief prompts | 2–4 pages |
| `slides.pptx` | title, outcomes, framing w/ data, concept slides, activity-instruction slides, scenario/discussion, resources, evaluation reminder | 15–25 slides; speaker notes on EVERY slide |
| `evaluation_template.docx` | pre/post items, each tagged to its outcome; Likert + knowledge checks + open response | 2–3 pages |

Production order: evaluation template → lesson plan → activities → slides
(assessment first forces outcome clarity).

## 3. Accessibility sign-off (per file, before calling it done)

Checklist: heading styles (real Word heading levels), alt text on all
images/tables, contrast ≥ 4.5:1, slide body ≥ 18pt, speaker notes everywhere,
table header rows set, reading order verified, screen-reader flow (no orphan
colons/labels). Run a review → fix → re-check loop per file; load the matching
accessibility-agent skill (`docx-accessibility-agent`, `pptx-accessibility-agent`)
for the review pass. A file without a passed accessibility review is NOT done.

## 4. Hard rules

- NEVER send email; deliverables are file paths Mars opens.
- NEVER create folders beyond the Mars-created deliverable folder.
- NEVER fabricate citations or statistics.
- Windows host: C:/ forward-slash native paths.
