---
name: public-health-education-builder
description: "Build textbook-grounded public-health learning materials."
version: 1.0.0
author: Mars Cruz, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [public-health, education, curriculum, assessment, learning]
    related_skills: [public-health-research-lifecycle, public-health-research-integrity-auditor, powerpoint, docx]
---

# Public Health Education Builder

Convert the textbook-grounded public-health research curriculum into original lessons, workshops, workbooks, assessments, cases, slides, facilitator guides, and project-based learning materials. The educational worker teaches how research decisions are made; it does not silently change canonical research state.

## When to Use

Use for `TEACH_CHAPTER`, `TEACH_CONCEPT`, `TEACH_RESEARCH_PHASE`, `PROJECT_BASED_LEARNING`, `BUILD_COURSE`, `BUILD_WORKSHOP`, `BUILD_LESSON`, `BUILD_WORKBOOK`, `BUILD_ASSESSMENT`, `BUILD_CASE_STUDY`, `BUILD_SLIDES`, or `BUILD_FACILITATOR_GUIDE`. Use `PROJECT_LINKED` when a learner wants examples or exercises grounded in an active project.

## Do Not Use

Do not use it to approve research decisions, write user facts into canonical state, reproduce textbook chapters or publisher test banks, fabricate study results/participant quotations, declare IRB status, or replace format-specific document/presentation/accessibility skills.

## AgentContract

- **Capability:** create aligned public-health learning materials and assessments from book concepts, current evidence, and original scenarios.
- **Required inputs:** educational mode; audience/education level/research experience; topic/chapter/phase; duration/modality; desired material type; project-linked status; project mode if linked.
- **Optional inputs:** learning objectives/competencies; statistical background; group size; synchronous/asynchronous setting; assessment type; accessibility/language/tone; active project state; current sources.
- **Outputs:** learner profile; objectives; competency mapping; prerequisites; compact primer; worked example; guided practice; project application; reflection; formative assessment; scoring rubric/answer explanation; extension; provenance notes; learner artifact; educational stage result.
- **State reads:** `project.mode`; `learner`; `research.topic`; `research.population`; `research.setting`; `research.variables_constructs`; `research.sampling`; `research.design`; `research.quantitative_analysis`; `research.qualitative_analysis`; `research.dissemination`; `education`; `provenance`; `workflow`.
- **State writes:** `education.learning_objectives`; `education.competency_mapping`; `education.materials_requested`; `education.assessments`; `education.learner_artifacts`; educational artifact/provenance records; never substantive `research.*` decisions unless a separately approved research-stage action occurs.
- **Validation rules:** align objectives to book learning objectives/Research Project Check-Ins and competencies; teach concepts before application; assess reasoning rather than vocabulary only; label book primer/current evidence/user project content; use original cases/questions; preserve research state; distinguish educational milestone completion from research-stage completion; address accessibility and language.
- **Completion condition:** requested unit/materials have objectives, prerequisites, content, practice, application, assessment, feedback/scoring, source notes, and accessibility checks, and any project-linked use is explicitly marked without mutating canonical research state.

## Modes and project link

- `TEACH_CHAPTER`: map the chapter's learning objectives and check-in to a unit.
- `TEACH_CONCEPT`: teach one concept card with confusion checks and application.
- `TEACH_RESEARCH_PHASE`: teach a six-phase lifecycle phase and its chapter stages.
- `PROJECT_BASED_LEARNING`: turn accepted or provisional project artifacts into guided practice.
- `BUILD_COURSE`: sequence multiple units and capstone milestones.
- `BUILD_WORKSHOP`/`BUILD_LESSON`: produce timed facilitation plans.
- `BUILD_WORKBOOK`: produce learner pages, prompts, worksheets, and reflection.
- `BUILD_ASSESSMENT`: produce original reasoning tasks, answer explanations, and rubric.
- `BUILD_CASE_STUDY`: create an original synthetic case; mark all values as demonstration.
- `BUILD_SLIDES`: produce a slide outline/spec and call `powerpoint` for rendering.
- `BUILD_FACILITATOR_GUIDE`: add facilitation notes, anticipated misconceptions, timing, and adaptations.
- `PROJECT_LINKED`: use the learner's project for exercises where pedagogically appropriate, but store the exercise/answer separately from canonical research state.

## Adaptive intake

Load existing educational state and ask only unanswered high-information questions, 3–7 per turn:

1. Who are the learners and what research/statistical experience do they have?
2. What chapter, concept, phase, or decision should the unit teach?
3. What should learners be able to do after the unit?
4. What duration, modality, group size, language, accessibility, and tone apply?
5. Which material types and assessment approach are wanted?
6. Should exercises use the active project, a synthetic case, or both?

## Educational workflow

1. Load the chapter map, concept cards, question banks, rubrics, and traceability matrix.
2. Select objectives and prerequisite concepts; connect each to a chapter/check-in and competency.
3. Provide a concise `BOOK_PRIMER` in `LEARN_AND_BUILD`/teaching modes; current guidance is separate and cited.
4. Create a worked example, guided practice, project application, reflection, and reasoning assessment.
5. Run the corresponding research-stage validator as an educational feedback check, not as a state mutation.
6. Create the learner artifact and mark the educational milestone separately.
7. Delegate DOCX/PPTX/PDF rendering and accessibility checks to existing skills; verify read-back/render outputs.

## Copyright and integrity

Paraphrase the book. Use only short quotations when necessary and cite the source location. Do not reconstruct instructor manuals, test banks, or long copyrighted passages. Original assessments must not be presented as publisher materials. Synthetic examples must be labeled `DEMONSTRATION` and cannot populate `research.results` or `provenance.analytic_outputs`.

## Assessment design

Prefer tasks requiring learners to identify design flaws, operationalize a construct, critique a sampling plan, recognize ethical concerns, choose an analysis, interpret a null result, select a truthful visualization, or tailor dissemination. Answer keys should explain reasoning and acceptable alternatives; a learner's exploratory response does not alter research state.

The educational output uses the canonical `stage_result` contract, with educational milestone status kept separate from research-stage status.

## Failure states

## Correction propagation

`EDUCATIONAL_CONTEXT_MISSING`, `OBJECTIVE_TRACEABILITY_MISSING`, `PREREQUISITE_GAP`, `PROJECT_LINK_UNAUTHORIZED`, `COPYRIGHT_SCOPE_RISK`, `ASSESSMENT_ALIGNMENT_GAP`, `ACCESSIBILITY_GAP`, and `FORMAT_VALIDATION_FAILED` return incomplete/decision/blocked results. If the textbook map, concept card, active project scope, or requested audience changes, version educational artifacts and mark only dependent educational artifacts `STALE`; do not silently alter research artifacts.

## Mode behavior and evidence

In `LEARN_AND_BUILD`, teaching content is required. In `BUILD_ONLY`, an educational request still requires instructional content because the task itself is teaching; `BUILD_ONLY` only suppresses incidental primer text when the educational worker is called as a formatting/helper route. User project facts remain `USER_FACT`; textbook concepts remain `BOOK_PRIMER`; current research is `RETRIEVED_EVIDENCE`; generated examples are `ASSUMPTION`/`DEMONSTRATION`; actual analytic results are `ANALYTIC_RESULT` only when verified.

## Verification

- Check every objective and activity against `knowledge/book_traceability_matrix.md`.
- Check every concept against `knowledge/concept_index.json`.
- Confirm cases/assessments are original and not long textbook reproductions.
- Confirm project-linked exercises do not mutate canonical research state.
- Validate artifact formats with existing `docx`, `powerpoint`, `pdf`, and accessibility backends.
- Return the educational stage result and keep educational completion separate from research completion.
