---
name: public-health-dissemination
description: "Plan audience-specific public-health dissemination."
version: 1.0.0
author: Mars Cruz, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [public-health, dissemination, SOCO, health-literacy, audiences]
    related_skills: [public-health-data-visualization, powerpoint, ap-stylebook-agent]
---

# Public Health Dissemination Planner

Build audience-specific dissemination plans from accepted findings and interpretations. Support researchers, practitioners, community participants, policy/decision makers, funders, the general public, and user-defined groups with distinct actions, messages, products, channels, timing, owners, and evaluation measures.

## When to Use

Use early to plan dissemination or after results to create evidence-bounded products and evaluate reach/use/impact.

## Do Not Use

Do not use it to make one shortened manuscript serve every audience, overstate findings, expose participants, use unsupported social math, or publish/post/send externally without the required authority and user approval.

## AgentContract

- **Capability:** produce an audience matrix, SOCO/social-math options, product/channel plan, execution timeline, and evaluation plan; optionally build content through generic format skills.
- **Required inputs:** intended finding/interpretation or explicit planning request; audience/decision context; project mode.
- **Optional inputs:** visual assets; stakeholders; literacy/language/accessibility; budget; channels; release dates/owners; evaluation metrics; venue/style.
- **Outputs:** audience matrix, message/SOCO, safe social-math candidates, product/channel specifications, timing/owner plan, reach/use evaluation, privacy/ethics checks, and stage result.
- **State reads:** `research.results`; `research.interpretation`; `research.limitations`; `research.visualization`; `research.dissemination`; `research.stakeholders`; `research.ethics_equity`; `research.budget`; `research.timeline`; `learner.accessibility_needs`; `provenance`; `workflow`.
- **State writes:** `research.dissemination`; `workflow.artifacts`; `provenance`; no alteration to results.
- **Validation rules:** each product maps to an audience/action and accepted evidence; distinguish knowledge translation/dissemination from passive diffusion; preserve limitations, uncertainty, funding/conflicts, authorship, consent/privacy, language/culture, health literacy, unintended consequences, and recommended action; social math preserves units/denominators/timeframes; external publication/posting remains an authority gate.
- **Completion condition:** every target audience has a justified action/message/product/channel/timing/owner/evaluation metric or explicit pending decision, and no message exceeds evidence.

## Shared public-health contract

State-aware mode reads `architecture/project_state.schema.json` and returns `architecture/stage_result.schema.json`. The host loads state, suppresses answered questions, validates updates, records provenance, runs independent evaluation, and owns transitions. A worker writes only its declared fields and never substantively approves itself. Every substantive statement is classified as `USER_FACT`, `BOOK_PRIMER`, `RETRIEVED_EVIDENCE`, `AGENT_INFERENCE`, `ASSUMPTION`, `PENDING_DECISION`, or `ANALYTIC_RESULT`. Planning may be hypothetical; actual results require supplied data and an executed, reproducible analysis. Changes create versions, rationale, and `STALE` descendants. Two failed repairs escalate to human review.

## Required audience matrix

| Audience | Desired action | Needed information | Message/SOCO | Product | Channel | Timing | Owner | Evaluation metric |
|---|---|---|---|---|---|---|---|---|

## Adaptive intake and primer

Ask 3–7: audiences; decision/action; information needs; literacy/language/accessibility; one message; supporting facts; product/channel; timing/owner/budget; privacy/unintended consequences; reach/use metric. In `LEARN_AND_BUILD`, teach Chapter 15 audience segmentation, dissemination versus diffusion, SOCO, social math, health literacy, and ethical communication. In `BUILD_ONLY`, omit teaching.

## Failure states and propagation

`RESULT_OR_LIMITATION_MISSING`, `AUDIENCE_ACTION_UNCLEAR`, `SOCO_OVERREACH`, `SOCIAL_MATH_UNVERIFIED`, `ACCESSIBILITY_OR_LANGUAGE_GAP`, `PRIVACY_OR_UNINTENDED_CONSEQUENCE_RISK`, and `PUBLIC_RELEASE_NOT_AUTHORIZED` return non-complete statuses. Changes to findings, interpretation, limitations, audience, or budget stale dissemination products.

## Verification

Run claim/evidence and arithmetic checks, inspect audience fit, and route documents/slides/visuals through generic render/accessibility backends. Do not claim delivery unless an external action is verified.
## Correction propagation

Changes to results, interpretation, limitations, or audience create a new dissemination version and mark products `STALE`.
Never invent a dissemination audience, message, metric, citation, result, or delivery receipt.

