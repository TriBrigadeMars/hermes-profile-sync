---
name: prisma-systematic-review
description: "Run PRISMA systematic reviews with a 6-agent pipeline."
---

# PRISMA Systematic Review Pipeline

A multi-agent pipeline that conducts PRISMA 2020-compliant systematic reviews and meta-analyses. Six specialized subagents execute sequentially (with parallel optimization) to produce a complete review package with real tool access (web search, PDF parsing, R execution).

## Configuration Phase

Before spawning agents, collect from the user via clarify tool:

| Parameter | Options | Default |
|-----------|---------|---------|
| Research topic | Free text | *Required* |
| Review type | systematic-review, meta-analysis, scoping-review | systematic-review |
| Search mode | web-live (PubMed/web search), pdf-upload (analyze provided PDFs), both | web-live |
| Statistical approach | auto (agent decides), user-defined | auto |
| Effect measure | OR, RR, SMD, HR, MD, agent-decides | agent-decides |
| Model override | current-session, openrouter:provider/model | current-session |
| Output directory | Path | ~/prisma-review-{timestamp} |

### Topic Refinement
If the user provides a broad topic, the first agent (Protocol Specialist) refines it into a specific, answerable research question using PECOS framework. The user can override or approve before proceeding.

### Model Selection
If user chooses a specific model, document it. Each subagent inherits the session model by default. To override, include model preference in the delegation context.

## Pipeline Architecture

```
Stage 1: Protocol (PECOS Framework)
    ↓
Stage 2: Search Strategy (Boolean Strings + Optional Live Search)
    ↓
┌─────────────┬─────────────┬─────────────┐
│ Stage 3     │ Stage 4     │ Stage 5     │  ← PARALLEL
│ Screening   │ Extraction  │ Statistics  │
│ Rubric      │ Template    │ Plan + R    │
└─────────────┴─────────────┴─────────────┘
    ↓             ↓             ↓
Stage 6: PRISMA 2020 Manuscript Compilation
```

## Stage Details

### Stage 1: Protocol Development
**Agent**: Public Health Methodologist
**delegate_task goal**: Develop a comprehensive systematic review protocol with PECOS criteria
**Context**: Topic, review type, any user specifications
**Output**: Structured protocol with PECOS criteria, objectives, eligibility criteria, outcomes
**Deliverable**: `01_protocol.md`

Key protocol sections:
- Background and rationale
- Review question (formatted per PECOS)
- Population, Exposure/Intervention, Comparator, Outcomes, Study design
- Registration intent (PROSPERO)

### Stage 2: Search Strategy
**Agent**: Medical Librarian
**delegate_task goal**: Translate PECOS into Boolean search strings for PubMed, Embase, Cochrane, CINAHL
**Context**: Protocol from Stage 1, search mode setting
**Output**: Database-specific search strings, gray literature strategy
**Deliverable**: `02_search_strategy.md` + optional `02_search_results.csv`

Search mode handling:
- **web-live**: Execute PubMed searches via web_search/fetch_url, retrieve real results, compile into CSV
- **pdf-upload**: Generate a PDF processing checklist, instruct user on PDF organization
- **both**: Do web search AND prepare PDF intake

### Stage 3: Screening Rubric (PARALLEL)
**Agent**: Review Screener
**Context**: Protocol from Stage 1
**Output**: Two-stage screening rubric (title/abstract + full-text) with decision tree
**Deliverable**: `03_screening_rubric.md`

### Stage 4: Data Extraction Template (PARALLEL)
**Agent**: Data Extraction & Bias Analyst
**Context**: Protocol from Stage 1, extraction_schema.json template
**Output**: Customized extraction schema, ROBINS-I assessment framework
**Deliverable**: `04_extraction_template.json` + `04_bias_assessment.md`

### Stage 5: Statistical Analysis Plan (PARALLEL)
**Agent**: Biostatistician
**Context**: Protocol outcomes, effect measure preference, statistical approach, meta_analysis.R template
**Output**: Analysis plan document + customized R script
**Deliverable**: `05_analysis_plan.md` + `05_meta_analysis.R`

### Stage 6: PRISMA Manuscript
**Agent**: Lead PRISMA Author
**Context**: ALL outputs from Stages 1-5
**Output**: Complete manuscript draft + PRISMA checklist
**Deliverable**: `06_manuscript_draft.md` + `06_prisma_checklist.md`

## Output Structure

```
~/prisma-review-{topic-slug}-{timestamp}/
├── 01_protocol.md
├── 02_search_strategy.md
├── 02_search_results.csv          (web-live mode)
├── 03_screening_rubric.md
├── 04_extraction_template.json
├── 04_bias_assessment.md
├── 05_analysis_plan.md
├── 05_meta_analysis.R
├── 06_manuscript_draft.md
├── 06_prisma_checklist.md
├── extracted_data.csv              (template for data entry)
└── README.md                       (pipeline summary + next steps)
```

## Subagent Context Pattern

Each subagent receives:
```
RESEARCH TOPIC: {topic}
REVIEW TYPE: {type}
CONFIGURATION: {config}
PREVIOUS OUTPUTS: {prior_stage_deliverables}
YOUR TASK: {specific_stage_description}
OUTPUT FORMAT: {expected_structure}
```

Stages 3-5 receive Stages 1-2 outputs only. Stage 6 receives ALL outputs.

## PRISMA 2020 Compliance

Manuscript must address all 27 checklist items covering: title, abstract, rationale, objectives, eligibility, information sources, search strategy, selection process, data collection, risk of bias, effect measures, synthesis methods, reporting bias, certainty assessment, PRISMA flow diagram, study characteristics, results, discussion, conclusions, registration, funding.

## Error Handling

- Subagent failure: retry once with simplified context
- Web search failure: fall back to generating search strings only
- R code errors: report but continue to manuscript
- Always save partial results — never lose completed work
