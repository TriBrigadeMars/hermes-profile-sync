User prefers email delivery (nalcs.mika@gmail.com) for job hunt notifications via Gmail SMTP (app password already configured)
§
User is on Windows 11, uses Hermes Desktop app with default profile, has Telegram and email (Gmail) gateway connections configured. Prefers task completion with real working artifacts delivered.
§
User is Mars Cruz, MPH, CHES, Prevention/Education/Outreach Coordinator at CU Anschutz. Prefers zip packages with .md, .docx, .pptx. Prefers files saved to C:\Users\cruzmars\ (use /mnt/c/Users/cruzmars/ from Docker). Desktop: C:\Users\cruzmars\Desktop\. Has 4 custom skills: apa-7-style-agent, ap-stylebook-agent, writing-style-agent, powerpoint-style-agent.
§
User values verification of work products — always requests detailed article summaries after PRISMA pipeline runs to review citations. Prefers final manuscripts in .docx format (Word, Times New Roman 12pt, double-spaced). Runs multiple scoping reviews as a research program — prefers sequential execution (not parallel) for Docker stability. Wants all reviews consolidated into unified folder when running multiple pipelines.
§
Has a custom vibe-coded resume/cover-letter app that consumes job descriptions from a watched folder (input files on same Windows machine).